plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    id("org.jetbrains.kotlin.kapt")
}

android {
    namespace = "com.xxla.mh"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.xxla.mh"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.7"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        
        // 添加网络安全配置
        manifestPlaceholders["usesCleartextTraffic"] = "true"

        // 统一域名默认值（可被各 buildType 覆盖）
        // 请在此处修改为你的后端域名，或在 local.properties 中配置
        buildConfigField("String", "API_BASE", "\"http://YOUR_SERVER_IP:6687\"")

        // 扩展兼容 lib 的 so 库：支持主流 ABI
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    buildTypes {
        // Debug 环境：指向本地后端（Android 模拟器使用 10.0.2.2）
        debug {
            // Android 模拟器访问本机 localhost 用 10.0.2.2
            buildConfigField("String", "API_BASE", "\"http://10.0.2.2:6687\"")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Release 环境：指向线上域名
            buildConfigField("String", "API_BASE", "\"http://YOUR_SERVER_DOMAIN\"")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "11"
        // 全局允许使用 Compose Foundation 实验性 API，避免 Release 编译报错
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi"
        )
    }
    buildFeatures {
        compose = true
        viewBinding = true
        buildConfig = true
    }

    // 处理常见 jni 库重复打包冲突（如 libc++_shared.so）
    packaging {
        jniLibs {
            pickFirsts += listOf("**/libc++_shared.so")
        }
        resources {
            excludes += listOf("/META-INF/{AL2.0,LGPL2.1}")
        }
    }
}

hilt {
    // Workaround: disable aggregating task to avoid JavaPoet ClassName.canonicalName() NoSuchMethodError
    enableAggregatingTask = false
}

dependencies {
    // Core Android
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.activity.compose)
    
    // Compose BOM
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    // Compose Foundation & Animation (for clickable, AnimatedVisibility, fadeIn/fadeOut etc.)
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    // Material icons (extended set for icons like History, Comment, Reply, VideoLibrary, People, BarChart)
    implementation("androidx.compose.material:material-icons-extended")
    
    // Navigation
    implementation(libs.navigation.compose)
    
    // ViewModel
    implementation(libs.lifecycle.viewmodel.compose)
    
    // Dependency Injection
    implementation(libs.hilt.android)
    kapt(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)
    
    // Network
    implementation(libs.retrofit)
    implementation(libs.retrofit.gson)
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)
    implementation(libs.gson)
    implementation("org.jsoup:jsoup:1.17.2")
    
    // Database
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    kapt(libs.room.compiler)
    
    // Coroutines
    implementation(libs.kotlinx.coroutines.android)
    
    // Image Loading
    implementation(libs.coil.compose)
    implementation(libs.coil.gif)
    implementation(libs.coil.video)
    implementation(libs.glide)
    
    // Video Player
    implementation(libs.exoplayer)
    implementation(libs.exoplayer.ui)
    
    // Paging
    implementation(libs.paging.runtime)
    implementation(libs.paging.compose)
    
    // DataStore
    implementation(libs.datastore.preferences)
    
    // WorkManager
    implementation(libs.work.runtime.ktx)

    // Firebase Messaging (push notifications)
    implementation(platform("com.google.firebase:firebase-bom:33.3.0"))
    implementation("com.google.firebase:firebase-messaging-ktx")
    // Google Play Services 基础库（修复启动时缺少 com.google.android.gms.common.R$string 的 ClassNotFound）
    implementation("com.google.android.gms:play-services-base:18.3.0")
    implementation("com.google.android.gms:play-services-basement:18.3.0")
    
    // Camera
    implementation(libs.camerax.core)
    implementation(libs.camerax.camera2)
    implementation(libs.camerax.lifecycle)
    implementation(libs.camerax.video)
    implementation(libs.camerax.view)
    implementation(libs.camerax.extensions)
    
    // Permissions
    implementation(libs.accompanist.permissions)
    
    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)

    // Core library desugaring for java.time, Streams, etc.
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
