package com.xxla.mh

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.navigation.BottomNavItem
import com.xxla.mh.navigation.Screen
import com.xxla.mh.ui.components.BottomNavigationBar
import com.xxla.mh.ui.components.NotificationPermissionPrompt
import com.xxla.mh.ui.screens.auth.AuthScreen
import com.xxla.mh.ui.screens.home.HomeScreen
import com.xxla.mh.ui.screens.profile.ProfileScreen
import com.xxla.mh.ui.screens.profile.FollowersScreen
import com.xxla.mh.ui.screens.profile.FollowingScreen
import com.xxla.mh.ui.screens.upload.UploadScreen
import com.xxla.mh.ui.theme.MhTheme
import com.xxla.mh.ui.theme.ThemeViewModel
import com.xxla.mh.ui.theme.ThemeMode
import com.xxla.mh.ui.update.UpdateViewModel
import com.xxla.mh.ui.update.UpdateUiState
import androidx.compose.ui.graphics.Color
import dagger.hilt.android.AndroidEntryPoint
import com.xxla.mh.ui.screens.chat.ChatViewModel

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val startRoute = intent?.getStringExtra("start_route")
        setContent {
            val themeViewModel: ThemeViewModel = hiltViewModel()
            val themeMode by themeViewModel.themeMode.collectAsState()
            MhTheme(darkTheme = themeMode == ThemeMode.DARK) {
                VideoAppUI(startRoute = startRoute)
            }
        }
    }
}

@Composable
fun VideoAppUI(startRoute: String? = null) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val updateViewModel: UpdateViewModel = hiltViewModel()
    val updateState by updateViewModel.uiState.collectAsState()
    val chatViewModel: ChatViewModel = hiltViewModel()
    val chatUiState by chatViewModel.uiState.collectAsState()
    
    // 处理从通知跳转的目标路由
    LaunchedEffect(startRoute) {
        startRoute?.let { route ->
            if (route.isNotBlank()) {
                navController.navigate(route)
            }
        }
    }
    
    // 需要显示底部导航栏的页面
    val bottomNavRoutes = listOf(
        Screen.Home.route,
        Screen.Chat.route,
        Screen.Upload.route,
        Screen.Profile.route
    )
    val isBottomNavVisible = currentRoute in bottomNavRoutes
    
    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                if (currentRoute in bottomNavRoutes) {
                    Surface(
                        shadowElevation = 8.dp,
                        tonalElevation = 8.dp
                    ) {
                        BottomNavigationBar(
                            navController = navController,
                            chatUnreadCount = chatUiState.totalUnread
                        )
                    }
                }
            }
        ) { innerPadding ->
            MainNavHost(
                navController = navController,
                modifier = Modifier.padding(innerPadding)
            )
        }

        MandatoryUpdateOverlay(
            uiState = updateState,
            onUpdateClick = { updateViewModel.startUpdate() },
            onInstallClick = { updateViewModel.installNow() }
        )

        // 通知权限提示（Android 13+ 运行时权限 / Android 9 引导到系统设置）
        NotificationPermissionPrompt()

        // 想念传话按钮：仅在情侣空间页面显示（避免全局干扰）
        if (currentRoute == Screen.CoupleSpace.route) {
            com.xxla.mh.ui.components.MissYouSendButton(
                onMoreClick = { navController.navigate(Screen.MissYouSent.route) }
            )
        }

        // 想念全屏弹层（接收者打开 App 时展示）——改为 WebView 版本以支持多预设与屏蔽交互
        com.xxla.mh.ui.components.MissYouWebOverlay()
    }
}

@Composable
fun MainNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        // 主要页面
        composable(Screen.Home.route) {
            HomeScreen(navController = navController)
        }
        
        composable(Screen.Chat.route) {
            com.xxla.mh.ui.screens.chat.ChatScreen(navController = navController)
        }
        
        composable(Screen.Upload.route) {
            UploadScreen(navController = navController)
        }
        
        composable(Screen.Profile.route) {
            ProfileScreen(navController = navController)
        }

        // 一起看入口页面
        composable(Screen.WatchTogether.route) {
            com.xxla.mh.ui.screens.watch.WatchTogetherScreen(navController = navController)
        }
        
        // 情侣空间页面
        composable(Screen.CoupleSpace.route) {
            com.xxla.mh.ui.screens.chat.CoupleSpaceScreen(navController = navController)
        }

        // 共同相册页面
        composable(Screen.CoupleAlbum.route) {
            com.xxla.mh.ui.screens.chat.CoupleAlbumScreen(navController = navController)
        }
        
        // 视频播放页面（支持深链与起始进度）
        composable(
            route = Screen.VideoPlayer.route,
            arguments = listOf(
                androidx.navigation.navArgument("videoId") { type = androidx.navigation.NavType.StringType },
                androidx.navigation.navArgument("source") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                androidx.navigation.navArgument("startMs") { type = androidx.navigation.NavType.LongType; defaultValue = 0L }
            ),
            deepLinks = listOf(
                androidx.navigation.navDeepLink { uriPattern = "mh://video_play?videoId={videoId}&source={source}&startMs={startMs}" }
            )
        ) { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId") ?: ""
            val sourceRaw = backStackEntry.arguments?.getString("source")
            val source = if (sourceRaw.isNullOrBlank()) null else sourceRaw
            val startMs = backStackEntry.arguments?.getLong("startMs") ?: 0L
            com.xxla.mh.ui.player.VideoPlayerScreen(
                videoId = videoId,
                source = source,
                initialStartMs = startMs,
                onBackClick = { navController.popBackStack() }
            )
        }
        
        // 统一认证页面（兼容原有路由）
        composable(Screen.Login.route) {
            AuthScreen(navController = navController)
        }
        
        composable(Screen.Register.route) {
            AuthScreen(navController = navController)
        }
        
        // 搜索页面
        composable(Screen.Search.route) {
            com.xxla.mh.ui.screens.search.SearchScreen(navController = navController)
        }

        // 看动漫页面（纯 Compose 搜索）
        composable(Screen.AnimeSearch.route) {
            com.xxla.mh.ui.screens.anime.AnimeSearchScreen(
                onOpenDetail = { subject ->
                    navController.navigate(
                        com.xxla.mh.navigation.Screen.AnimeDetail.createRoute(
                            url = subject.detailUrl,
                            title = subject.title
                        )
                    )
                },
                onBack = { navController.popBackStack() }
            )
        }

        // 动漫详情页面
        composable(
            route = com.xxla.mh.navigation.Screen.AnimeDetail.route,
            arguments = listOf(
                androidx.navigation.navArgument("url") { type = androidx.navigation.NavType.StringType },
                androidx.navigation.navArgument("title") { type = androidx.navigation.NavType.StringType; defaultValue = "" }
            )
        ) { backStackEntry ->
            val urlArg = backStackEntry.arguments?.getString("url") ?: ""
            val titleArg = backStackEntry.arguments?.getString("title") ?: ""
            val urlDecoded = java.net.URLDecoder.decode(urlArg, "UTF-8")
            val titleDecoded = java.net.URLDecoder.decode(titleArg, "UTF-8")
            com.xxla.mh.ui.screens.anime.AnimeDetailScreen(
                detailUrl = urlDecoded,
                onStartPlay = { playInfo, episodePageUrl ->
                    // 已获取直链，携带直链与 headers 导航到播放页
                    navController.navigate(
                        com.xxla.mh.navigation.Screen.AnimePlay.createRoute(
                            title = titleDecoded,
                            // 传入剧集播放页的原始网页地址，确保内置浏览器加载正确页面
                            episodeUrl = episodePageUrl,
                            videoUrl = playInfo.videoUrl,
                            headers = playInfo.headers
                        )
                    )
                },
                onBack = { navController.popBackStack() }
            )
        }

        // 播放页面
        composable(
            route = com.xxla.mh.navigation.Screen.AnimePlay.route,
            arguments = listOf(
                androidx.navigation.navArgument("title") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                androidx.navigation.navArgument("episodeUrl") { type = androidx.navigation.NavType.StringType },
                androidx.navigation.navArgument("videoUrl") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                androidx.navigation.navArgument("headers") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                androidx.navigation.navArgument("startMs") { type = androidx.navigation.NavType.LongType; defaultValue = 0L },
                // 一起看好友信息（可选）
                androidx.navigation.navArgument("peerId") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                androidx.navigation.navArgument("peerName") { type = androidx.navigation.NavType.StringType; defaultValue = "" },
                androidx.navigation.navArgument("peerAvatar") { type = androidx.navigation.NavType.StringType; defaultValue = "" }
            ),
            deepLinks = listOf(
                androidx.navigation.navDeepLink {
                    uriPattern = "mh://anime_play?title={title}&episodeUrl={episodeUrl}&videoUrl={videoUrl}&headers={headers}&startMs={startMs}"
                }
            )
        ) { backStackEntry ->
            val titleArg = backStackEntry.arguments?.getString("title") ?: ""
            val urlArg = backStackEntry.arguments?.getString("episodeUrl") ?: ""
            val videoArg = backStackEntry.arguments?.getString("videoUrl") ?: ""
            val headersArg = backStackEntry.arguments?.getString("headers") ?: ""
            val startMsArg = backStackEntry.arguments?.getLong("startMs") ?: 0L
            val peerIdArg = backStackEntry.arguments?.getString("peerId") ?: ""
            val peerNameArg = backStackEntry.arguments?.getString("peerName") ?: ""
            val peerAvatarArg = backStackEntry.arguments?.getString("peerAvatar") ?: ""
            val titleDecoded = java.net.URLDecoder.decode(titleArg, "UTF-8")
            val urlDecoded = java.net.URLDecoder.decode(urlArg, "UTF-8")
            val videoDecoded = java.net.URLDecoder.decode(videoArg, "UTF-8")
            val headersDecoded = java.net.URLDecoder.decode(headersArg, "UTF-8")
            val peerIdDecoded = java.net.URLDecoder.decode(peerIdArg, "UTF-8")
            val peerNameDecoded = java.net.URLDecoder.decode(peerNameArg, "UTF-8")
            val peerAvatarDecoded = java.net.URLDecoder.decode(peerAvatarArg, "UTF-8")
            val headersMap: Map<String, String> = try {
                com.google.gson.Gson().fromJson(headersDecoded, Map::class.java) as Map<String, String>
            } catch (_: Exception) { emptyMap() }
            com.xxla.mh.ui.screens.anime.AnimePlayScreen(
                title = titleDecoded,
                episodeUrl = urlDecoded,
                initialVideoUrl = if (videoDecoded.isNotBlank()) videoDecoded else null,
                initialHeaders = headersMap,
                initialStartMs = startMsArg.takeIf { it > 0 },
                peerId = peerIdDecoded.takeIf { it.isNotBlank() },
                peerName = peerNameDecoded.takeIf { it.isNotBlank() },
                peerAvatar = peerAvatarDecoded.takeIf { it.isNotBlank() },
                onBack = { navController.popBackStack() }
            )
        }

        // 用户主页页面（根据 userId 展示其作品）
        composable(Screen.UserProfile.route) { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            com.xxla.mh.ui.screens.profile.UserProfileScreen(
                navController = navController,
                userId = userId
            )
        }

        // 粉丝列表页面
        composable(Screen.FollowersList.route) { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            FollowersScreen(
                userId = userId,
                onBackClick = { navController.popBackStack() },
                onUserClick = { targetUserId ->
                    navController.navigate(Screen.UserProfile.createRoute(targetUserId))
                }
            )
        }

        // 关注列表页面
        composable(Screen.FollowingList.route) { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId") ?: ""
            FollowingScreen(
                userId = userId,
                onBackClick = { navController.popBackStack() },
                onUserClick = { targetUserId ->
                    navController.navigate(Screen.UserProfile.createRoute(targetUserId))
                }
            )
        }
        
        // 评论页面
        composable("comment_screen/{videoId}") { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId") ?: ""
            com.xxla.mh.ui.screens.comment.CommentScreen(
                navController = navController,
                videoId = videoId
            )
        }
        
        // 历史记录页面
        composable("history_screen") {
            com.xxla.mh.ui.screens.profile.HistoryScreen(navController = navController)
        }

        // 帖子历史页面
        composable("post_history_screen") {
            com.xxla.mh.ui.screens.profile.PostHistoryScreen(navController = navController)
        }

        // 消息中心页面
        composable("message_center_screen") {
            com.xxla.mh.ui.screens.profile.MessageCenterScreen(navController = navController)
        }

        // 我的视频页面（占位屏）
        composable("my_videos") {
            com.xxla.mh.ui.screens.profile.MyVideosScreen(navController = navController)
        }

        // 我的动态页面
        composable("my_posts") {
            com.xxla.mh.ui.screens.profile.MyPostsScreen(navController = navController)
        }

        // 编辑视频页面
        composable(Screen.EditVideo.route) { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId") ?: ""
            com.xxla.mh.ui.screens.edit.EditVideoScreen(
                navController = navController,
                videoId = videoId
            )
        }

        // 帖子详情页面
        composable(Screen.PostDetail.route) { backStackEntry ->
            val postId = backStackEntry.arguments?.getString("postId") ?: ""
            com.xxla.mh.ui.screens.post.PostDetailScreen(
                navController = navController,
                postId = postId
            )
        }

        // 编辑帖子页面
        composable(Screen.EditPost.route) { backStackEntry ->
            val postId = backStackEntry.arguments?.getString("postId") ?: ""
            com.xxla.mh.ui.screens.edit.EditPostScreen(
                navController = navController,
                postId = postId
            )
        }

        // 关于我们页面
        composable("about") {
            com.xxla.mh.ui.screens.profile.AboutScreen(navController = navController)
        }

        // 收藏夹页面
        composable(Screen.Favorites.route) {
            // FavoritesScreen(navController = navController)
        }
        
        // 设置页面
        composable(Screen.Settings.route) {
            // SettingsScreen(navController = navController)
        }

        // 聊天会话页面
        composable(Screen.ChatConversation.route) { backStackEntry ->
            val peerId = backStackEntry.arguments?.getString("peerId") ?: ""
            val nameArg = backStackEntry.arguments?.getString("name") ?: ""
            val avatarArg = backStackEntry.arguments?.getString("avatar") ?: ""
            val decodedName = try { java.net.URLDecoder.decode(nameArg, "UTF-8") } catch (_: Exception) { nameArg }
            val decodedAvatar = try { java.net.URLDecoder.decode(avatarArg, "UTF-8") } catch (_: Exception) { avatarArg }
            com.xxla.mh.ui.screens.chat.ChatConversationScreen(
                navController = navController,
                peerId = peerId,
                name = decodedName,
                avatar = decodedAvatar
            )
        }

        // 想念记录列表页面
        composable(Screen.MissYouSent.route) {
            com.xxla.mh.ui.screens.chat.MissYouSentScreen(navController = navController)
        }
    }
}

@Composable
fun MandatoryUpdateOverlay(
    uiState: UpdateUiState,
    onUpdateClick: () -> Unit,
    onInstallClick: () -> Unit
) {
    if (uiState.showDialog) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.4f)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .padding(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                androidx.compose.foundation.layout.Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "发现新版本，需更新后使用")
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(8.dp))

                    uiState.notes?.takeIf { it.isNotBlank() }?.let { notes ->
                        Text(text = notes)
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(8.dp))
                    }

                    if (!uiState.canInstall) {
                        Button(onClick = onUpdateClick, enabled = !uiState.downloading) {
                            Text(text = if (uiState.builtin) "应用内更新" else "立即更新")
                        }
                    }
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(8.dp))
                    Text(text = when {
                        uiState.canInstall -> "安装包已下载，可立即安装"
                        uiState.builtin -> "正在应用内下载安装包"
                        else -> "将跳转系统浏览器下载最新安装包"
                    })

                    if (uiState.downloading) {
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(8.dp))
                        if (uiState.progress > 0) {
                            LinearProgressIndicator(progress = uiState.progress / 100f)
                        } else {
                            // 总大小未知或下载起步阶段，展示不确定进度条避免长期0%误导
                            LinearProgressIndicator()
                        }
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(4.dp))
                        Text(text = "下载进度: ${uiState.progress}%")
                    }

                    if (uiState.canInstall) {
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(8.dp))
                        Button(onClick = onInstallClick) {
                            Text(text = "立即安装")
                        }
                    }

                    uiState.error?.let { err ->
                        androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(8.dp))
                        Text(text = err, color = Color.Red)
                    }
                }
            }
        }
    }
}
