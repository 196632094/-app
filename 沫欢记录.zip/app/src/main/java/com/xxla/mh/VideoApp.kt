package com.xxla.mh

import android.app.Application
import android.os.Environment
import java.io.File
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.xxla.mh.notifications.NotificationHelper
import com.xxla.mh.notifications.NotificationPollingWorker
import java.util.concurrent.TimeUnit
import coil.ImageLoader
import coil.Coil
import coil.decode.ImageDecoderDecoder
import coil.decode.GifDecoder
import coil.decode.VideoFrameDecoder
import android.os.Build
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ProcessLifecycleOwner
import com.xxla.mh.network.PresenceApiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@HiltAndroidApp
class VideoApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        cleanOldApks()
        // 初始化通知渠道
        NotificationHelper.createChannels(this)
        // 调度后台轮询任务（最短 15 分钟间隔）
        schedulePolling()
        // 启动前台在线心跳（应用进入前台时每 30 秒一次）
        startPresenceHeartbeat()
        // 初始化全局 Coil ImageLoader，启用 GIF 与视频帧支持
        val imageLoader = ImageLoader.Builder(this)
            .components {
                // 视频帧解码（用于以视频第一帧作为缩略图显示）
                add(VideoFrameDecoder.Factory())
                if (Build.VERSION.SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
        Coil.setImageLoader(imageLoader)
    }

    private fun cleanOldApks() {
        try {
            val dirs = listOfNotNull(
                cacheDir,
                externalCacheDir,
                getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            )
            dirs.forEach { dir ->
                dir.listFiles()?.forEach { f ->
                    val name = f.name.lowercase()
                    if (name.endsWith(".apk") || name.startsWith("update-")) {
                        // 仅删除非目录且可写文件
                        if (f.isFile) {
                            runCatching { f.delete() }
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // 忽略清理异常，避免影响应用启动
        }
    }

    private fun schedulePolling() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val work = PeriodicWorkRequestBuilder<NotificationPollingWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "notification_polling",
            ExistingPeriodicWorkPolicy.UPDATE,
            work
        )
    }

    private fun startPresenceHeartbeat() {
        val lifecycle = ProcessLifecycleOwner.get().lifecycle
        lifecycle.addObserver(LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> startHeartbeatLoop()
                Lifecycle.Event.ON_STOP -> stopHeartbeatLoop()
                else -> {}
            }
        })
    }

    private fun startHeartbeatLoop() {
        if (heartbeatJob?.isActive == true) return
        val entryPoint = EntryPointAccessors.fromApplication(this, AppEntryPoint::class.java)
        val presenceApi = entryPoint.presenceApiService()
        heartbeatJob = appScope.launch {
            while (isActive) {
                runCatching { presenceApi.heartbeat() }
                delay(30_000)
            }
        }
    }

    private fun stopHeartbeatLoop() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }
}

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AppEntryPoint {
    fun presenceApiService(): PresenceApiService
}
