package com.xxla.mh.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

private val Context.playbackDataStore: DataStore<Preferences> by preferencesDataStore(name = "playback_progress")

@Singleton
class PlaybackProgressRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private fun posKey(namespace: String, id: String): Preferences.Key<Long> {
        val h = id.hashCode().toString()
        return longPreferencesKey("pos_${namespace}_$h")
    }

    private fun tsKey(namespace: String, id: String): Preferences.Key<Long> {
        val h = id.hashCode().toString()
        return longPreferencesKey("ts_${namespace}_$h")
    }

    // 默认命名空间为 anime，兼容现有调用
    suspend fun savePosition(episodeUrl: String, positionMs: Long) {
        savePositionNS("anime", episodeUrl, positionMs)
    }

    fun readPosition(episodeUrl: String): Flow<Long?> {
        return readPositionNS("anime", episodeUrl)
    }

    suspend fun savePositionNS(namespace: String, id: String, positionMs: Long) {
        context.playbackDataStore.edit { prefs ->
            prefs[posKey(namespace, id)] = positionMs
            prefs[tsKey(namespace, id)] = System.currentTimeMillis()
        }
    }

    fun readPositionNS(namespace: String, id: String): Flow<Long?> {
        val k = posKey(namespace, id)
        return context.playbackDataStore.data.map { prefs ->
            prefs[k]
        }
    }

    suspend fun clearPositionNS(namespace: String, id: String) {
        context.playbackDataStore.edit { prefs ->
            prefs.remove(posKey(namespace, id))
            prefs.remove(tsKey(namespace, id))
        }
    }

    /**
     * 将指定命名空间的记录裁剪到至多 maxEntries 条，按最近更新时间保留。
     */
    suspend fun trimToSize(namespace: String, maxEntries: Int) {
        if (maxEntries <= 0) return
        val snapshot = context.playbackDataStore.data.first()
        val tsPrefix = "ts_${namespace}_"
        val allTs = snapshot.asMap().entries
            .filter { it.key.name.startsWith(tsPrefix) }
            .map { entry ->
                val name = entry.key.name
                val hash = name.removePrefix(tsPrefix)
                val ts = (entry.value as? Long) ?: 0L
                hash to ts
            }
        if (allTs.size <= maxEntries) return
        val overflow = allTs.sortedByDescending { it.second }.drop(maxEntries)
        if (overflow.isEmpty()) return
        context.playbackDataStore.edit { prefs ->
            overflow.forEach { (hash) ->
                val posName = "pos_${namespace}_$hash"
                val tsName = "ts_${namespace}_$hash"
                // 构造匿名 key 进行删除
                val posK = longPreferencesKey(posName)
                val tsK = longPreferencesKey(tsName)
                prefs.remove(posK)
                prefs.remove(tsK)
            }
        }
    }

    /**
     * 动态裁剪策略：以 baseMax 为基础，按实际记录条数增加保留上限，最多不超过 cap。
     * 规则：每超过 baseMax 的 100 条，允许额外保留 50 条（上限 cap）。
     */
    suspend fun trimDynamically(namespace: String, baseMax: Int = 200, cap: Int = 500) {
        val snapshot = context.playbackDataStore.data.first()
        val tsPrefix = "ts_${namespace}_"
        val size = snapshot.asMap().keys.count { it.name.startsWith(tsPrefix) }
        if (size <= baseMax) return
        val extra = ((size - baseMax).coerceAtLeast(0) / 100) * 50
        val max = (baseMax + extra).coerceAtMost(cap)
        trimToSize(namespace, max)
    }
}
