package com.xxla.mh.data

import com.xxla.mh.network.PostApiService
import com.xxla.mh.network.PostListResponse
import com.xxla.mh.network.PostDetailResponse
import com.xxla.mh.network.BaseResponse
import com.xxla.mh.network.CommentListResponse
import com.xxla.mh.network.CommentResponse
import com.xxla.mh.network.CommentRequest
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PostRepository @Inject constructor(
    private val postApiService: PostApiService
) {
    suspend fun getPosts(
        type: String = "all",
        page: Int,
        size: Int,
        noRetry: Boolean = false
    ): Response<PostListResponse> {
        return postApiService.getPosts(type = type, page = page, size = size, noRetry = if (noRetry) "true" else null)
    }

    // 详情
    suspend fun getPostDetail(postId: String): Response<PostDetailResponse> {
        return postApiService.getPostDetail(postId)
    }

    // 点赞/取消点赞帖子
    suspend fun likePost(postId: String): Response<BaseResponse> {
        return postApiService.likePost(postId)
    }
    suspend fun unlikePost(postId: String): Response<BaseResponse> {
        return postApiService.unlikePost(postId)
    }

    // 评论相关
    suspend fun getPostComments(postId: String, page: Int, size: Int): Response<CommentListResponse> {
        return postApiService.getComments(postId, page, size)
    }

    suspend fun postComment(postId: String, content: String, parentId: String? = null): Response<CommentResponse> {
        return postApiService.postComment(postId, CommentRequest(content, parentId))
    }

    suspend fun likeComment(postId: String, commentId: String): Response<BaseResponse> {
        return postApiService.likeComment(postId, commentId)
    }

    suspend fun unlikeComment(postId: String, commentId: String): Response<BaseResponse> {
        return postApiService.unlikeComment(postId, commentId)
    }

    // 删除评论（帖子）
    suspend fun deleteComment(postId: String, commentId: String): Boolean {
        return try {
            postApiService.deleteComment(postId, commentId).isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 删除帖子
    suspend fun deletePost(postId: String): Boolean {
        return try {
            postApiService.deletePost(postId).isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 更新帖子（原始形式，调用方构建好请求体与文件）
    suspend fun updatePost(
        postId: String,
        type: RequestBody,
        images: List<MultipartBody.Part>?,
        audio: MultipartBody.Part?,
        cover: MultipartBody.Part?,
        title: RequestBody?,
        content: RequestBody?,
        description: RequestBody?,
        tags: RequestBody?,
        isPublic: RequestBody?
    ): Response<BaseResponse> {
        return postApiService.updatePost(
            postId = postId,
            type = type,
            images = images,
            audio = audio,
            cover = cover,
            title = title,
            content = content,
            description = description,
            tags = tags,
            isPublic = isPublic
        )
    }

    // 可根据需要扩展：按类型分别拉取、分页加载更多等
}
