package com.xxla.mh.data

import com.xxla.mh.network.StickerApiService
import com.xxla.mh.network.StickerResponse
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StickerRepository @Inject constructor(
    private val stickerApiService: StickerApiService
) {
    suspend fun getStickers(): List<String> {
        val resp = stickerApiService.getStickers()
        val body: StickerResponse? = resp.body()
        if (!resp.isSuccessful || body == null || body.success == false) {
            throw Exception(resp.errorBody()?.string() ?: body?.message ?: resp.message())
        }
        val items = body.data?.items ?: emptyList()
        return items.map { it.url }
    }
}
