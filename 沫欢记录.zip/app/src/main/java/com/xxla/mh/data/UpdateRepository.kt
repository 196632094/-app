package com.xxla.mh.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.net.Uri
import androidx.core.content.FileProvider
import com.xxla.mh.network.UpdateApiService
import com.xxla.mh.network.UpdateConfigData
import com.xxla.mh.util.UrlUtils
import dagger.hilt.android.qualifiers.ApplicationContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import android.database.Cursor
import android.provider.Settings
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UpdateRepository @Inject constructor(
    private val updateApiService: UpdateApiService,
    private val okHttpClient: OkHttpClient,
    @ApplicationContext private val context: Context
) {
    data class DownloadProgress(val status: Int, val percent: Int, val localUri: String?, val reason: String? = null)
    private var lastApkFile: File? = null
    private var lastDownloadId: Long? = null
    private var lastRemoteTotalBytes: Long = -1L

    suspend fun fetchUpdateConfig(): UpdateConfigData? {
        return try {
            val resp = updateApiService.getUpdateConfig()
            val body = resp.body()
            if (resp.isSuccessful && body != null && body.success) {
                body.data
            } else null
        } catch (e: Exception) {
            null
        }
    }

    fun openUrlInBrowser(url: String) {
        val fullUrl = UrlUtils.toAbsolute(url)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    suspend fun downloadApk(url: String, onProgress: (Int) -> Unit): File {
        // 统一到后端主域，避免跨域导致连接超时或证书问题
        val fullUrl = UrlUtils.toApiHost(url)
        val request = Request.Builder().url(fullUrl).build()
        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) {
            throw IOException("APK下载失败: ${response.code}")
        }
        val body = response.body ?: throw IOException("APK下载失败: 空响应体")
        val total = body.contentLength()

        // 优先存储到缓存目录
        val target = File(context.cacheDir, "update-${System.currentTimeMillis()}.apk")
        body.byteStream().use { input ->
            FileOutputStream(target).use { output ->
                val buffer = ByteArray(8 * 1024)
                var downloaded = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloaded += read
                    if (total > 0) {
                        val pct = ((downloaded * 100) / total).toInt()
                        onProgress(pct)
                    }
                }
                output.flush()
            }
        }
        // 记录最后下载的文件，便于后续触发安装
        lastApkFile = target
        return target
    }

    fun startDownloadWithDownloadManager(url: String): Long {
        // 统一到后端主域，避免跨域导致连接超时或证书问题
        val fullUrl = UrlUtils.toApiHost(url)
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        // 固定存储到应用外部文件目录，便于安装与文件权限
        val fileName = "update-${System.currentTimeMillis()}.apk"
        val destination = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        lastApkFile = destination

        val request = DownloadManager.Request(Uri.parse(fullUrl)).apply {
            setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            setTitle("沫欢记录 更新")
            setDescription("正在下载新版本")
            setMimeType("application/vnd.android.package-archive")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setAllowedOverMetered(true)
            setAllowedOverRoaming(true)
            setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
        }
        // 预取远端文件大小，以便在 DownloadManager 无法提供总大小时显示更合理的进度
        lastRemoteTotalBytes = fetchRemoteContentLength(fullUrl)
        val id = dm.enqueue(request)
        lastDownloadId = id
        return id
    }

    fun queryDownloadProgress(id: Long): DownloadProgress {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(id)
        val cursor: Cursor? = dm.query(query)
        cursor?.use { c ->
            if (c.moveToFirst()) {
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val downloaded = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val localUri = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                val reasonCode = try { c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)) } catch (_: Exception) { 0 }
                val pct = when {
                    total > 0 -> ((downloaded * 100) / total).toInt()
                    lastRemoteTotalBytes > 0 -> ((downloaded * 100) / lastRemoteTotalBytes).toInt().coerceAtMost(99)
                    else -> 0
                }
                val reasonText = when (status) {
                    DownloadManager.STATUS_PAUSED -> when (reasonCode) {
                        DownloadManager.PAUSED_QUEUED_FOR_WIFI -> "等待Wi-Fi连接"
                        DownloadManager.PAUSED_WAITING_FOR_NETWORK -> "等待网络连接"
                        DownloadManager.PAUSED_WAITING_TO_RETRY -> "等待重试"
                        else -> "下载暂停"
                    }
                    DownloadManager.STATUS_FAILED -> when (reasonCode) {
                        DownloadManager.ERROR_CANNOT_RESUME -> "无法继续，网络或存储问题"
                        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "存储设备不可用"
                        DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "文件已存在"
                        DownloadManager.ERROR_FILE_ERROR -> "文件错误"
                        DownloadManager.ERROR_HTTP_DATA_ERROR -> "HTTP数据错误"
                        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "空间不足"
                        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "重定向过多"
                        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "HTTP状态码不支持"
                        else -> "下载失败"
                    }
                    else -> null
                }
                return DownloadProgress(status, pct, localUri, reasonText)
            }
        }
        return DownloadProgress(DownloadManager.STATUS_FAILED, 0, null, "下载失败")
    }

    private fun fetchRemoteContentLength(url: String): Long {
        return try {
            val req = Request.Builder().url(url).head().build()
            okHttpClient.newCall(req).execute().use { resp ->
                val cl = resp.header("Content-Length")
                cl?.toLongOrNull() ?: -1L
            }
        } catch (_: Exception) {
            -1L
        }
    }

    private fun installApk(file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        launchInstaller(uri)
    }

    private fun launchInstaller(uri: Uri) {
        val intent = Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun installLastDownloadedApkIfAvailable() {
        val file = lastApkFile
        if (file != null && file.exists()) {
            installApk(file)
            return
        }
        val id = lastDownloadId
        if (id != null) {
            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri = dm.getUriForDownloadedFile(id)
            if (uri != null) {
                launchInstaller(uri)
            }
        }
    }

    fun getLocalVersionName(): String {
        return try {
            val pm = context.packageManager
            val p = pm.getPackageInfo(context.packageName, 0)
            p.versionName ?: "0"
        } catch (e: Exception) {
            "0"
        }
    }
}
