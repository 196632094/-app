package com.xxla.mh.data

import android.content.Context
import android.net.Uri
import com.xxla.mh.network.VideoApiService
import com.xxla.mh.network.PostApiService
import okhttp3.RequestBody
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UploadRepository @Inject constructor(
    private val videoApiService: VideoApiService,
    private val postApiService: PostApiService,
    @ApplicationContext private val context: Context
) {
    
    fun uploadVideo(
        videoUri: Uri,
        thumbnailUri: Uri? = null,
        title: String,
        description: String,
        tags: List<String>,
        isPublic: Boolean,
        onProgress: (Float) -> Unit
    ): Flow<Result<String>> = flow {
        try {
            // 将Uri转换为File
            val videoFile = createTempFileFromUri(context, videoUri)
            val thumbFile: File? = thumbnailUri?.let { createTempFileFromUri(context, it) }
            
            // 创建MultipartBody.Part
            val videoRequestBody = videoFile.asRequestBody("video/*".toMediaTypeOrNull())
            val videoPart = MultipartBody.Part.createFormData(
                "video",
                videoFile.name,
                videoRequestBody
            )
            
            // 创建其他参数（使用 RequestBody 而非 Part）
            val titleBody = title.toRequestBody("text/plain".toMediaTypeOrNull())
            val descriptionBody = description.toRequestBody("text/plain".toMediaTypeOrNull())
            val tagsBody = tags.joinToString(",").toRequestBody("text/plain".toMediaTypeOrNull())
            val isPublicBody = isPublic.toString().toRequestBody("text/plain".toMediaTypeOrNull())
            val thumbnailPart: MultipartBody.Part? = thumbFile?.let { file ->
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("thumbnail", file.name, body)
            }
            
            // 上传视频
            val response = videoApiService.uploadVideo(
                video = videoPart,
                title = titleBody,
                description = descriptionBody,
                tags = tagsBody,
                thumbnail = thumbnailPart,
                isPublic = isPublicBody
            )
            
            // 模拟上传进度
            for (i in 1..10) {
                onProgress(i / 10f)
                kotlinx.coroutines.delay(300)
            }
            
            if (response.isSuccessful && response.body() != null) {
                emit(Result.success(response.body()!!.data.videoId))
            } else {
                emit(Result.failure(Exception("上传失败: ${response.errorBody()?.string()}")))
            }
            
            // 删除临时文件
            videoFile.delete()
            thumbFile?.delete()
            
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun uploadArticleWithImages(
        title: String,
        content: String,
        tags: List<String>,
        imageUris: List<Uri>,
        coverUri: Uri?,
        isPublic: Boolean,
        onProgress: (Float) -> Unit
    ): Flow<Result<String>> = flow {
        try {
            val imageFiles = imageUris.map { createTempFileFromUri(context, it) }
            val coverFile = coverUri?.let { createTempFileFromUri(context, it) }

            val imageParts = imageFiles.map { file ->
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("images", file.name, body)
            }
            val coverPart: MultipartBody.Part? = coverFile?.let { file ->
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("cover", file.name, body)
            }

            val typeBody: RequestBody = "article".toRequestBody("text/plain".toMediaTypeOrNull())
            val titleBody: RequestBody? = title.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
            val contentBody: RequestBody? = content.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
            val tagsBody: RequestBody? = tags.joinToString(",").toRequestBody("text/plain".toMediaTypeOrNull())
            val isPublicBody: RequestBody = isPublic.toString().toRequestBody("text/plain".toMediaTypeOrNull())

            val response = postApiService.uploadPost(
                type = typeBody,
                images = if (imageParts.isEmpty()) null else imageParts,
                audio = null,
                cover = coverPart,
                title = titleBody,
                content = contentBody,
                description = null,
                tags = tagsBody,
                isPublic = isPublicBody
            )

            // 模拟进度
            for (i in 1..10) { onProgress(i / 10f); kotlinx.coroutines.delay(200) }

            if (response.isSuccessful && response.body() != null) {
                emit(Result.success(response.body()!!.data.postId))
            } else {
                emit(Result.failure(Exception("发布失败: ${response.errorBody()?.string()}")))
            }

            imageFiles.forEach { it.delete() }
            coverFile?.delete()
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun uploadImagesOnly(
        title: String,
        description: String,
        tags: List<String>,
        imageUris: List<Uri>,
        coverUri: Uri?,
        isPublic: Boolean,
        onProgress: (Float) -> Unit
    ): Flow<Result<String>> = flow {
        try {
            val imageFiles = imageUris.map { createTempFileFromUri(context, it) }
            val coverFile = coverUri?.let { createTempFileFromUri(context, it) }

            val imageParts = imageFiles.map { file ->
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("images", file.name, body)
            }
            val coverPart: MultipartBody.Part? = coverFile?.let { file ->
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("cover", file.name, body)
            }

            val typeBody = "images".toRequestBody("text/plain".toMediaTypeOrNull())
            val titleBody = title.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
            val descBody = description.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
            val tagsBody = tags.joinToString(",").toRequestBody("text/plain".toMediaTypeOrNull())
            val isPublicBody = isPublic.toString().toRequestBody("text/plain".toMediaTypeOrNull())

            val response = postApiService.uploadPost(
                type = typeBody,
                images = if (imageParts.isEmpty()) null else imageParts,
                audio = null,
                cover = coverPart,
                title = titleBody,
                content = null,
                description = descBody,
                tags = tagsBody,
                isPublic = isPublicBody
            )

            for (i in 1..10) { onProgress(i / 10f); kotlinx.coroutines.delay(150) }

            if (response.isSuccessful && response.body() != null) {
                emit(Result.success(response.body()!!.data.postId))
            } else {
                emit(Result.failure(Exception("发布失败: ${response.errorBody()?.string()}")))
            }

            imageFiles.forEach { it.delete() }
            coverFile?.delete()
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun uploadMusic(
        audioUri: Uri,
        coverUri: Uri?,
        title: String,
        description: String,
        tags: List<String>,
        isPublic: Boolean,
        onProgress: (Float) -> Unit
    ): Flow<Result<String>> = flow {
        try {
            val audioFile = createTempFileFromUri(context, audioUri)
            val coverFile = coverUri?.let { createTempFileFromUri(context, it) }

            val audioPart = MultipartBody.Part.createFormData(
                "audio",
                audioFile.name,
                audioFile.asRequestBody("audio/*".toMediaTypeOrNull())
            )
            val coverPart: MultipartBody.Part? = coverFile?.let { file ->
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("cover", file.name, body)
            }

            val typeBody = "music".toRequestBody("text/plain".toMediaTypeOrNull())
            val titleBody = title.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
            val descBody = description.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
            val tagsBody = tags.joinToString(",").toRequestBody("text/plain".toMediaTypeOrNull())
            val isPublicBody = isPublic.toString().toRequestBody("text/plain".toMediaTypeOrNull())

            val response = postApiService.uploadPost(
                type = typeBody,
                images = null,
                audio = audioPart,
                cover = coverPart,
                title = titleBody,
                content = null,
                description = descBody,
                tags = tagsBody,
                isPublic = isPublicBody
            )

            for (i in 1..10) { onProgress(i / 10f); kotlinx.coroutines.delay(200) }

            if (response.isSuccessful && response.body() != null) {
                emit(Result.success(response.body()!!.data.postId))
            } else {
                emit(Result.failure(Exception("发布失败: ${response.errorBody()?.string()}")))
            }

            audioFile.delete()
            coverFile?.delete()
        } catch (e: Exception) {
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun updatePost(
        postId: String,
        type: String,
        newImageUris: List<Uri>?,
        newAudioUri: Uri?,
        newCoverUri: Uri?,
        title: String?,
        content: String?,
        description: String?,
        tags: List<String>?,
        isPublic: Boolean?,
        onProgress: (Float) -> Unit
    ): Flow<Result<Boolean>> = flow {
        // 统一构建请求体（仅在非空时提供）
        val typeBody = type.toRequestBody("text/plain".toMediaTypeOrNull())
        val titleBody = title?.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
        val contentBody = content?.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
        val descBody = description?.takeIf { it.isNotBlank() }?.toRequestBody("text/plain".toMediaTypeOrNull())
        val tagsBody = tags?.let { it.joinToString(",") }?.toRequestBody("text/plain".toMediaTypeOrNull())
        val isPublicBody = isPublic?.toString()?.toRequestBody("text/plain".toMediaTypeOrNull())

        var tempFiles: MutableList<File> = mutableListOf()
        try {
            val imageParts: List<MultipartBody.Part>? = newImageUris?.takeIf { it.isNotEmpty() }?.map { uri ->
                val f = createTempFileFromUri(context, uri)
                tempFiles.add(f)
                val body = f.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("images", f.name, body)
            }

            val audioPart: MultipartBody.Part? = newAudioUri?.let { uri ->
                val f = createTempFileFromUri(context, uri)
                tempFiles.add(f)
                MultipartBody.Part.createFormData("audio", f.name, f.asRequestBody("audio/*".toMediaTypeOrNull()))
            }

            val coverPart: MultipartBody.Part? = newCoverUri?.let { uri ->
                val f = createTempFileFromUri(context, uri)
                tempFiles.add(f)
                MultipartBody.Part.createFormData("cover", f.name, f.asRequestBody("image/*".toMediaTypeOrNull()))
            }

            val response = postApiService.updatePost(
                postId = postId,
                type = typeBody,
                images = imageParts,
                audio = audioPart,
                cover = coverPart,
                title = titleBody,
                content = contentBody,
                description = descBody,
                tags = tagsBody,
                isPublic = isPublicBody
            )

            for (i in 1..10) { onProgress(i / 10f); kotlinx.coroutines.delay(100) }

            if (response.isSuccessful) {
                emit(Result.success(true))
            } else {
                emit(Result.failure(Exception("编辑失败: ${response.errorBody()?.string()}")))
            }
        } catch (e: Exception) {
            emit(Result.failure(e))
        } finally {
            tempFiles.forEach { runCatching { it.delete() } }
        }
    }.flowOn(Dispatchers.IO)

    private fun createTempFileFromUri(context: Context, uri: Uri): File {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw Exception("无法打开文件")

        val mime = context.contentResolver.getType(uri)
        val suffix = when {
            mime?.startsWith("video") == true -> ".mp4"
            mime?.startsWith("image") == true -> ".jpg"
            mime?.startsWith("audio") == true -> ".mp3"
            else -> ".bin"
        }

        val tempFile = File.createTempFile("upload_", suffix, context.cacheDir)

        FileOutputStream(tempFile).use { outputStream ->
            val buffer = ByteArray(4 * 1024) // 4KB buffer
            var read: Int
            while (inputStream.read(buffer).also { read = it } != -1) {
                outputStream.write(buffer, 0, read)
            }
            outputStream.flush()
        }

        inputStream.close()
        return tempFile
    }
}
