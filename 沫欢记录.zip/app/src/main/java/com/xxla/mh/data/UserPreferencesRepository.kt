package com.xxla.mh.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object PreferencesKeys {
        val USER_ID = stringPreferencesKey("user_id")
        val USERNAME = stringPreferencesKey("username")
        val EMAIL = stringPreferencesKey("email")
        val AVATAR = stringPreferencesKey("avatar")
        val NICKNAME = stringPreferencesKey("nickname")
        val SIGNATURE = stringPreferencesKey("signature")
        val LEVEL = intPreferencesKey("level")
        val UID = stringPreferencesKey("uid")
        val FOLLOWING_COUNT = intPreferencesKey("following_count")
        val FOLLOWERS_COUNT = intPreferencesKey("followers_count")
        val LIKES_COUNT = intPreferencesKey("likes_count")
        val VIDEOS_COUNT = intPreferencesKey("videos_count")
        val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        val TOKEN = stringPreferencesKey("token")
        // 主题模式：default / dark
        val THEME_MODE = stringPreferencesKey("theme_mode")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val userId = preferences[PreferencesKeys.USER_ID] ?: ""
            val username = preferences[PreferencesKeys.USERNAME] ?: ""
            val email = preferences[PreferencesKeys.EMAIL] ?: ""
            val avatar = preferences[PreferencesKeys.AVATAR]
            val nickname = preferences[PreferencesKeys.NICKNAME]
            val signature = preferences[PreferencesKeys.SIGNATURE]
            val level = preferences[PreferencesKeys.LEVEL] ?: 1
            val uid = preferences[PreferencesKeys.UID] ?: ""
            val followingCount = preferences[PreferencesKeys.FOLLOWING_COUNT] ?: 0
            val followersCount = preferences[PreferencesKeys.FOLLOWERS_COUNT] ?: 0
            val likesCount = preferences[PreferencesKeys.LIKES_COUNT] ?: 0
            val videosCount = preferences[PreferencesKeys.VIDEOS_COUNT] ?: 0
            val isLoggedIn = preferences[PreferencesKeys.IS_LOGGED_IN] ?: false
            val token = preferences[PreferencesKeys.TOKEN]
            val themeMode = preferences[PreferencesKeys.THEME_MODE] ?: "default"

            UserPreferences(
                userId = userId,
                username = username,
                email = email,
                avatar = avatar,
                nickname = nickname,
                signature = signature,
                level = level,
                uid = uid,
                followingCount = followingCount,
                followersCount = followersCount,
                likesCount = likesCount,
                videosCount = videosCount,
                isLoggedIn = isLoggedIn,
                token = token,
                themeMode = themeMode
            )
        }

    suspend fun saveUserLogin(user: User, token: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.USER_ID] = user.id
            preferences[PreferencesKeys.USERNAME] = user.username
            preferences[PreferencesKeys.EMAIL] = user.email
            user.avatar?.let { preferences[PreferencesKeys.AVATAR] = it }
            user.nickname?.let { preferences[PreferencesKeys.NICKNAME] = it }
            user.signature?.let { preferences[PreferencesKeys.SIGNATURE] = it }
            preferences[PreferencesKeys.LEVEL] = user.level
            preferences[PreferencesKeys.UID] = user.uid
            preferences[PreferencesKeys.FOLLOWING_COUNT] = user.followingCount
            preferences[PreferencesKeys.FOLLOWERS_COUNT] = user.followersCount
            preferences[PreferencesKeys.LIKES_COUNT] = user.likesCount
            preferences[PreferencesKeys.VIDEOS_COUNT] = user.videosCount
            preferences[PreferencesKeys.IS_LOGGED_IN] = true
            preferences[PreferencesKeys.TOKEN] = token
        }
    }

    suspend fun clearUserData() {
        context.dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    suspend fun updateAvatar(avatarUrl: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.AVATAR] = avatarUrl
        }
    }

    // 主题模式相关
    val themeModeFlow: Flow<String> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.THEME_MODE] ?: "default"
        }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = mode
        }
    }
}

data class UserPreferences(
    val userId: String = "",
    val username: String = "",
    val email: String = "",
    val avatar: String? = null,
    val nickname: String? = null,
    val signature: String? = null,
    val level: Int = 1,
    val uid: String = "",
    val followingCount: Int = 0,
    val followersCount: Int = 0,
    val likesCount: Int = 0,
    val videosCount: Int = 0,
    val isLoggedIn: Boolean = false,
    val token: String? = null,
    val themeMode: String = "default"
)

data class User(
    val id: String,
    val username: String,
    val email: String,
    val avatar: String? = null,
    val nickname: String? = null,
    val signature: String? = null,
    val level: Int = 1,
    val uid: String = "",
    val followingCount: Int = 0,
    val followersCount: Int = 0,
    val likesCount: Int = 0,
    val videosCount: Int = 0
)
