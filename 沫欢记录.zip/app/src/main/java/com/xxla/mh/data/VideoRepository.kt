package com.xxla.mh.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import com.xxla.mh.network.VideoApiService
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody

@Singleton
class VideoRepository @Inject constructor(
    private val videoApiService: VideoApiService,
    @ApplicationContext private val context: Context
) {
    // 获取视频列表（真实接口）
    suspend fun getVideos(
        page: Int,
        size: Int,
        category: String? = null,
        noRetry: Boolean = false
    ) = videoApiService.getVideos(page, size, category, if (noRetry) "true" else null)

    // 点赞/取消点赞
    suspend fun toggleLike(videoId: String): Boolean {
        return try {
            // 这里应该根据当前视频的点赞状态决定是点赞还是取消点赞
            // 简化处理，默认调用点赞接口
            val response = videoApiService.likeVideo(videoId)
            response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 点赞视频
    suspend fun likeVideo(videoId: String): Boolean {
        return try {
            videoApiService.likeVideo(videoId).isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 取消点赞视频
    suspend fun unlikeVideo(videoId: String): Boolean {
        return try {
            videoApiService.unlikeVideo(videoId).isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 分享视频
    fun shareVideo(videoId: String) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "https://yourdomain.com/video/$videoId")
            type = "text/plain"
        }
        
        val shareChooser = Intent.createChooser(shareIntent, "分享视频")
        shareChooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(shareChooser)
    }

    // 获取视频评论
    suspend fun getVideoComments(videoId: String, page: Int, size: Int) = 
        videoApiService.getComments(videoId, page, size)

    // 发表评论（支持可选父评论ID）
    suspend fun postComment(videoId: String, content: String, parentId: String? = null) = 
        videoApiService.postComment(videoId, com.xxla.mh.network.CommentRequest(content, parentId))

    // 点赞评论
    suspend fun likeComment(videoId: String, commentId: String) =
        videoApiService.likeComment(videoId, commentId)

    // 取消点赞评论
    suspend fun unlikeComment(videoId: String, commentId: String) =
        videoApiService.unlikeComment(videoId, commentId)

    // 删除评论（视频）
    suspend fun deleteComment(videoId: String, commentId: String): Boolean {
        return try {
            videoApiService.deleteComment(videoId, commentId).isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 获取视频弹幕
    suspend fun getVideoDanmaku(videoId: String) = 
        videoApiService.getDanmaku(videoId)

    // 发送弹幕
    suspend fun sendDanmaku(videoId: String, content: String, time: Float, color: String, type: Int) = 
        videoApiService.sendDanmaku(videoId, com.xxla.mh.network.DanmakuRequest(content, time, color, type))

    // 删除视频
    suspend fun deleteVideo(videoId: String): Boolean {
        return try {
            videoApiService.deleteVideo(videoId).isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    // 获取视频详情
    suspend fun getVideoDetail(videoId: String) = videoApiService.getVideoDetail(videoId)

    // 记录唯一播放，返回最新播放量（失败返回 null）
    suspend fun recordVideoView(videoId: String): Int? {
        return try {
            val resp = videoApiService.recordView(videoId)
            if (resp.isSuccessful) {
                resp.body()?.data?.viewCount
            } else null
        } catch (e: Exception) {
            null
        }
    }

    // 更新视频（可选替换视频/封面）
    suspend fun updateVideo(
        videoId: String,
        title: String?,
        description: String?,
        tags: List<String>?,
        isPublic: Boolean?,
        newVideoUri: Uri?,
        newThumbnailUri: Uri?
    ): com.xxla.mh.network.VideoDetail? {
        return try {
            val titleBody: RequestBody? = title?.toRequestBody("text/plain".toMediaTypeOrNull())
            val descBody: RequestBody? = description?.toRequestBody("text/plain".toMediaTypeOrNull())
            val tagsBody: RequestBody? = tags?.joinToString(",")?.toRequestBody("text/plain".toMediaTypeOrNull())
            val isPublicBody: RequestBody? = isPublic?.toString()?.toRequestBody("text/plain".toMediaTypeOrNull())

            val videoPart: MultipartBody.Part? = newVideoUri?.let { uri ->
                val temp = createTempFileFromUri(uri, "video.mp4")
                val body = temp.asRequestBody("video/mp4".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("video", temp.name, body)
            }
            val thumbPart: MultipartBody.Part? = newThumbnailUri?.let { uri ->
                val temp = createTempFileFromUri(uri, "thumbnail.jpg")
                val body = temp.asRequestBody("image/*".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("thumbnail", temp.name, body)
            }

            val resp = videoApiService.updateVideo(
                videoId,
                titleBody,
                descBody,
                tagsBody,
                thumbPart,
                isPublicBody,
                videoPart
            )
            if (resp.isSuccessful) resp.body()?.data else null
        } catch (e: Exception) {
            null
        }
    }

    private fun createTempFileFromUri(uri: Uri, defaultName: String): File {
        val inputStream: InputStream = context.contentResolver.openInputStream(uri)!!
        val cacheDir = File(context.cacheDir, "uploads")
        if (!cacheDir.exists()) cacheDir.mkdirs()
        val outFile = File(cacheDir, defaultName)
        FileOutputStream(outFile).use { out ->
            inputStream.copyTo(out)
        }
        inputStream.close()
        return outFile
    }
}
