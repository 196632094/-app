package com.xxla.mh.data

import com.xxla.mh.network.WatchApiService
import com.xxla.mh.network.WatchHeartbeatRequest
import com.xxla.mh.network.WatchStartRequest
import com.xxla.mh.network.WatchStopRequest
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WatchRepository @Inject constructor(
    private val api: WatchApiService
) {
    suspend fun start(contentKey: String): Boolean {
        val resp = api.start(WatchStartRequest(contentKey))
        return resp.isSuccessful && (resp.body()?.success == true)
    }

    suspend fun stop(contentKey: String): Boolean {
        val resp = api.stop(WatchStopRequest(contentKey))
        return resp.isSuccessful && (resp.body()?.success == true)
    }

    suspend fun heartbeat(contentKey: String): Boolean {
        val resp = api.heartbeat(WatchHeartbeatRequest(contentKey))
        return resp.isSuccessful && (resp.body()?.success == true)
    }

    suspend fun online(contentKey: String): Pair<Int, List<String>> {
        val resp = api.online(contentKey)
        if (resp.isSuccessful) {
            val data = resp.body()?.data
            return Pair(data?.onlineCount ?: 0, data?.userIds ?: emptyList())
        }
        return 0 to emptyList()
    }

    /**
     * 轮询在线人数（默认 5s 一次）。注意：调用者负责取消 Flow 以停止轮询。
     */
    fun pollOnline(contentKey: String, intervalMs: Long = 5000L): Flow<Pair<Int, List<String>>> = flow {
        while (true) {
            emit(online(contentKey))
            delay(intervalMs)
        }
    }
}

