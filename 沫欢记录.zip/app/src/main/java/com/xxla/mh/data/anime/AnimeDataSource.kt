package com.xxla.mh.data.anime

interface AnimeDataSource {
    suspend fun search(keyword: String): List<AnimeSubject>
    suspend fun getDetail(detailUrl: String): AnimeDetail
    suspend fun resolvePlay(episodeUrl: String): PlayInfo
}

