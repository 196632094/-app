package com.xxla.mh.data.anime

data class AnimeSubject(
    val title: String,
    val detailUrl: String
)

data class AnimeEpisode(
    val sort: String?,
    val name: String,
    val url: String
)

data class AnimeChannel(
    val name: String,
    val episodes: List<AnimeEpisode>
)

data class AnimeDetail(
    val title: String,
    val coverUrl: String?,
    val channels: List<AnimeChannel>
)

data class PlayInfo(
    val videoUrl: String,
    val headers: Map<String, String> = emptyMap()
)

// 用于将多线路的同一集进行整合
data class EpisodeSource(
    val channelName: String,
    val episode: AnimeEpisode
)

data class AggregatedEpisode(
    val key: String,            // 归一化后的剧集键（优先使用 sort 或数字）
    val title: String,          // 展示用标题（来自某个源的 name）
    val sources: List<EpisodeSource> // 不同线路的同一剧集
)
