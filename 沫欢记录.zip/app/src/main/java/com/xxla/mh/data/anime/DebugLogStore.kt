package com.xxla.mh.data.anime

object DebugLogStore {
    private val buffer = StringBuilder()

    @Synchronized
    fun clear() {
        buffer.setLength(0)
    }

    @Synchronized
    fun append(message: String) {
        buffer.append(message).append('\n')
    }

    @Synchronized
    fun dump(): String = buffer.toString()
}

