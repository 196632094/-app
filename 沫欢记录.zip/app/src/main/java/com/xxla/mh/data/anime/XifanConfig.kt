package com.xxla.mh.data.anime

import android.content.Context
import com.google.gson.Gson
import com.xxla.mh.R

data class XifanConfig(
    val mediaSources: List<MediaSource>
)

data class MediaSource(
    val factoryId: String,
    val version: Int?,
    val arguments: Arguments
)

data class Arguments(
    val name: String?,
    val description: String?,
    val iconUrl: String?,
    val searchConfig: SearchConfig,
    val tier: Int?
)

data class SearchConfig(
    val searchUrl: String,
    val searchUseOnlyFirstWord: Boolean? = null,
    val searchRemoveSpecial: Boolean? = null,
    val rawBaseUrl: String?,
    val subjectFormatId: String?,
    val selectorSubjectFormatIndexed: SelectorSubjectFormatIndexed?,
    val selectorSubjectFormatA: SelectorSubjectFormatA?,
    val selectorSubjectFormatJsonPathIndexed: SelectorSubjectFormatJsonPathIndexed?,
    val channelFormatId: String?,
    val selectorChannelFormatFlattened: SelectorChannelFormatFlattened?,
    val selectorChannelFormatNoChannel: SelectorChannelFormatNoChannel?,
    val matchVideo: MatchVideo?
)

data class SelectorSubjectFormatIndexed(
    val selectNames: String?,
    val selectLinks: String?,
    val preferShorterName: Boolean?
)

data class SelectorSubjectFormatA(
    val selectLists: String?,
    val preferShorterName: Boolean?
)

data class SelectorSubjectFormatJsonPathIndexed(
    val selectLinks: String?,
    val selectNames: String?,
    val preferShorterName: Boolean?
)

data class SelectorChannelFormatFlattened(
    val selectChannelNames: String?,
    val selectEpisodesFromList: String?,
    val selectEpisodeLinksFromList: String?,
    val matchChannelName: String?,
    val matchEpisodeSortFromName: String?
)

data class SelectorChannelFormatNoChannel(
    val selectEpisodes: String?,
    val selectEpisodeLinks: String?,
    val matchEpisodeSortFromName: String?
)

data class MatchVideo(
    val enableNestedUrl: Boolean?,
    val matchNestedUrl: String?,
    val matchVideoUrl: String?,
    val cookies: String?,
    val addHeadersToVideo: Map<String, String>?
)

object XifanConfigLoader {
    fun load(context: Context): SearchConfig {
        val input = context.resources.openRawResource(R.raw.xifan)
        val json = input.bufferedReader().use { it.readText() }
        val cfg = Gson().fromJson(json, XifanConfig::class.java)
        return cfg.mediaSources.first().arguments.searchConfig
    }
}
