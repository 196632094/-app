package com.xxla.mh.data.anime

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import dagger.hilt.android.qualifiers.ApplicationContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.net.URLEncoder
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Singleton
class XifanDataSource @Inject constructor(
    @ApplicationContext private val context: Context,
    @Named("externalHttp") private val okHttpClient: OkHttpClient
) : AnimeDataSource {

    private val cfg: SearchConfig by lazy { XifanConfigLoader.load(context) }

    private val defaultHeaders: Map<String, String> by lazy {
        val mv = cfg.matchVideo
        val h = (mv?.addHeadersToVideo ?: emptyMap()).toMutableMap()
        // 兜底 UA/Referer
        if (!h.containsKey("userAgent")) h["userAgent"] = "Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0 Mobile Safari/537.36"
        if (!h.containsKey("referer")) h["referer"] = cfg.rawBaseUrl ?: "https://dm.xifanacg.com"
        h
    }

    override suspend fun search(keyword: String): List<AnimeSubject> {
        // 查询预处理：仅取首词、移除特殊字符
        val raw = keyword.trim()
        var q = raw
        if (cfg.searchUseOnlyFirstWord == true) {
            q = raw.split(Regex("\\s+"), limit = 2).firstOrNull().orEmpty()
        }
        if (cfg.searchRemoveSpecial == true) {
            q = q.replace(Regex("[^\\p{L}\\p{N}\\s]"), "")
        }
        if (q.isBlank()) return emptyList()

        val encoded = URLEncoder.encode(q, "UTF-8")
        val url = cfg.searchUrl.replace("{keyword}", encoded)
        debugLog("search url='" + url + "' q='" + q + "'")
        val html = httpGet(url)
        val doc = Jsoup.parse(html, cfg.rawBaseUrl)
        debugLog("doc.title='" + doc.title() + "'")

        // 优先使用 Indexed 选择器
        val namesSelector = cfg.selectorSubjectFormatIndexed?.selectNames
        val linksSelector = cfg.selectorSubjectFormatIndexed?.selectLinks
        val results = mutableListOf<AnimeSubject>()
        if (!namesSelector.isNullOrBlank() && !linksSelector.isNullOrBlank()) {
            val names = doc.select(namesSelector)
            val links = doc.select(linksSelector)
            debugLog("indexed selectors names=" + names.size + ", links=" + links.size)
            val count = minOf(names.size, links.size)
            for (i in 0 until count) {
                val name = names[i].text().trim()
                val href = links[i].attr("href")
                val abs = links[i].absUrl("href").ifBlank { href }
                if (name.isNotBlank() && abs.isNotBlank()) {
                    results += AnimeSubject(name, abs)
                }
            }
        }

        // 回退：A 列表选择器（直接选中 a 标签）
        if (results.isEmpty()) {
            val listsSel = cfg.selectorSubjectFormatA?.selectLists
            if (!listsSel.isNullOrBlank()) {
                val anchors = doc.select(listsSel)
                debugLog("alist anchors=" + anchors.size)
                for (a in anchors) {
                    val name = a.text().trim()
                    val href = a.attr("href")
                    val abs = a.absUrl("href").ifBlank { href }
                    if (name.isNotBlank() && abs.isNotBlank()) {
                        results += AnimeSubject(name, abs)
                    }
                }
            }
        }

        // 额外回退：适配站点 .public-list-box 结构（标题在 .thumb-txt，链接为其中的 <a>）
        if (results.isEmpty()) {
            val boxes = doc.select(".public-list-box")
            debugLog("public-list-box count=" + boxes.size)
            for (box in boxes) {
                // 标题：优先 .thumb-txt，其次图片 alt 文本（去除“封面图”后缀）
                var title = box.selectFirst(".thumb-txt")?.text()?.trim().orEmpty()
                if (title.isBlank()) {
                    val alt = box.selectFirst("img[alt]")?.attr("alt")?.trim().orEmpty()
                    if (alt.isNotBlank()) {
                        title = alt.replace(Regex("[\\s-]*封面图$"), "").trim()
                    }
                }
                // 链接：优先 .public-list-exp 内的 a[href]，其次 a.public-list-exp[href]，最后盒子内任何指向 bangumi 的 a
                val linkEl = box.selectFirst(".public-list-exp a[href]")
                    ?: box.selectFirst("a.public-list-exp[href]")
                    ?: box.selectFirst("a[href*='/bangumi/']")
                val href = linkEl?.attr("href").orEmpty()
                val abs = if (href.startsWith("http")) href else linkEl?.absUrl("href").orEmpty().ifBlank { href }
                val looksDetail = Regex("/bangumi/\\d+\\.html").containsMatchIn(abs)
                if (title.isNotBlank() && abs.isNotBlank() && looksDetail) {
                    results += AnimeSubject(title, abs)
                }
            }
        }

        // 最后兜底：直接抓取页面内所有指向 bangumi 详情的链接
        if (results.isEmpty()) {
            val anchors = doc.select("a[href*='/bangumi/']")
            debugLog("fallback anchors(bangumi)=" + anchors.size)
            for (a in anchors) {
                val href = a.attr("href")
                val abs = a.absUrl("href").ifBlank { href }
                var name = a.text().trim()
                if (name.isBlank()) {
                    name = a.selectFirst("img[alt]")?.attr("alt")?.trim().orEmpty()
                }
                if (name.isNotBlank() && abs.isNotBlank()) {
                    results += AnimeSubject(name, abs)
                }
            }
        }

        // 去重（依据 URL）
        val dedup = LinkedHashMap<String, AnimeSubject>()
        results.forEach { s -> dedup.putIfAbsent(s.detailUrl, s) }
        val final = dedup.values.toList()
        debugLog("final results=" + final.size)
        return final
    }

    override suspend fun getDetail(detailUrl: String): AnimeDetail {
        val html = httpGet(detailUrl)
        val doc = Jsoup.parse(html, cfg.rawBaseUrl)
        debugLog("getDetail url=" + detailUrl)
        debugLog("getDetail doc.title=" + doc.title())
        
        val title = runCatching {
            doc.selectFirst("h1, .video-info-header h1, .module-info-heading h1")?.text()?.trim()
                ?: doc.title().orEmpty()
        }.getOrDefault(doc.title().orEmpty())
        val cover = runCatching {
            doc.selectFirst("meta[property=og:image]")?.attr("content")
        }.getOrNull()

        // 优先按无频道选择器解析（常见站点）
        val noChannelSel = cfg.selectorChannelFormatNoChannel?.selectEpisodes
        debugLog("getDetail noChannelSel=" + noChannelSel)
        val episodes: List<AnimeEpisode> = if (!noChannelSel.isNullOrBlank()) {
            val selectedElements = doc.select(noChannelSel)
            debugLog("getDetail selected episodes count=" + selectedElements.size)
            selectedElements.mapNotNull { a ->
                val name = a.text().trim()
                val href = a.attr("href")
                val abs = a.absUrl("href").ifBlank { href }
                val sort = matchByRegex(cfg.selectorChannelFormatNoChannel?.matchEpisodeSortFromName, name)
                debugLog("getDetail episode: name='$name', href='$href', abs='$abs'")
                if (abs.isNotBlank()) AnimeEpisode(sort, name, abs) else null
            }
        } else emptyList()

        val channels = if (episodes.isNotEmpty()) {
            debugLog("getDetail using configured episodes, count=" + episodes.size)
            listOf(AnimeChannel(name = "全部", episodes = episodes))
        } else {
            // 退化：尝试全局抓取可能的剧集链接
            debugLog("getDetail fallback to all links")
            val fallbackEpisodes = doc.select("a").mapNotNull { a ->
                val href = a.attr("href")
                val abs = a.absUrl("href").ifBlank { href }
                val text = a.text().trim()
                if (text.isNotBlank() && (abs.contains("/play") || abs.contains(".html"))) {
                    debugLog("getDetail fallback episode: text='$text', abs='$abs'")
                    AnimeEpisode(null, text, abs)
                } else null
            }
            debugLog("getDetail fallback episodes count=" + fallbackEpisodes.size)
            listOf(AnimeChannel(name = "全部", episodes = fallbackEpisodes))
        }

        return AnimeDetail(title = title, coverUrl = cover, channels = channels)
    }

    override suspend fun resolvePlay(episodeUrl: String): PlayInfo {
        runCatching { DebugLogStore.clear() }.onFailure { }
        val mv = cfg.matchVideo
        debugLog("resolvePlay episodeUrl=" + episodeUrl)
        val pageHtml = httpGet(episodeUrl)
        debugLog("resolvePlay pageHtml length=" + pageHtml.length)
        var targetHtml = pageHtml

        // 1) 先用 DOM 解析可能的 iframe src（常见站点通过 iframe 中转）
        var fromIframes: String? = null
        runCatching {
            val doc0 = Jsoup.parse(pageHtml, cfg.rawBaseUrl)
            val iframes = doc0.select("iframe[src]")
            debugLog("resolvePlay iframe count=" + iframes.size)
            for (iframe in iframes) {
                val src = iframe.attr("src")
                if (src.isNullOrBlank()) continue
                val iframeAbs = if (src.startsWith("http")) src else (cfg.rawBaseUrl.orEmpty().trimEnd('/') + "/" + src.trimStart('/'))
                debugLog("resolvePlay iframe url=" + iframeAbs)
                val ih = httpGet(iframeAbs)
                if (ih.isBlank()) continue
                val iframeDoc = Jsoup.parse(ih, cfg.rawBaseUrl)
                // 在 iframe 中查找 video
                val videoEl = iframeDoc.select("video").firstOrNull()
                if (videoEl != null) {
                    val sourceEl = videoEl.selectFirst("source[src]")
                    val s1 = sourceEl?.attr("src")
                    val c1 = s1?.let { if (it.startsWith("http")) it else sourceEl?.absUrl("src").orEmpty().ifBlank { it } }
                    debugLog("resolvePlay iframe source src=" + c1)
                    if (!c1.isNullOrBlank() && looksLikeVideo(c1)) { fromIframes = c1; break }

                    val vsrc = videoEl.attr("src")
                    val c2 = if (vsrc.startsWith("http")) vsrc else videoEl.absUrl("src").ifBlank { vsrc }
                    debugLog("resolvePlay iframe video src=" + c2)
                    if (!c2.isNullOrBlank() && looksLikeVideo(c2)) { fromIframes = c2; break }
                }

                // 兜底：直接寻找第一条 source/video 的 src
                val tag = iframeDoc.select("source[src], video[src]").firstOrNull()
                val raw = tag?.attr("src")
                val abs = raw?.let { if (it.startsWith("http")) it else tag?.absUrl("src").orEmpty().ifBlank { it } }
                debugLog("resolvePlay iframe tag src=" + abs)
                if (!abs.isNullOrBlank() && looksLikeVideo(abs)) { fromIframes = abs; break }

                // 若未找到直链，保留第一个 iframe 的 HTML 作为 targetHtml 继续后续解析
                if (targetHtml === pageHtml) {
                    targetHtml = ih
                    debugLog("resolvePlay nested html length=" + ih.length)
                }
            }
        }.onFailure {
            debugLog("resolvePlay iframe parse failed=" + (it.message ?: it.toString()))
        }

        // 2) 仍未命中 iframe，则按配置的正则尝试抓取嵌套 URL（改为更鲁棒的模式）
        debugLog("resolvePlay enableNestedUrl=" + mv?.enableNestedUrl + ", matchNestedUrl=" + mv?.matchNestedUrl)
        if (mv?.enableNestedUrl == true && targetHtml === pageHtml) {
            val nested = matchByRegex(mv?.matchNestedUrl, pageHtml)
            debugLog("resolvePlay nested regex group1=" + nested)
            if (!nested.isNullOrBlank()) {
                val nestedAbs = if (nested.startsWith("http")) nested else (cfg.rawBaseUrl.orEmpty().trimEnd('/') + "/" + nested.trimStart('/'))
                debugLog("resolvePlay fetching nested url=" + nestedAbs)
                val nh = httpGet(nestedAbs)
                if (nh.isNotBlank()) {
                    targetHtml = nh
                    debugLog("resolvePlay nested html length=" + nh.length)
                }
            }
        }

        // 2.5) 解析页面中的 JavaScript 变量 player_aaaa，直接提取 url，并校验剧集号（参考 py 实现）
        val playerInfo = tryExtractPlayerAaaaInfo(targetHtml)
            ?: tryExtractPlayerAaaaInfo(pageHtml)
        var expectedEp = extractEpisodeNumber(episodeUrl)
        if (expectedEp.isNullOrBlank()) {
            expectedEp = deriveEpisodeNumberFromPage(pageHtml, episodeUrl)
            debugLog("resolvePlay expectedEp(fallback)=" + expectedEp)
        }
        val fromPlayerAaaa = playerInfo?.let { info ->
            val idMatches = info.id?.let { it == expectedEp } ?: false
            val urlMatches = validateEpisodeInUrl(info.url, expectedEp)
            debugLog("resolvePlay player_aaaa info.id=" + info.id + ", expectedEp=" + expectedEp)
            debugLog("resolvePlay player_aaaa info.url=" + info.url)
            if (idMatches || urlMatches) info.url else null
        }
        debugLog("resolvePlay fromPlayerAaaa(validated)=" + fromPlayerAaaa)

        val doc = Jsoup.parse(targetHtml, cfg.rawBaseUrl)
        // 方法3/4：XPath(CSS替代)与DOM精确定位 video/source
        val fromDomExact = runCatching { findVideoUrlByDom(doc) }.getOrNull()
        debugLog("resolvePlay fromDomExact=" + fromDomExact)
        // 先尝试 <video>/<source>
        val videoElements = doc.select("video, source")
        debugLog("resolvePlay found video/source elements=" + videoElements.size)
        val fromTags = runCatching {
            videoElements.firstOrNull { el ->
                val src = el.attr("src")
                debugLog("resolvePlay checking element src=" + src)
                src.endsWith(".m3u8") || src.endsWith(".mp4") || src.contains("m3u8")
            }?.let { el ->
                val raw = el.attr("src")
                if (raw.startsWith("http")) raw else el.absUrl("src").ifBlank { raw }
            }
        }.getOrNull()
        debugLog("resolvePlay fromTags=" + fromTags)

        // 方法2：基于剧集号精确匹配直链（支持 mp4/m3u8，包含URL编码）
        val fromEpVideo = matchVideoByEpisodeNumber(targetHtml, expectedEp)
        debugLog("resolvePlay fromEpVideo=" + fromEpVideo)

        val regex = mv?.matchVideoUrl?.let { Regex(it) }
        debugLog("resolvePlay matchVideoUrl pattern=" + mv?.matchVideoUrl)
        val fromRegex = if (fromTags == null && regex != null) {
            val match = regex.find(targetHtml)?.value
            debugLog("resolvePlay regex match=" + match)
            match
        } else null
        
        // 优先选择带剧集号的候选，避免偏集
        // 收集剧集上下文用于判断是否为最后一集
        val epCtx = getEpisodeContext(pageHtml, episodeUrl)
        val isLast = epCtx?.let {
            val gi = it.groupIndex
            val idx = it.indexInGroup
            gi >= 0 && idx >= 0 && idx == (it.groups.getOrNull(gi)?.size ?: 0) - 1
        } ?: false

        var videoUrlCandidate: String? = fromPlayerAaaa ?: fromEpVideo ?: fromIframes ?: fromDomExact ?: fromTags ?: fromRegex
        if (videoUrlCandidate.isNullOrBlank()) {
            if (!isLast) {
                // 非最后一集：优先尝试“下一集页面借链再矫正”
                val borrowed = borrowDirectLinkFromNextEpisode(epCtx, episodeUrl, expectedEp)
                if (!borrowed.isNullOrBlank()) {
                    videoUrlCandidate = borrowed
                    debugLog("resolvePlay borrow-next adjusted=" + videoUrlCandidate)
                } else {
                    // 兜底：尝试匹配常见 m3u8 链接
                    val fallback = Regex("""https?://[^"'\\s]+\.m3u8(?:\?[^"'\\s]*)?""").find(targetHtml)?.value
                    debugLog("resolvePlay fallback m3u8 match=" + fallback)
                    videoUrlCandidate = fallback
                }
            } else {
                // 最后一集：直接回退到同线路的上一集直链（不做矫正）
                val prevUrl = runCatching {
                    val gi = epCtx?.groupIndex ?: -1
                    val idx = epCtx?.indexInGroup ?: -1
                    val urls = if (gi >= 0) epCtx?.groups?.getOrNull(gi) ?: emptyList() else emptyList()
                    if (gi >= 0 && idx > 0) urls[idx - 1] else null
                }.getOrNull()
                debugLog("resolvePlay last-episode fallback prevUrl(same-line)=" + prevUrl)
                if (!prevUrl.isNullOrBlank()) {
                    val prevHtml = httpGet(prevUrl)
                    videoUrlCandidate = extractRawVideoFromHtml(prevHtml)
                    debugLog("resolvePlay last-episode raw from prev(same-line)=" + videoUrlCandidate)
                }
            }
        }

        // 最后一集逻辑已在上面分支处理（同线路回退上一集，不做矫正）

        // 非最后一集：若拿到候选直链，按所选剧集号替换链接中的集数（保持位数）
        if (!videoUrlCandidate.isNullOrBlank() && !isLast) {
            val adjusted = adjustEpisodeInUrl(videoUrlCandidate, expectedEp)
            if (!adjusted.isNullOrBlank()) {
                debugLog("resolvePlay adjusted candidate=" + adjusted)
                videoUrlCandidate = adjusted
            }
        }
        // 清理 JSON 转义与百分号编码
        var videoUrl: String = cleanUrl(videoUrlCandidate ?: episodeUrl)
        runCatching { videoUrl = URLDecoder.decode(videoUrl, "UTF-8") }.onFailure { }
        // 相对路径转绝对
        if (!videoUrl.startsWith("http")) {
            videoUrl = (cfg.rawBaseUrl.orEmpty().trimEnd('/') + "/" + videoUrl.trimStart('/'))
        }
        debugLog("resolvePlay final videoUrl=" + videoUrl)

        val headers = mutableMapOf<String, String>()
        defaultHeaders["referer"]?.let { headers["Referer"] = it }
        defaultHeaders["userAgent"]?.let { headers["User-Agent"] = it }
        mv?.cookies?.let { headers["Cookie"] = it }
        debugLog("resolvePlay headers=" + headers)

        return PlayInfo(videoUrl = videoUrl, headers = headers)
    }

    // 方法3/4：使用 XPath 提示的结构改为 CSS 精确选择 + DOM 遍历
    // 优先路径：html > body > div:nth-of-type(2) > div > video
    private fun findVideoUrlByDom(doc: org.jsoup.nodes.Document): String? {
        fun resolveFromVideo(videoEl: org.jsoup.nodes.Element?): String? {
            if (videoEl == null) return null
            val sourceEl = videoEl.selectFirst("source[src]")
            val s1 = sourceEl?.attr("src")
            if (!s1.isNullOrBlank()) return if (s1.startsWith("http")) s1 else sourceEl?.absUrl("src").orEmpty().ifBlank { s1 }
            val vsrc = videoEl.attr("src")
            if (!vsrc.isNullOrBlank()) return if (vsrc.startsWith("http")) vsrc else videoEl.absUrl("src").ifBlank { vsrc }
            val dataSrc = videoEl.attr("data-src")
            if (!dataSrc.isNullOrBlank()) return if (dataSrc.startsWith("http")) dataSrc else videoEl.absUrl("data-src").ifBlank { dataSrc }
            return null
        }

        return try {
            val target = doc.select("html > body > div:nth-of-type(2) > div > video").firstOrNull()
            val byPath = resolveFromVideo(target)
            debugLog("domExact byPath=" + byPath)
            if (!byPath.isNullOrBlank() && looksLikeVideo(byPath)) return byPath

            val allVideos = doc.select("video")
            debugLog("domExact videos count=" + allVideos.size)
            for (v in allVideos) {
                val candidate = resolveFromVideo(v)
                debugLog("domExact video candidate=" + candidate)
                if (!candidate.isNullOrBlank() && looksLikeVideo(candidate)) return candidate
            }

            val srcEl = doc.select("source[src]").firstOrNull()
            val s = srcEl?.attr("src")
            val abs = if (s?.startsWith("http") == true) s else srcEl?.absUrl("src").orEmpty().ifBlank { s.orEmpty() }
            debugLog("domExact first source src=" + abs)
            if (!abs.isNullOrBlank() && looksLikeVideo(abs)) return abs

            null
        } catch (e: Exception) {
            debugLog("domExact parse failed=" + (e.message ?: e.toString()))
            null
        }
    }

    // 方法2：基于剧集号精确匹配 MP4 链接（包含URL编码变体）
    private fun matchMp4ByEpisodeNumber(html: String, episodeUrl: String): String? {
        val epRaw = extractEpisodeNumber(episodeUrl) ?: return null
        val epPadded = epRaw.padStart(2, '0')
        val variants = listOf(epRaw, epPadded).distinct()
        for (ep in variants) {
            val p1 = Regex("https?://[^\\s\"']+?" + Regex.escape(ep) + "[^\\s\"']*?\\.mp4", RegexOption.IGNORE_CASE)
            val m1 = p1.find(html)?.value
            if (!m1.isNullOrBlank()) {
                val decoded = runCatching { java.net.URLDecoder.decode(m1, "UTF-8") }.getOrDefault(m1)
                return decoded
            }
            val encodedEp = runCatching { java.net.URLEncoder.encode(ep, "UTF-8") }.getOrDefault(ep)
            val p2 = Regex("https?://[^\\s\"']+?" + Regex.escape(encodedEp) + "[^\\s\"']*?\\.mp4", RegexOption.IGNORE_CASE)
            val m2 = p2.find(html)?.value
            if (!m2.isNullOrBlank()) {
                val decoded2 = runCatching { java.net.URLDecoder.decode(m2, "UTF-8") }.getOrDefault(m2)
                return decoded2
            }
        }
        return null
    }

    // 从剧集链接提取剧集号（watch/{bangumi}/{season}/{ep}.html）
    private fun extractEpisodeNumber(episodeUrl: String): String? {
        return runCatching {
            val m1 = Regex("/watch/\\d+/\\d+/(\\d+)\\.html").find(episodeUrl)
            val m2 = Regex("/watch/\\d+-\\d+-(\\d+)\\.html").find(episodeUrl)
            (m1 ?: m2)?.groupValues?.getOrNull(1)
        }.getOrNull()
    }

    // 当无法从 URL 中提取剧集号时，从播放页内的剧集列表或标题推断
    private fun deriveEpisodeNumberFromPage(html: String, episodeUrl: String): String? {
        return runCatching {
            val doc = Jsoup.parse(html, cfg.rawBaseUrl)
            val normEpisode = normalizeToPath(episodeUrl)
            val candidates = doc.select(".anthology-list-play a[href], .module-play-list a[href], a[href*='/watch/']")
            // 先尝试：链接匹配当前播放页 URL
            for (a in candidates) {
                val href = a.attr("href")
                val abs = if (href.startsWith("http")) href else a.absUrl("href").ifBlank { href }
                val normAbs = normalizeToPath(abs)
                if (normAbs == normEpisode) {
                    val name = a.text().trim()
                    val mName = Regex("第\\s*(\\d{1,3})\\s*[话集]").find(name)?.groupValues?.getOrNull(1)
                    if (!mName.isNullOrBlank()) return@runCatching mName
                    val mHref = Regex("/watch/\\d+/\\d+/(\\d+)\\.html").find(abs)?.groupValues?.getOrNull(1)
                        ?: Regex("/watch/\\d+-\\d+-(\\d+)\\.html").find(abs)?.groupValues?.getOrNull(1)
                    if (!mHref.isNullOrBlank()) return@runCatching mHref
                    // 回退：索引位置作为剧集号
                    val parentList = a.parent()
                    val anchors = parentList?.select("a[href*='/watch/']") ?: candidates
                    val index = anchors.indexOf(a)
                    if (index >= 0) return@runCatching (index + 1).toString()
                }
            }
            // 其次：寻找标记为选中状态的剧集项
            val active = doc.select(".anthology-list-play a.active, .anthology-list-play a.current, .anthology-list-play a.cur, .module-play-list a.active, .module-play-list a.current, a.active, a.current, a.cur").firstOrNull()
            if (active != null) {
                val text = active.text().trim()
                val mName = Regex("第\\s*(\\d{1,3})\\s*[话集]").find(text)?.groupValues?.getOrNull(1)
                if (!mName.isNullOrBlank()) return@runCatching mName
                val href = active.attr("href")
                val abs = if (href.startsWith("http")) href else active.absUrl("href").ifBlank { href }
                val mHref = Regex("/watch/\\d+/\\d+/(\\d+)\\.html").find(abs)?.groupValues?.getOrNull(1)
                    ?: Regex("/watch/\\d+-\\d+-(\\d+)\\.html").find(abs)?.groupValues?.getOrNull(1)
                if (!mHref.isNullOrBlank()) return@runCatching mHref
            }
            // 最后：从标题或元数据中尝试提取
            val titleText = doc.selectFirst("h1, title")?.text().orEmpty()
            Regex("第\\s*(\\d{1,3})\\s*[话集]").find(titleText)?.groupValues?.getOrNull(1)
        }.getOrNull()
    }

    private fun normalizeToPath(u: String?): String? {
        if (u.isNullOrBlank()) return null
        return runCatching {
            val uri = java.net.URI(u)
            uri.path
        }.getOrDefault(u)
    }

    // 收集页面中的剧集列表（按“线路”分组）与当前所选线路及索引
    private data class EpisodeContext(val groups: List<List<String>>, val groupIndex: Int, val indexInGroup: Int)
    private fun getEpisodeContext(html: String, episodeUrl: String): EpisodeContext? {
        return runCatching {
            val doc = Jsoup.parse(html, cfg.rawBaseUrl)
            val containers = doc.select(".anthology-list-play, .module-play-list")
            if (containers.isEmpty()) return@runCatching null
            val groups = containers.map { c ->
                val as_ = c.select("a[href]")
                as_.map { a ->
                    val href = a.attr("href")
                    if (href.startsWith("http")) href else a.absUrl("href").ifBlank { href }
                }
            }.filter { it.isNotEmpty() }
            if (groups.isEmpty()) return@runCatching null

            val normTarget = normalizeToPath(episodeUrl)
            var gIdx = -1
            var iIdx = -1
            // 先尝试按当前播放链接定位到分组与索引
            groups.forEachIndexed { gi, list ->
                val idx = list.indexOfFirst { normalizeToPath(it) == normTarget }
                if (idx >= 0 && gIdx == -1) { gIdx = gi; iIdx = idx }
            }
            // 若未命中，尝试 active/current 标记定位分组与索引
            if (gIdx == -1 || iIdx == -1) {
                containers.forEachIndexed { gi, c ->
                    val active = c.select("a.active, a.current, a.cur").firstOrNull()
                    if (active != null && gIdx == -1) {
                        val href = active.attr("href")
                        val abs = if (href.startsWith("http")) href else active.absUrl("href").ifBlank { href }
                        val idx = groups[gi].indexOfFirst { it == abs }
                        if (idx >= 0) { gIdx = gi; iIdx = idx }
                    }
                }
            }

            EpisodeContext(groups = groups, groupIndex = gIdx, indexInGroup = iIdx)
        }.getOrNull()
    }

    // 从页面原始 HTML 中尽力提取一个直链（不做剧集号校验/替换）
    private fun extractRawVideoFromHtml(html: String): String? {
        if (html.isBlank()) return null
        // 1) player_aaaa
        try {
            val info = tryExtractPlayerAaaaInfo(html)
            if (info?.url?.let { looksLikeVideo(it) } == true) return info.url
        } catch (_: Exception) {}
        // 2) DOM 精确
        try {
            val doc = Jsoup.parse(html, cfg.rawBaseUrl)
            val dom = findVideoUrlByDom(doc)
            if (!dom.isNullOrBlank() && looksLikeVideo(dom)) return dom
            // 3) 标签
            val tag = doc.select("video, source").firstOrNull()?.attr("src")
            val tagAbs = tag?.let { if (it.startsWith("http")) it else doc.absUrl("src").ifBlank { it } }
            if (!tagAbs.isNullOrBlank() && looksLikeVideo(tagAbs)) return tagAbs
        } catch (_: Exception) {}
        // 4) 正则兜底（优先 mp4，再 m3u8）
        val mp4 = Regex("""https?://[^"'\\s]+\.mp4(?:\?[^"'\\s]*)?""").find(html)?.value
        if (!mp4.isNullOrBlank()) return mp4
        val m3u8 = Regex("""https?://[^"'\\s]+\.m3u8(?:\?[^"'\\s]*)?""").find(html)?.value
        return m3u8
    }

    // 将候选直链中的集数调整为所选集数（更稳健：避免分辨率数字、保持原位数）
    private fun adjustEpisodeInUrl(candidate: String?, episodeNumber: String?): String? {
        if (candidate.isNullOrBlank() || episodeNumber.isNullOrBlank()) return candidate
        return runCatching {
            val uri = java.net.URI(candidate)
            val path = uri.path ?: candidate
            val filename = path.substringAfterLast('/')
            val extIndex = filename.lastIndexOf('.')
            val namePart = if (extIndex > 0) filename.substring(0, extIndex) else filename

            // 选出最可能的“集数”数字：优先 EP/E/第/集 标记，其次分隔符结尾段，最后回退从后往前跳过分辨率
            val all = Regex("\\d{1,3}").findAll(namePart).toList()
            var best: MatchResult? = null
            var bestScore = Int.MIN_VALUE
            fun scoreMatch(m: MatchResult): Int {
                val r = m.range
                val before = if (r.first > 0) namePart[r.first - 1] else null
                val after = if (r.last + 1 < namePart.length) namePart[r.last + 1] else null
                val prefix3 = namePart.substring(maxOf(0, r.first - 3), r.first).lowercase()
                val suffix3 = namePart.substring(r.last + 1, minOf(namePart.length, r.last + 4)).lowercase()
                var s = 0
                if (prefix3.contains("ep") || prefix3.endsWith("e") || prefix3.contains("第")) s += 8
                if (suffix3.startsWith("集")) s += 8
                if (before == '_' || before == '-' || before == ' ' || before == '(' || before == '[') s += 3
                if (after == '_' || after == '-' || after == ' ' || after == ')' || after == ']') s += 3
                // 明显的分辨率数字惩罚
                if (suffix3.startsWith("p")) s -= 10 // 1080p/720p 等
                // 1920x1080 等；匹配形如 \d+x\d+，若本数字后紧跟 . 或 结尾且前一个字符是 'x'
                if (before == 'x' || before == 'X') s -= 8
                val v = m.value
                if (v == "1080" || v == "720" || v == "480") s -= 9
                // 越靠近结尾（扩展名前）越可能是集数
                s += r.last
                return s
            }
            for (m in all) {
                val sc = scoreMatch(m)
                if (sc > bestScore) { bestScore = sc; best = m }
            }
            val m = best ?: all.lastOrNull() // 回退：最后一个数字
            val found = m?.value
            if (!found.isNullOrBlank()) {
                val width = found.length.coerceIn(1, 3)
                val target = episodeNumber.padStart(width, '0')
                if (target != found) {
                    val replacedName = namePart.replaceRange(m!!.range, target)
                    val newFilename = if (extIndex > 0) (replacedName + filename.substring(extIndex)) else replacedName
                    val newPath = path.removeSuffix(filename) + newFilename
                    // 使用 URI 组件安全重建，避免路径重复拼接
                    val scheme = uri.scheme
                    val authority = uri.authority
                    val base = buildString {
                        if (!scheme.isNullOrBlank()) {
                            append(scheme).append("://")
                        }
                        if (!authority.isNullOrBlank()) {
                            append(authority)
                        }
                    }
                    val rebuilt = base + newPath + (uri.query?.let { "?" + it } ?: "")
                    cleanUrl(rebuilt)
                } else candidate
            } else candidate
        }.getOrDefault(candidate)
    }

    // 构造相邻集数页面的 URL（保持原位数），基于当前播放页 URL
    private fun tryBuildAdjacentEpisodeUrl(currentEpisodeUrl: String?, delta: Int): String? {
        if (currentEpisodeUrl.isNullOrBlank()) return null
        return runCatching {
            val uri = java.net.URI(currentEpisodeUrl)
            val path = uri.path ?: return@runCatching currentEpisodeUrl
            val m = Regex("(\\d{1,3})(?=\\.html$)").find(path)
            val num = m?.value ?: return@runCatching null
            val width = num.length
            val next = (num.toIntOrNull() ?: return@runCatching null) + delta
            val replaced = path.replaceRange(m.range, next.toString().padStart(width, '0'))
            val base = currentEpisodeUrl.removeSuffix(uri.path ?: "")
            base + replaced + (uri.query?.let { "?" + it } ?: "")
        }.getOrNull()
    }

    // 试图从“下一集页面”借出一个直链，再按当前集数矫正
    private fun borrowDirectLinkFromNextEpisode(epCtx: EpisodeContext?, episodeUrl: String, expectedEp: String?): String? {
        val nextUrl: String? = runCatching {
            val gi = epCtx?.groupIndex ?: -1
            val idx = epCtx?.indexInGroup ?: -1
            val urls = if (gi >= 0) epCtx?.groups?.getOrNull(gi) ?: emptyList() else emptyList()
            if (gi >= 0 && idx >= 0 && idx + 1 < urls.size) {
                urls[idx + 1]
            } else {
                tryBuildAdjacentEpisodeUrl(episodeUrl, +1)
            }
        }.getOrNull()
        if (nextUrl.isNullOrBlank()) return null
        val nextHtml = httpGet(nextUrl)
        val raw = extractRawVideoFromHtml(nextHtml)
        return adjustEpisodeInUrl(raw, expectedEp)
    }
    // 基于剧集号精确匹配直链（支持 mp4/m3u8，包含URL编码变体）
    private fun matchVideoByEpisodeNumber(html: String, episodeNumber: String?): String? {
        if (episodeNumber.isNullOrBlank()) return null
        val epRaw = episodeNumber
        val epPadded = epRaw.padStart(2, '0')
        val variants = listOf(epRaw, epPadded).distinct()
        for (ep in variants) {
            val p1 = Regex("https?://[^\\s\"']+?" + Regex.escape(ep) + "[^\\s\"']*?\\.(mp4|m3u8)", RegexOption.IGNORE_CASE)
            val m1 = p1.find(html)?.value
            if (!m1.isNullOrBlank()) {
                return runCatching { java.net.URLDecoder.decode(m1, "UTF-8") }.getOrDefault(m1)
            }
            val encodedEp = runCatching { java.net.URLEncoder.encode(ep, "UTF-8") }.getOrDefault(ep)
            val p2 = Regex("https?://[^\\s\"']+?" + Regex.escape(encodedEp) + "[^\\s\"']*?\\.(mp4|m3u8)", RegexOption.IGNORE_CASE)
            val m2 = p2.find(html)?.value
            if (!m2.isNullOrBlank()) {
                return runCatching { java.net.URLDecoder.decode(m2, "UTF-8") }.getOrDefault(m2)
            }
        }
        return null
    }
    // 校验候选直链是否包含目标剧集号（同时支持两位补零及URL编码）
    private fun validateEpisodeInUrl(candidate: String?, episodeNumber: String?): Boolean {
        if (candidate.isNullOrBlank()) return false
        if (episodeNumber.isNullOrBlank()) return true // 无法提取剧集号时，不拦截候选
        return runCatching {
            val epRaw = episodeNumber
            val epPadded = epRaw.padStart(2, '0')
            val lower = candidate.lowercase()
            val enc = try { java.net.URLEncoder.encode(epPadded, "UTF-8") } catch (_: Exception) { epPadded }
            lower.contains(epPadded.lowercase()) || lower.contains(enc.lowercase())
        }.getOrDefault(false)
    }

    // 提取并解析 var player_aaaa = {...} 结构，返回其中的 url 字段
    private fun tryExtractFromPlayerAaaa(html: String): String? {
        return runCatching {
            val pattern = Regex("var\\s+player_aaaa\\s*=\\s*(\\{[\\s\\S]*?\\})\\s*(?:;|</script>)", RegexOption.IGNORE_CASE)
            val m = pattern.find(html) ?: return@runCatching null
            val rawObj = m.groupValues[1]
            debugLog("player_aaaa raw length=" + rawObj.length)

            // 规范化为可解析的 JSON（修复单引号、未加引号的 key、结尾多余逗号）
            var jsonLike = rawObj
            jsonLike = jsonLike.replace("'", "\"")
            jsonLike = jsonLike.replace("\n", "")
            jsonLike = jsonLike.replace(Regex("(\\w+)\\s*:"), "\"$1\":")
            jsonLike = jsonLike.replace(Regex(",\\s*}"), "}")

            // 直接尝试从对象文本中提取 "url": "..." 字段
            val directField = Regex("\"url\"\\s*:\\s*\"([^\"]+?)\"").find(jsonLike)?.groupValues?.getOrNull(1)
            var candidate = directField?.let { cleanUrl(it) }
            debugLog("player_aaaa urlField=" + directField)

            // 如果不是直链，尝试从 query 参数中解包真正的视频地址（常见格式：player?url=xxx）
            if (candidate.isNullOrBlank() || !looksLikeVideo(candidate)) {
                candidate = expandWrappedVideoUrl(directField)
                debugLog("player_aaaa expanded candidate=" + candidate)
            }

            if (candidate != null && looksLikeVideo(candidate)) return@runCatching candidate

            // 回退使用 Gson 解析为 Map
            val map: Map<*, *> = Gson().fromJson(jsonLike, Map::class.java)
            val u = (map["url"] as? String)?.let { cleanUrl(it) }
            debugLog("player_aaaa gson url=" + u)

            var expanded = u
            if (expanded.isNullOrBlank() || !looksLikeVideo(expanded)) {
                expanded = expandWrappedVideoUrl(u)
                debugLog("player_aaaa gson expanded=" + expanded)
            }

            // 若仍不是明显直链，尝试抓取该包装页并在其中提取视频（深度=1，避免循环）
            if (expanded.isNullOrBlank() || !looksLikeVideo(expanded)) {
                val wrapped = u ?: candidate
                if (!wrapped.isNullOrBlank() && wrapped.startsWith("http")) {
                    val wrappedHtml = httpGet(wrapped)
                    if (wrappedHtml.isNotBlank()) {
                        // 在包装页中寻找 video/source 或再次出现的 player_aaaa
                        val doc = Jsoup.parse(wrappedHtml, cfg.rawBaseUrl)
                        val tagUrl = doc.select("video, source").firstOrNull()?.attr("src")
                        val absTagUrl = tagUrl?.let { if (it.startsWith("http")) it else doc.absUrl("src").ifBlank { it } }
                        debugLog("player_aaaa wrapped tagUrl=" + absTagUrl)
                        if (!absTagUrl.isNullOrBlank() && looksLikeVideo(absTagUrl)) return@runCatching absTagUrl

                        val fromWrappedPlayer = tryExtractPlayerAaaaInfo(wrappedHtml)?.url
                        debugLog("player_aaaa wrapped inner player url=" + fromWrappedPlayer)
                        if (!fromWrappedPlayer.isNullOrBlank() && looksLikeVideo(fromWrappedPlayer)) return@runCatching fromWrappedPlayer
                    }
                }
            }

            // 最后兜底：尝试在原始对象文本中匹配常见 m3u8
            Regex("""https?://[^\"'\\s]+\\.m3u8(?:\?[^\"'\\s]*)?""").find(jsonLike)?.value
        }.onFailure { e ->
            debugLog("player_aaaa parse failed=" + (e.message ?: e.toString()))
        }.getOrNull()
    }

    // 包含 id 的 player_aaaa 解析
    private data class PlayerAaaaInfo(val url: String?, val id: String?)

    private fun tryExtractPlayerAaaaInfo(html: String): PlayerAaaaInfo? {
        return runCatching {
            val pattern = Regex("var\\s+player_aaaa\\s*=\\s*(\\{[\\s\\S]*?\\})\\s*(?:;|</script>)", RegexOption.IGNORE_CASE)
            val m = pattern.find(html) ?: return@runCatching null
            val rawObj = m.groupValues[1]
            var jsonLike = rawObj
            jsonLike = jsonLike.replace("'", "\"")
            jsonLike = jsonLike.replace("\n", "")
            jsonLike = jsonLike.replace(Regex("(\\w+)\\s*:"), "\"$1\":")
            jsonLike = jsonLike.replace(Regex(",\\s*}"), "}")

            // 直接提取字段
            val directUrl = Regex("\"url\"\\s*:\\s*\"([^\"]+?)\"").find(jsonLike)?.groupValues?.getOrNull(1)
            val directId = Regex("\"id\"\\s*:\\s*\"?(\\d+)\"?").find(jsonLike)?.groupValues?.getOrNull(1)
            var candidateUrl = directUrl?.let { cleanUrl(it) }

            if (candidateUrl.isNullOrBlank() || !looksLikeVideo(candidateUrl)) {
                candidateUrl = expandWrappedVideoUrl(directUrl)
            }

            if (!candidateUrl.isNullOrBlank() && looksLikeVideo(candidateUrl)) {
                return@runCatching PlayerAaaaInfo(candidateUrl, directId)
            }

            // Gson 解析兜底
            val map: Map<*, *> = Gson().fromJson(jsonLike, Map::class.java)
            val u = (map["url"] as? String)?.let { cleanUrl(it) }
            val id = (map["id"]?.toString())
            var expanded = u
            if (expanded.isNullOrBlank() || !looksLikeVideo(expanded)) {
                expanded = expandWrappedVideoUrl(u)
            }
            if (!expanded.isNullOrBlank() && looksLikeVideo(expanded)) {
                return@runCatching PlayerAaaaInfo(expanded, id)
            }

            // 包装页探测
            val wrapped = u ?: candidateUrl
            if (!wrapped.isNullOrBlank() && wrapped.startsWith("http")) {
                val wrappedHtml = httpGet(wrapped)
                if (wrappedHtml.isNotBlank()) {
                    val doc = Jsoup.parse(wrappedHtml, cfg.rawBaseUrl)
                    val tagUrl = doc.select("video, source").firstOrNull()?.attr("src")
                    val absTagUrl = tagUrl?.let { if (it.startsWith("http")) it else doc.absUrl("src").ifBlank { it } }
                    if (!absTagUrl.isNullOrBlank() && looksLikeVideo(absTagUrl)) return@runCatching PlayerAaaaInfo(absTagUrl, id)
                    val inner = tryExtractPlayerAaaaInfo(wrappedHtml)
                    if (inner != null && !inner.url.isNullOrBlank() && looksLikeVideo(inner.url)) return@runCatching inner
                }
            }
            null
        }.getOrNull()
    }

    // 解析包装播放器 URL 中的 query 参数，提取真正的视频地址（url/v/video/src 等），并做解码
    private fun expandWrappedVideoUrl(u: String?): String? {
        if (u.isNullOrBlank()) return null
        return runCatching {
            val uri = android.net.Uri.parse(u)
            val keys = listOf("url", "v", "video", "src")
            val q = keys.mapNotNull { k -> uri.getQueryParameter(k) }.firstOrNull()
            var value = q ?: u
            // 百分号解码
            try { value = java.net.URLDecoder.decode(value, "UTF-8") } catch (_: Exception) {}
            // 尝试 Base64 解码
            if (!looksLikeVideo(value) && value.length % 4 == 0) {
                try {
                    val decoded = String(android.util.Base64.decode(value, android.util.Base64.DEFAULT))
                    if (decoded.isNotBlank()) value = decoded
                } catch (_: Exception) {}
            }
            cleanUrl(value)
        }.getOrNull()
    }

    // 简单判断是否像视频直链
    private fun looksLikeVideo(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        return url.endsWith(".m3u8") || url.endsWith(".mp4") || url.contains("m3u8")
    }

    // 彻底清理 URL 中的 JSON 转义字符（参考 py 的 clean_url）
    private fun cleanUrl(url: String): String {
        var cleaned = url
        cleaned = cleaned.replace(Regex("\\\\+"), "")
        cleaned = cleaned.replace("\\/", "/")
        cleaned = cleaned.replace("\\\"", "\"")
        cleaned = cleaned.replace("\\'", "'")
        return cleaned
    }

    private fun matchByRegex(pattern: String?, text: String): String? {
        if (pattern.isNullOrBlank()) return null
        return runCatching {
            val r = Regex(pattern)
            val m = r.find(text)
            if (m != null) {
                if (m.groupValues.size > 1) m.groupValues[1] else m.value
            } else null
        }.getOrNull()
    }

    private fun httpGet(url: String): String {
        val req = Request.Builder().url(url)
            .header("Referer", defaultHeaders["referer"] ?: (cfg.rawBaseUrl ?: url))
            .header("User-Agent", defaultHeaders["userAgent"] ?: "Mozilla/5.0")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "zh-CN,zh;q=0.9")
            .build()
        return try {
            okHttpClient.newCall(req).execute().use { resp ->
                debugLog("GET " + url + " => code=" + resp.code)
                resp.body?.string() ?: ""
            }
        } catch (e: Exception) {
            debugLog("GET failed url=" + url + "; err=" + (e.message ?: e.toString()))
            ""
        }
    }

    private fun debugLog(msg: String) {
        // 为了排查配置与解析问题，临时总是输出调试日志
        Log.d("AnimeSearch", msg)
        try { DebugLogStore.append(msg) } catch (_: Exception) { /* ignore */ }
    }
}


