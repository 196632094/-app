package com.xxla.mh.data.api

import com.xxla.mh.ui.screens.admin.PendingVideo
import com.xxla.mh.ui.screens.admin.Statistics
import com.xxla.mh.ui.screens.admin.UserInfo
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * 后台管理系统API服务接口
 */
interface AdminApiService {
    /**
     * 获取待审核视频列表
     */
    @GET("admin/videos/pending")
    suspend fun getPendingVideos(): List<PendingVideo>
    
    /**
     * 获取用户列表
     */
    @GET("admin/users")
    suspend fun getUsers(): List<UserInfo>
    
    /**
     * 获取统计数据
     */
    @GET("admin/statistics")
    suspend fun getStatistics(): Statistics
    
    /**
     * 审核通过视频
     */
    @POST("admin/videos/{videoId}/approve")
    suspend fun approveVideo(@Path("videoId") videoId: String)
    
    /**
     * 拒绝视频
     */
    @POST("admin/videos/{videoId}/reject")
    suspend fun rejectVideo(@Path("videoId") videoId: String)
    
    /**
     * 禁用用户
     */
    @POST("admin/users/{userId}/ban")
    suspend fun banUser(@Path("userId") userId: String)
    
    /**
     * 解除用户禁用
     */
    @POST("admin/users/{userId}/unban")
    suspend fun unbanUser(@Path("userId") userId: String)
}