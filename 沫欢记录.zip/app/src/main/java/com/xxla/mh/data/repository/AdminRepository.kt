package com.xxla.mh.data.repository

import com.xxla.mh.data.api.AdminApiService
import com.xxla.mh.ui.screens.admin.PendingVideo
import com.xxla.mh.ui.screens.admin.Statistics
import com.xxla.mh.ui.screens.admin.UserInfo
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 后台管理系统的数据仓库
 */
@Singleton
class AdminRepository @Inject constructor(
    private val adminApiService: AdminApiService
) {
    /**
     * 获取待审核视频列表
     */
    suspend fun getPendingVideos(): List<PendingVideo> {
        // 模拟网络请求延迟
        delay(800)
        // 实际项目中应调用API
        // return adminApiService.getPendingVideos()
        return emptyList() // 返回空列表，实际数据在ViewModel中模拟
    }
    
    /**
     * 获取用户列表
     */
    suspend fun getUsers(): List<UserInfo> {
        // 模拟网络请求延迟
        delay(800)
        // 实际项目中应调用API
        // return adminApiService.getUsers()
        return emptyList() // 返回空列表，实际数据在ViewModel中模拟
    }
    
    /**
     * 获取统计数据
     */
    suspend fun getStatistics(): Statistics {
        // 模拟网络请求延迟
        delay(800)
        // 实际项目中应调用API
        // return adminApiService.getStatistics()
        return Statistics() // 返回空对象，实际数据在ViewModel中模拟
    }
    
    /**
     * 审核通过视频
     */
    suspend fun approveVideo(videoId: String) {
        // 模拟网络请求延迟
        delay(500)
        // 实际项目中应调用API
        // adminApiService.approveVideo(videoId)
    }
    
    /**
     * 拒绝视频
     */
    suspend fun rejectVideo(videoId: String) {
        // 模拟网络请求延迟
        delay(500)
        // 实际项目中应调用API
        // adminApiService.rejectVideo(videoId)
    }
    
    /**
     * 禁用用户
     */
    suspend fun banUser(userId: String) {
        // 模拟网络请求延迟
        delay(500)
        // 实际项目中应调用API
        // adminApiService.banUser(userId)
    }
    
    /**
     * 解除用户禁用
     */
    suspend fun unbanUser(userId: String) {
        // 模拟网络请求延迟
        delay(500)
        // 实际项目中应调用API
        // adminApiService.unbanUser(userId)
    }
}