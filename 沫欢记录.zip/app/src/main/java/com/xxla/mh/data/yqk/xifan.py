import re
import os
import requests
import json
import datetime
from bs4 import BeautifulSoup
from collections import deque
import time
from urllib.parse import urljoin
import argparse

# 全局变量初始化
download_queue = deque()  # 下载队列
download_history = {}     # 下载历史记录
preupdate_queue = []      # 预更新队列

# 预更新队列存储文件
PREUPDATE_FILE = "preupdate_queue.json"

BASE_URL = "https://dm1.xfdm.pro"
# 全局SESSION对象
SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
    "Referer": ""
})

class XifanAnime:
    def __init__(self, config):
        self.config = config
        search_config = config["arguments"]["searchConfig"]
        self.search_url = search_config["searchUrl"]
        self.subject_selectors = search_config["selectorSubjectFormatIndexed"]
        self.channel_selectors = search_config["selectorChannelFormatFlattened"]
        self.video_rules = search_config["matchVideo"]
        
        self.session = requests.Session()
        headers = {
            "User-Agent": self.video_rules["addHeadersToVideo"]["userAgent"]
        }
        self.session.headers.update(headers)

def search_anime(keyword):
    """搜索番剧并返回结果列表"""
    try:
        response = SESSION.get(f"{BASE_URL}/search.html?wd={keyword}")
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        results = []
        for item in soup.select('.public-list-box'):
            # 获取标题
            title_elem = item.select_one('.thumb-txt')
            if not title_elem:
                img_elem = item.select_one('.public-list-exp img')
                if img_elem and 'alt' in img_elem.attrs:
                    title = img_elem['alt'].strip()
                    title = re.sub(r'封面图$', '', title).strip()
                else:
                    continue
            else:
                title = title_elem.text.strip()
            
            # 获取详情页链接
            link_elem = item.select_one('.public-list-exp')
            if not link_elem or not link_elem.get('href'):
                continue
            detail_path = link_elem['href']
            
            # 提取番剧ID
            anime_id_match = re.search(r'/bangumi/(\d+)\.html', detail_path)
            if not anime_id_match:
                continue
                
            results.append({
                "id": anime_id_match.group(1),
                "title": title,
                "url": urljoin(BASE_URL, detail_path)
            })
        
        return results
        
    except Exception as e:
        print(f"搜索失败: {e}")
        return []

def get_episodes(anime_url):
    """获取番剧的线路和剧集"""
    try:
        response = SESSION.get(anime_url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 解析线路
        lines = []
        for i, tab in enumerate(soup.select('.anthology-tab .swiper-slide')):
            line_name = tab.text.strip()
            lines.append({
                "id": i + 1,
                "name": line_name,
                "episodes": []
            })
        
        # 解析剧集
        for i, container in enumerate(soup.select('.anthology-list-box')):
            if i >= len(lines):
                break
                
            for ep in container.select('.anthology-list-play a'):
                ep_url = urljoin(BASE_URL, ep['href'])
                ep_name = ep.text.strip()
                lines[i]["episodes"].append({
                    "name": ep_name,
                    "url": ep_url
                })
        
        return lines
    except Exception as e:
        print(f"获取剧集失败: {e}")
        return []

def get_latest_episodes(anime_url, line_id):
    """获取指定线路的最新剧集列表"""
    try:
        # 获取所有线路
        lines = get_episodes(anime_url)
        if not lines:
            return None
            
        # 查找指定线路
        selected_line = None
        for line in lines:
            if line['id'] == line_id:
                selected_line = line
                break
                
        if not selected_line:
            print(f"未找到ID为 {line_id} 的线路")
            return None
            
        return selected_line['episodes']
    except Exception as e:
        print(f"获取最新剧集失败: {e}")
        return None

import lxml.html

def get_video_url(episode_url, episode_number):
    """
    从播放页提取视频直链
    :param episode_url: 播放页URL
    :param episode_number: 用户选择的剧集号（用于精确匹配）
    """
    for attempt in range(3):  # 最多重试3次
        try:
            response = SESSION.get(episode_url)
            response.raise_for_status()
            html_content = response.text
            
            # 方法1：优化JavaScript变量提取（修复正则匹配问题）
            # 匹配 player_aaaa 对象（考虑跨行和特殊符号）
            match = re.search(r'var player_aaaa\s*=\s*({[\s\S]*?})\s*;', html_content)
            if not match:
                # 备选方案：无分号结尾的情况
                match = re.search(r'var player_aaaa\s*=\s*({[\s\S]*?})\s*</script>', html_content)
            
            if match:
                try:
                    import json
                    import urllib.parse
                    json_str = match.group(1)
                    
                    # 处理JSON中的单引号和未转义字符
                    json_str = json_str.replace("'", '"').replace('\n', '')
                    
                    # 修复常见JSON格式错误
                    json_str = re.sub(r'(\w+):', r'"\1":', json_str)  # 无引号的key
                    json_str = re.sub(r',\s*}', '}', json_str)  # 尾部多余逗号
                    
                    player_data = json.loads(json_str)
                    
                    if 'url' in player_data:
                        video_url = player_data['url']
                        # URL解码处理
                        video_url = urllib.parse.unquote(video_url)
                        
                        # 验证剧集号是否匹配
                        ep_pattern = f"{episode_number:02d}"
                        if ep_pattern in video_url:
                            print(f"成功从player_aaaa提取视频地址: {video_url}")
                            return video_url
                        else:
                            print(f"警告：提取的视频URL与剧集号不匹配: {video_url}")
                except Exception as e:
                    
                    # 备选方案：直接提取URL模式，并校验剧集号匹配
                    url_match = re.search(r'"url"\s*:\s*"([^"]+\.(?:mp4|m3u8))"', match.group(1))
                    if url_match:
                        video_url = urllib.parse.unquote(url_match.group(1))
                        ep_pattern = f"{episode_number:02d}"
                        if ep_pattern in video_url:
                            return video_url
                        else:
                            print(f"警告：备选player_aaaa视频URL与剧集号不匹配: {video_url}")
            
            # 方法2：基于剧集号精确匹配视频URL（增强匹配能力，支持 mp4/m3u8）
            try:
                import urllib.parse
                ep_pattern = f"{episode_number:02d}"
                
                # 方案1：直接匹配URL结构（mp4/m3u8）
                pattern1_mp4 = fr'(https?://[^\s"\']+?{re.escape(ep_pattern)}[^\s"\']*?\.mp4)'
                pattern1_m3u8 = fr'(https?://[^\s"\']+?{re.escape(ep_pattern)}[^\s"\']*?\.m3u8(?:\?[^\s"\']*)?)'
                # 方案2：匹配URL编码的剧集号（mp4/m3u8）
                encoded_ep = urllib.parse.quote(ep_pattern)
                pattern2_mp4 = fr'(https?://[^\s"\']+?{re.escape(encoded_ep)}[^\s"\']*?\.mp4)'
                pattern2_m3u8 = fr'(https?://[^\s"\']+?{re.escape(encoded_ep)}[^\s"\']*?\.m3u8(?:\?[^\s"\']*)?)'
                
                for pattern in [pattern1_mp4, pattern2_mp4, pattern1_m3u8, pattern2_m3u8]:
                    url_match2 = re.search(pattern, html_content)
                    if url_match2:
                        video_url = urllib.parse.unquote(url_match2.group(1))
                        print(f"通过剧集号匹配到直链: {video_url}")
                        return video_url
            except Exception as e:
                print(f"剧集号匹配异常: {str(e)}")
            
            # 方法3：XPath精确定位
            try:
                # 使用lxml解析HTML
                tree = lxml.html.fromstring(html_content)
                
                # 用户提供的XPath: /html/body/div[2]/div/video
                video_element = tree.xpath('/html/body/div[2]/div/video')
                
                if video_element:
                    # 获取第一个匹配的视频元素
                    video_element = video_element[0]
                    
                    # 检查source子元素
                    source = video_element.find('.//source')
                    if source is not None and 'src' in source.attrib:
                        video_url = source.attrib['src']
                        print(f"通过XPath定位提取视频地址: {video_url}")
                        return video_url
                    
                    # 检查video元素本身的src属性
                    if 'src' in video_element.attrib:
                        video_url = video_element.attrib['src']
                        print(f"通过XPath定位提取视频地址: {video_url}")
                        return video_url
            except Exception as e:
                print(f"XPath解析失败: {e}")
            
            # 方法4：BeautifulSoup DOM定位
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # 尝试直接定位视频元素
            video_element = None
            
            # 方法4.1：CSS选择器定位
            try:
                # body > div:nth-of-type(2) > div > video
                video_element = soup.select_one('body > div:nth-of-type(2) > div > video')
            except Exception as e:
                print(f"CSS选择器解析失败: {e}")
            
            # 方法4.2：备用定位方法
            if not video_element:
                # 尝试直接查找video标签
                video_element = soup.find('video')
            
            if video_element:
                # 检查source标签
                source = video_element.find('source')
                if source and source.get('src'):
                    video_url = source['src']
                    print(f"通过DOM定位提取视频地址: {video_url}")
                    return video_url
                
                # 检查video元素的src属性
                if video_element.get('src'):
                    video_url = video_element['src']
                    print(f"通过DOM定位提取视频地址: {video_url}")
                    return video_url
            
            if video_element:
                # 检查source标签
                source = video_element.find('source')
                if source and source.get('src'):
                    video_url = source['src']
                    print(f"通过DOM定位提取视频地址: {video_url}")
                    return video_url
                
                # 检查video元素的src属性
                if video_element.get('src'):
                    video_url = video_element['src']
                    print(f"通过DOM定位提取视频地址: {video_url}")
                    return video_url
            
            # 方法5：iframe内容解析
            iframe = soup.find('iframe')
            if iframe and iframe.get('src'):
                iframe_src = urljoin(episode_url, iframe['src'])
                print(f"发现iframe，正在解析内容: {iframe_src}")
                
                try:
                    iframe_response = SESSION.get(iframe_src)
                    iframe_response.raise_for_status()
                    
                    # 使用lxml解析iframe内容
                    iframe_tree = lxml.html.fromstring(iframe_response.text)
                    
                    # 在iframe中查找视频
                    iframe_video = iframe_tree.xpath('//video')
                    if iframe_video:
                        iframe_video = iframe_video[0]
                        
                        # 检查source子元素
                        source = iframe_video.find('.//source')
                        if source is not None and 'src' in source.attrib:
                            video_url = source.attrib['src']
                            print(f"从iframe中提取视频地址: {video_url}")
                            return video_url
                        
                        # 检查video元素本身的src属性
                        if 'src' in iframe_video.attrib:
                            video_url = iframe_video.attrib['src']
                            print(f"从iframe中提取视频地址: {video_url}")
                            return video_url
                except Exception as e:
                    print(f"iframe解析失败: {e}")
            
        except Exception as e:
            print(f"提取视频链接失败 (尝试 {attempt+1}/3): {e}")
    
    return None

def clean_url(url):
    """
    彻底清理URL中的JSON转义字符
    处理多层转义情况：\\/ -> /, \\\\/ -> / 等
    """
    # 处理多层转义反斜杠
    cleaned = re.sub(r'\\\\+', '', url)
    # 移除剩余的反斜杠
    cleaned = cleaned.replace('\\/', '/').replace('\\"', '"').replace("\\'", "'")
    # 验证URL格式
    if not re.match(r'^https?://', cleaned):
        print(f"警告：清理后的URL格式异常: {cleaned}")
        # 保留原始URL用于调试
        print(f"原始URL: {url}")
    return cleaned

def download_video(video_url, filename, session, directory):
    """下载视频文件到指定目录（使用相同的session）"""
    if not video_url:
        print("无法下载视频")
        return False
    
    try:
        # 创建目录（如果不存在）
        if not os.path.exists(directory):
            os.makedirs(directory)
        
        # 确定文件名
        if not filename:
            filename = os.path.basename(video_url)
        
        # 添加扩展名如果缺失
        if not os.path.splitext(filename)[1]:
            if "m3u8" in video_url:
                filename += ".m3u8"
            else:
                filename += ".mp4"
        
        filepath = os.path.join(directory, filename)
        
        # 开始下载（使用相同的session）
        print(f"开始下载: {filename}")
        
        # 添加重试机制
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = session.get(video_url, stream=True, timeout=30)
                response.raise_for_status()
                
                total_size = int(response.headers.get('content-length', 0))
                downloaded = 0
                
                with open(filepath, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        if chunk:  # 过滤掉保持连接的新块
                            f.write(chunk)
                            downloaded += len(chunk)
                            # 显示进度
                            if total_size > 0:
                                percent = (downloaded / total_size) * 100
                                print(f"\r下载进度: {percent:.1f}%", end='')
                
                print(f"\n下载完成: {filepath}")
                return True
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                print(f"\n下载失败(尝试 {attempt+1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    print("等待5秒后重试...")
                    time.sleep(5)
                else:
                    raise
            except Exception as e:
                print(f"\n下载失败: {e}")
                return False
        
        return False
    except Exception as e:
        print(f"下载失败: {e}")
        return False

def main():
    global download_queue, download_history  # 声明全局变量
    
    while True:
        print("\n=== 稀饭动漫下载器 ===")
        keyword = input("请输入要搜索的番剧名称 (输入q退出,k下载,L预更新,P管理): ").strip()
        
        if keyword.lower() == 'q':
            save_queue_and_history()
            print("程序已退出")
            return
        elif keyword.lower() == 'k':
            if not download_queue:
                print("下载队列为空")
                continue
            download_queue_content()
            continue
        elif keyword.lower() == 'l':
            # 管理预更新番剧
            manage_preupdate()
            continue
        elif keyword.lower() == 'p':
            # 管理已下载番剧
            manage_downloaded_anime()
            continue
        
        # 短关键词处理（模糊搜索） - 修改为允许1个字符
        if len(keyword) < 1:
            print("搜索关键词不能为空")
            continue
        
        # 搜索番剧
        print("搜索中...")
        results = search_anime(keyword)
        if not results:
            print("\n未找到相关番剧")
            continue
        
        # 显示搜索结果
        print("\n搜索结果:")
        for i, item in enumerate(results):
            print(f"{i+1}. {item['title']}")
        
        # 选择番剧
        try:
            choice = int(input("请选择番剧 (输入序号): ")) - 1
            anime = results[choice]
        except (ValueError, IndexError):
            print("输入无效或序号超出范围，请重新搜索")
            continue
        
        # 获取线路和剧集
        lines = get_episodes(anime['url'])
        if not lines or not any(line['episodes'] for line in lines):
            print("未找到可用剧集")
            continue
        
        # 显示线路
        print("\n可用线路:")
        for i, line in enumerate(lines):
            print(f"{i+1}. {line['name']} ({len(line['episodes'])}集)")
        
        # 选择线路
        line_choice = int(input("请选择线路 (输入序号): ")) - 1
        selected_line = lines[line_choice]
        
        # 显示剧集
        print(f"\n{selected_line['name']} 剧集列表:")
        for i, ep in enumerate(selected_line['episodes']):
            print(f"{i+1}. {ep['name']}")
        
        # 操作菜单
        anime_title = re.sub(r'[\\/*?:"<>|]', '', anime['title'])
        print(f"\n请为番剧 {anime_title} 选择操作:")
        print("1. 输入'd'添加全部剧集到队列")
        print("2. 输入剧集数字添加单集到队列")
        print("3. 输入'k'开始下载队列")
        print("4. 输入'del'删除队列中的项目")
        print("5. 输入'clear'清空整个队列")
        print("6. 输入'q'退出程序")
        print("7. 输入'm'添加预更新番剧")
        print("8. 输入其他任意键返回搜索")
        
        action = input("请选择操作: ").strip().lower()
        
        if action == 'd':
            # 添加全部剧集
            episodes = []
            for i, ep in enumerate(selected_line['episodes']):
                episodes.append({
                    "name": ep['name'],
                    "url": ep['url'],
                    "episode_number": i + 1
                })
            
            download_queue.append({
                "anime_id": anime['id'],
                "anime_title": anime_title,
                "anime_url": anime['url'],
                "line": selected_line,
                "episodes": episodes
            })
            print(f"已添加 {anime_title} 的全部剧集到下载队列")
            show_queue()
            
        elif action.isdigit():
            # 添加单集
            ep_choice = int(action) - 1
            if ep_choice < 0 or ep_choice >= len(selected_line['episodes']):
                print("无效的剧集选择")
                continue
                
            episode = selected_line['episodes'][ep_choice]
            download_queue.append({
                "anime_id": anime['id'],
                "anime_title": anime_title,
                "anime_url": anime['url'],
                "line": selected_line,
                "episodes": [{
                    "name": episode['name'],
                    "url": episode['url'],
                    "episode_number": ep_choice + 1
                }]
            })
            print(f"已添加 {anime_title} 第{ep_choice+1}集到下载队列")
            show_queue()
            
        elif action == 'k':
            if not download_queue:
                print("下载队列为空")
                continue
            download_queue_content()
            
        elif action == 'del':
            # 删除队列项目
            if not download_queue:
                print("下载队列为空")
                continue
                
            show_queue()
            try:
                del_index = int(input("输入要删除的队列序号: ")) - 1
                if 0 <= del_index < len(download_queue):
                    removed = download_queue[del_index]
                    del download_queue[del_index]
                    print(f"已删除: {removed['anime_title']}")
                else:
                    print("无效序号")
            except:
                print("输入无效")
                
        elif action == 'clear':
            download_queue.clear()
            print("已清空下载队列")
            
        elif action == 'q':
            save_queue_and_history()
            print("程序已退出")
            return
            
        elif action == 'm':
            # 添加预更新番剧
            try:
                total_episodes = int(input("请输入总集数: "))
                update_day = int(input("请输入更新日(1-7, 1=周一, 7=周日, 0=不指定): "))
                update_hour = int(input("请输入更新小时(0-24, -1=不指定): "))
                update_minute = int(input("请输入更新分钟(0-59, -1=不指定): "))
                
                # 验证输入
                if update_day < 0 or update_day > 7:
                    update_day = 0
                if update_hour < -1 or update_hour > 24:
                    update_hour = -1
                if update_minute < -1 or update_minute > 59:
                    update_minute = -1
                    
                # 创建预更新条目 - 添加线路ID和番剧URL
                preupdate_item = {
                    "anime_id": anime['id'],
                    "title": anime_title,
                    "anime_url": anime['url'],  # 添加番剧URL
                    "line_id": selected_line['id'],  # 添加线路ID
                    "total_episodes": total_episodes,
                    "current_episodes": 0,  # 初始化为0，表示尚未下载任何剧集
                    "downloaded": 0,         # 初始化已下载剧集数为0
                    "pending": 0,            # 初始化待更新剧集数为0
                    "update_day": update_day,
                    "update_hour": update_hour,
                    "update_minute": update_minute,
                    "last_checked": time.strftime("%Y-%m-%d")
                }
                
                # 添加到预更新队列
                preupdate_queue.append(preupdate_item)
                save_preupdate_queue()
                print(f"已添加 {anime_title} 到预更新队列")
                
            except ValueError:
                print("输入无效，请确保输入的是数字")
        else:
            # 返回搜索
            continue

def manage_downloaded_anime():
    """管理已下载的番剧"""
    base_dir = "C:/Users/Administrator/Videos/动漫/"
    if not os.path.exists(base_dir):
        print("动漫目录不存在，请先下载一些番剧")
        return
    
    while True:
        print("\n=== 番剧管理 ===")
        print("1. 返回搜索")
        print("2. 显示已下载的番剧")
        print("3. 搜索已下载的番剧")
        print("4. 删除番剧或剧集")
        print("5. 删除全部番剧")
        
        choice = input("请选择操作: ").strip()
        
        if choice == '1':
            return
        elif choice == '2':
            show_downloaded_anime(base_dir)
        elif choice == '3':
            search_downloaded_anime(base_dir)
        elif choice == '4':
            delete_anime_content(base_dir)
        elif choice == '5':
            delete_all_anime(base_dir)
        else:
            print("无效选择，返回主菜单")
            return

def show_downloaded_anime(base_dir):
    """显示所有已下载的番剧"""
    print("\n已下载的番剧:")
    anime_list = [name for name in os.listdir(base_dir) 
                 if os.path.isdir(os.path.join(base_dir, name))]
    
    if not anime_list:
        print("没有找到已下载的番剧")
        return
    
    for i, anime in enumerate(anime_list, 1):
        episodes = [f for f in os.listdir(os.path.join(base_dir, anime)) 
                   if f.endswith(('.mp4', '.m3u8'))]
        print(f"{i}. {anime} ({len(episodes)}集)")

def search_downloaded_anime(base_dir):
    """模糊搜索已下载的番剧"""
    search_term = input("请输入搜索关键词: ").strip().lower()
    if not search_term:
        print("搜索词不能为空")
        return
    
    anime_list = [name for name in os.listdir(base_dir) 
                 if os.path.isdir(os.path.join(base_dir, name))
                 and search_term in name.lower()]
    
    if not anime_list:
        print("没有找到匹配的番剧")
        return
    
    print("\n搜索结果:")
    for i, anime in enumerate(anime_list, 1):
        episodes = [f for f in os.listdir(os.path.join(base_dir, anime)) 
                   if f.endswith(('.mp4', '.m3u8'))]
        print(f"{i}. {anime} ({len(episodes)}集)")

def delete_anime_content(base_dir):
    """删除番剧或剧集"""
    anime_name = input("请输入要删除的番剧名称: ").strip()
    if not anime_name:
        print("番剧名称不能为空")
        return
    
    anime_path = os.path.join(base_dir, anime_name)
    if not os.path.exists(anime_path):
        print(f"番剧 '{anime_name}' 不存在")
        return
    
    print(f"\n请选择删除操作:")
    print("1. 删除整个番剧")
    print("2. 删除特定剧集")
    choice = input("请选择: ").strip()
    
    if choice == '1':
        confirm = input(f"确定要删除整个番剧 '{anime_name}' 吗? (y/n): ").lower()
        if confirm == 'y':
            import shutil
            try:
                shutil.rmtree(anime_path)
                print(f"已删除番剧: {anime_name}")
                
                # 从下载历史中移除相关记录
                global download_history
                keys_to_remove = [k for k in download_history.keys() if anime_name in k]
                for key in keys_to_remove:
                    del download_history[key]
                save_queue_and_history()
            except Exception as e:
                print(f"删除失败: {e}")
    elif choice == '2':
        episode = input("请输入要删除的剧集编号: ").strip()
        pattern = re.compile(rf'第{episode}集|第{episode}话|Episode {episode}|{episode}\.mp4')
        
        deleted = False
        for filename in os.listdir(anime_path):
            if pattern.search(filename):
                filepath = os.path.join(anime_path, filename)
                confirm = input(f"确定要删除 '{filename}' 吗? (y/n): ").lower()
                if confirm == 'y':
                    try:
                        os.remove(filepath)
                        print(f"已删除剧集: {filename}")
                        deleted = True
                        
                        # 从下载历史中移除相关记录
                        history_key = f"{anime_name}-{episode}"
                        if history_key in download_history:
                            del download_history[history_key]
                            save_queue_and_history()
                    except Exception as e:
                        print(f"删除失败: {e}")
        
        if not deleted:
            print("未找到匹配的剧集文件")
            
        # 检查并删除空文件夹
        if not os.listdir(anime_path):
            confirm = input("文件夹已空，是否删除空文件夹? (y/n): ").lower()
            if confirm == 'y':
                try:
                    os.rmdir(anime_path)
                    print(f"已删除空文件夹: {anime_name}")
                except Exception as e:
                    print(f"删除文件夹失败: {e}")
    else:
        print("无效选择")

def delete_all_anime(base_dir):
    """删除全部番剧（双重确认）"""
    confirm1 = input("确定要删除所有番剧吗? 此操作不可恢复! (y/n): ").lower()
    if confirm1 != 'y':
        print("操作已取消")
        return
        
    confirm2 = input('再次确认，请输入"DELETE ALL": ')
    if confirm2.strip() != "DELETE ALL":
        print("确认失败，操作已取消")
        return
        
    import shutil
    try:
        for item in os.listdir(base_dir):
            item_path = os.path.join(base_dir, item)
            if os.path.isdir(item_path):
                shutil.rmtree(item_path)
        print("已删除所有番剧")
        
        # 清空下载历史
        global download_history
        download_history = {}
        save_queue_and_history()
    except Exception as e:
        print(f"删除失败: {e}")

def manage_preupdate():
    """管理预更新番剧"""
    global preupdate_queue
    
    while True:
        # 显示预更新列表
        print("\n=== 预更新番剧管理 ===")
        if not preupdate_queue:
            print("当前没有预更新番剧")
        else:
            for i, item in enumerate(preupdate_queue, 1):
                # 显示条目信息 - 使用新格式: 总集数/已下载/待更新
                total = item.get('total_episodes', 0)
                downloaded = item.get('downloaded', 0)
                pending = item.get('pending', 0)
                
                # 确保显示正确的状态
                if pending > 0:
                    status = f"待更新: {pending}集"
                else:
                    status = "已完成"
                    
                print(f"{i}. {item['title']} ({item['total_episodes']}/{item['downloaded']}/{item['pending']}) - {status}")
        
        # 显示菜单
        print("\n输入选项:")
        print("1. 返回搜索")
        print("2. 开始下载更新")
        print("3. 检查所有番剧更新")
        print("4. 删除番剧")
        print("5. 清空队列")
        
        action = input("请选择操作: ").strip()
        
        # 非1-5返回搜索
        if action not in ['1','2','3','4','5']:
            return
        
        if action == '1':
            return
        elif action == '2':
            download_preupdate_items()
        elif action == '3':
            # 执行检查所有番剧更新
            check_all_updates()
        elif action == '4':
            delete_preupdate_item()
        elif action == '5':
            confirm = input("确定要清空整个预更新队列吗？(y/n): ").lower()
            if confirm == 'y':
                preupdate_queue.clear()
                save_preupdate_queue()
                print("已清空预更新队列")
            else:
                print("操作已取消")

# 删除基于时间的更新计算逻辑

def download_preupdate_items():
    """下载预更新队列中的剧集 - 基于剧集解析和历史检查"""
    global preupdate_queue, download_history
    
    # 确保加载最新下载历史
    load_queue_and_history()
    
    print("开始下载预更新剧集...")
    total_downloaded = 0
    total_skipped = 0
    total_failed = 0
    
    # 遍历预更新队列
    for item in preupdate_queue:
        print(f"\n处理番剧: {item['title']}")
        
        try:
            # 获取所有剧集信息
            print(f"解析详情页: {item['anime_url']}")
            episodes = get_latest_episodes(item['anime_url'], item['line_id'])
            
            if not episodes:
                print(f"错误：无法获取剧集信息 - {item['title']}")
                total_failed += 1
                continue
            
            print(f"找到 {len(episodes)} 个剧集")
            
            # 确定要下载的剧集范围
            start_ep = 1
            end_ep = min(item['total_episodes'], len(episodes))
            
            # 下载缺失的剧集
            for ep_num in range(start_ep, end_ep + 1):
                # 生成历史记录key
                history_key = f"{item['title']}-{item['line_id']}-{ep_num}"
                
                # 检查是否已下载
                if history_key in download_history:
                    print(f"第{ep_num}集已下载，跳过")
                    total_skipped += 1
                    # 更新当前剧集数为当前集数
                    item['current_episodes'] = ep_num
                    continue
                
                print(f"开始下载第{ep_num}集...")
                success = download_single_episode(
                    item['title'], 
                    item['anime_url'], 
                    {"id": item['line_id'], "name": "预更新线路"}, 
                    ep_num
                )
                
                if success:
                    total_downloaded += 1
                    item['current_episodes'] = ep_num
                    download_history[history_key] = {
                        "title": item['title'],
                        "episode": ep_num,
                        "date": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "url": episodes[ep_num-1]['url']
                    }
                else:
                    total_failed += 1
                    print(f"第{ep_num}集下载失败")
            
            # 更新最后检查日期
            item['last_checked'] = datetime.datetime.now().strftime("%Y-%m-%d")
            
        except Exception as e:
            print(f"处理番剧{item['title']}出错: {str(e)}")
            total_failed += (end_ep - start_ep + 1)
    
    # 保存更新后的数据
    save_preupdate_queue()
    save_queue_and_history()
    
    print("\n=== 预更新下载完成 ===")
    print(f"成功下载: {total_downloaded}集")
    print(f"跳过: {total_skipped}集")
    print(f"失败: {total_failed}集")
    input("\n按Enter继续...")

def scan_local_episodes(anime_title):
    """扫描本地已下载的剧集 - 增强匹配能力"""
    anime_dir = f"/vol02/1000-0-f9cce6a6/数据/动漫/{anime_title}"
    if not os.path.exists(anime_dir):
        return []
    
    downloaded_episodes = []
    
    # 增强的文件名匹配模式
    patterns = [
        r'第(\d+)集\.mp4$',          # 标准格式: 第01集.mp4
        r'第(\d+)集\s*-\s*.+\.mp4$', # 带标题格式: 第01集 - 标题.mp4
        r'第(\d+)话\.mp4$',          # 日语格式: 第01话.mp4
        r'第(\d+)話\.mp4$',          # 繁体格式: 第01話.mp4
        r'Episode\s*(\d+)\.mp4$',    # 英文格式: Episode 01.mp4
        r'(\d{2,3})\.mp4$'           # 纯数字格式: 01.mp4
    ]
    
    for filename in os.listdir(anime_dir):
        # 检查所有可能的模式
        for pattern in patterns:
            match = re.search(pattern, filename)
            if match:
                try:
                    ep_num = int(match.group(1))
                    downloaded_episodes.append(ep_num)
                    break  # 匹配成功即跳出当前循环
                except ValueError:
                    continue
    
    return downloaded_episodes

def check_all_updates():
    """检查所有番剧的更新状态 - 智能对比本地文件和在线信息"""
    global preupdate_queue, download_history
    
    print("正在检查所有番剧更新...")
    
    # 确保加载最新下载历史
    load_queue_and_history()
    
    # 遍历预更新队列
    for item in preupdate_queue:
        print(f"\n检查番剧: {item['title']}")
        
        try:
            # 获取网站最新剧集信息
            episodes = get_latest_episodes(item['anime_url'], item['line_id'])
            
            if not episodes:
                print(f"错误：无法获取剧集信息 - {item['title']}")
                continue
            
            total_episodes = len(episodes)
            # 更新总集数（可能已增加）
            item['total_episodes'] = total_episodes
            
            # 扫描本地实际下载的剧集
            local_episodes = scan_local_episodes(item['title'])
            downloaded = len(local_episodes)
            
            # 计算待更新剧集数（考虑预设总集数）
            pending = min(item['total_episodes'], total_episodes) - downloaded
            if pending < 0:
                pending = 0
            
            # 更新状态信息
            item['downloaded'] = downloaded
            item['pending'] = pending
            
            # 显示状态
            print(f"预设总集数: {item['total_episodes']}")
            print(f"网站最新集数: {total_episodes}")
            print(f"本地已下载: {downloaded}")
            print(f"待更新: {pending}")
            
            # 检查是否有缺失剧集
            missing_eps = [ep for ep in range(1, min(item['total_episodes'], total_episodes)+1) 
                           if ep not in local_episodes]
            if missing_eps:
                print(f"缺失剧集: {', '.join(map(str, missing_eps))}")
            
            # 自动清理已完成的番剧
            if pending == 0 and not missing_eps:
                preupdate_queue.remove(item)
                print(f"{item['title']} 已完成，已从队列移除")
            
        except Exception as e:
            print(f"检查番剧{item['title']}出错: {str(e)}")
    
    # 保存更新后的队列
    save_preupdate_queue()
    input("\n按Enter继续...")

def delete_preupdate_item():
    """删除预更新番剧"""
    global preupdate_queue
    
    if not preupdate_queue:
        print("预更新队列为空")
        return
        
    index = int(input("输入要删除的番剧序号: ")) - 1
    if 0 <= index < len(preupdate_queue):
        item = preupdate_queue.pop(index)
        save_preupdate_queue()
        print(f"已删除: {item['title']}")
    else:
        print("无效序号")

def download_queue_content():
    """下载队列中的所有内容"""
    global download_queue, download_history  # 声明全局变量
    
    total_downloaded = 0
    total_skipped = 0
    total_failed = 0
    
    while download_queue:
        item = download_queue.popleft()
        anime_id = item['anime_id']
        anime_title = item['anime_title']
        episodes = item['episodes']
        line = item['line']
        
        # 创建番剧目录
        anime_dir = f"/vol02/1000-0-f9cce6a6/数据/动漫/{anime_title}"
        if not os.path.exists(anime_dir):
            os.makedirs(anime_dir)
        
        downloaded = 0
        skipped = 0
        failed = 0
        
        print(f"\n开始下载: {anime_title} ({len(episodes)}集)")
        
        for ep in episodes:
            ep_num = ep['episode_number']
            
            # 检查是否已下载
            history_key = f"{anime_id}-{line['id']}-{ep_num}"
            file_path = os.path.join(anime_dir, f"第{ep_num}集.mp4")
            
            if os.path.exists(file_path) or download_history.get(history_key):
                print(f"第{ep_num}集已存在，跳过下载")
                skipped += 1
                total_skipped += 1
                continue
            
            # 获取视频链接
            print(f"\n解析第{ep_num}集视频地址...")
            video_url = None
            for attempt in range(3):  # 重试3次
                video_url = get_video_url(ep['url'], ep_num)
                if video_url:
                    break
                time.sleep(2)  # 等待2秒后重试
            
            if not video_url:
                print(f"无法获取第{ep_num}集视频链接")
                failed += 1
                total_failed += 1
                continue
            
            # 清理URL
            video_url = clean_url(video_url)
            print(f"视频地址: {video_url}")
            
            # 下载视频 - 使用全局SESSION对象
            if download_video(video_url, f"第{ep_num}集.mp4", SESSION, anime_dir):
                # 记录下载历史
                download_history[history_key] = {
                    "title": anime_title,
                    "episode": ep_num,
                    "date": time.strftime("%Y-%m-%d %H:%M:%S")
                }
                downloaded += 1
                total_downloaded += 1
            else:
                failed += 1
                total_failed += 1
        
        # 生成单个番剧报告
        generate_report(anime_title, len(episodes), downloaded, skipped, failed)
    
    # 生成总报告
    print("\n=== 总下载报告 ===")
    print(f"总剧集数: {total_downloaded + total_skipped + total_failed}")
    print(f"已下载: {total_downloaded}")
    print(f"跳过: {total_skipped}")
    print(f"失败: {total_failed}")
    print(f"成功率: {(total_downloaded/(total_downloaded+total_failed)*100) if total_downloaded+total_failed > 0 else 100:.1f}%")
    
    save_queue_and_history()
    input("\n按Enter继续...")

def save_queue_and_history():
    """保存下载队列和历史到文件"""
    global download_queue, download_history
    
    # 将队列转换为列表（deque不可序列化）
    queue_list = list(download_queue)
    
    data = {
        "queue": queue_list,
        "history": download_history
    }
    
    with open("queue_and_history.json", "w") as f:
        json.dump(data, f)

def save_preupdate_queue():
    """保存预更新队列到文件"""
    global preupdate_queue
    with open(PREUPDATE_FILE, "w") as f:
        json.dump(preupdate_queue, f)

def load_preupdate_queue():
    """从文件加载预更新队列并确保所有条目都有必要字段"""
    global preupdate_queue
    try:
        if os.path.exists(PREUPDATE_FILE):
            with open(PREUPDATE_FILE, "r") as f:
                preupdate_queue = json.load(f)
            
            # 确保旧数据有必要的字段
            for item in preupdate_queue:
                if 'downloaded' not in item:
                    item['downloaded'] = 0
                if 'pending' not in item:
                    item['pending'] = 0
    except:
        preupdate_queue = []

def load_queue_and_history():
    """从文件加载下载队列和历史"""
    global download_queue, download_history
    
    try:
        if os.path.exists("queue_and_history.json"):
            with open("queue_and_history.json", "r") as f:
                data = json.load(f)
                download_queue = deque(data.get("queue", []))
                download_history = data.get("history", {})
    except:
        download_queue = deque()
        download_history = {}

def download_single_episode(anime_title, anime_url, line, ep_num):
    """下载单集剧集 - 添加历史记录检查"""
    try:
        # 检查是否已下载
        history_key = f"{anime_title}-{line['id']}-{ep_num}"
        if history_key in download_history:
            print(f"第{ep_num}集已下载，跳过")
            return True
        
        # 获取剧集信息
        episodes = get_latest_episodes(anime_url, line['id'])
        if not episodes:
            print(f"无法获取剧集信息: {anime_title}")
            return False
        
        # 检查剧集号是否有效
        if ep_num < 1 or ep_num > len(episodes):
            print(f"剧集号 {ep_num} 无效")
            return False
            
        ep = episodes[ep_num - 1]
        
        # 获取视频URL
        print(f"解析第{ep_num}集视频地址...")
        video_url = get_video_url(ep['url'], ep_num)
        if not video_url:
            print(f"无法获取第{ep_num}集视频链接")
            return False
            
        # 清理URL
        video_url = clean_url(video_url)
        print(f"视频地址: {video_url}")
        
        # 创建番剧目录
        anime_dir = f"C:/Users/Administrator/Videos/动漫/{anime_title}"
        if not os.path.exists(anime_dir):
            os.makedirs(anime_dir)
        
        # 下载视频
        if download_video(video_url, f"第{ep_num}集.mp4", SESSION, anime_dir):
            # 记录下载历史
            download_history[history_key] = {
                "title": anime_title,
                "episode": ep_num,
                "date": time.strftime("%Y-%m-%d %H:%M:%S"),
                "url": ep['url']
            }
            return True
        return False
        
    except Exception as e:
        print(f"下载单集出错: {e}")
        import traceback
        traceback.print_exc()  # 打印完整错误堆栈
        return False

def show_queue():
    """显示当前下载队列"""
    global download_queue  # 声明全局变量
    if not download_queue:
        print("\n当前下载队列为空")
        return
    
    print("\n当前下载队列:")
    for i, item in enumerate(download_queue, 1):
        anime_title = item["anime_title"]
        episodes = item["episodes"]
        print(f"{i}. {anime_title} ({len(episodes)}集)")

def generate_report(anime_title, total, downloaded, skipped, failed):
    """生成下载报告"""
    print("\n=== 下载报告 ===")
    print(f"番剧名称: {anime_title}")
    print(f"总剧集数: {total}")
    print(f"已下载: {downloaded}")
    print(f"跳过: {skipped} (已存在)")
    print(f"失败: {failed}")
    print(f"成功率: {(downloaded / total * 100) if total > 0 else 100:.1f}%")
    print("\n按Enter继续，输入q退出")

if __name__ == "__main__":
    load_queue_and_history()
    load_preupdate_queue()
    main()
