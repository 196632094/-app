package com.xxla.mh.di

import com.xxla.mh.data.anime.AnimeDataSource
import com.xxla.mh.data.anime.XifanDataSource
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AnimeModule {
    @Binds
    @Singleton
    abstract fun bindAnimeDataSource(impl: XifanDataSource): AnimeDataSource
}

