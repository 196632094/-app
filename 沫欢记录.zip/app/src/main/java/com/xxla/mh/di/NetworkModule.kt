package com.xxla.mh.di

import com.xxla.mh.network.ApiService
import com.xxla.mh.network.MessageApiService
import com.xxla.mh.network.SearchApiService
import com.xxla.mh.network.VideoApiService
import com.xxla.mh.network.UserApiService
import com.xxla.mh.network.UpdateApiService
import com.xxla.mh.network.AuthInterceptor
import com.xxla.mh.network.ApiConfig
import com.xxla.mh.network.ChatApiService
import com.xxla.mh.network.CoupleApiService
import com.xxla.mh.network.CoupleAlbumApiService
import com.xxla.mh.network.MissYouApiService
import com.xxla.mh.network.PostApiService
import com.xxla.mh.network.StickerApiService
import com.xxla.mh.network.HistoryApiService
import com.xxla.mh.network.PostHistoryApiService
import com.xxla.mh.network.PresenceApiService
import com.xxla.mh.network.WatchApiService
import com.xxla.mh.network.RetryInterceptor
import com.xxla.mh.data.UserPreferencesRepository
import com.xxla.mh.data.api.AdminApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton
import javax.inject.Named

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideLoggingInterceptor(): HttpLoggingInterceptor {
        return HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
    }

    @Provides
    @Singleton
    fun provideAuthInterceptor(
        userPreferencesRepository: UserPreferencesRepository
    ): AuthInterceptor {
        return AuthInterceptor(userPreferencesRepository)
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(
        authInterceptor: AuthInterceptor,
        loggingInterceptor: HttpLoggingInterceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .addInterceptor(authInterceptor)
            // GET 请求网络失败自动重试（除显式禁用的请求外）
            .addInterceptor(RetryInterceptor())
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    // 外部站点抓取专用客户端（不添加鉴权头）
    @Provides
    @Singleton
    @Named("externalHttp")
    fun provideExternalOkHttpClient(
        loggingInterceptor: HttpLoggingInterceptor
    ): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(ApiConfig.API_BASE + "/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideApiService(retrofit: Retrofit): ApiService {
        return retrofit.create(ApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideVideoApiService(retrofit: Retrofit): VideoApiService {
        return retrofit.create(VideoApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideAdminApiService(retrofit: Retrofit): AdminApiService {
        return retrofit.create(AdminApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideSearchApiService(retrofit: Retrofit): SearchApiService {
        return retrofit.create(SearchApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideMessageApiService(retrofit: Retrofit): MessageApiService {
        return retrofit.create(MessageApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideUserApiService(retrofit: Retrofit): UserApiService {
        return retrofit.create(UserApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideUpdateApiService(retrofit: Retrofit): UpdateApiService {
        return retrofit.create(UpdateApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideChatApiService(retrofit: Retrofit): ChatApiService {
        return retrofit.create(ChatApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideCoupleApiService(retrofit: Retrofit): CoupleApiService {
        return retrofit.create(CoupleApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideCoupleAlbumApiService(retrofit: Retrofit): CoupleAlbumApiService {
        return retrofit.create(CoupleAlbumApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideMissYouApiService(retrofit: Retrofit): MissYouApiService {
        return retrofit.create(MissYouApiService::class.java)
    }


    @Provides
    @Singleton
    fun providePostApiService(retrofit: Retrofit): PostApiService {
        return retrofit.create(PostApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideStickerApiService(retrofit: Retrofit): StickerApiService {
        return retrofit.create(StickerApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideHistoryApiService(retrofit: Retrofit): HistoryApiService {
        return retrofit.create(HistoryApiService::class.java)
    }

    @Provides
    @Singleton
    fun providePresenceApiService(retrofit: Retrofit): PresenceApiService {
        return retrofit.create(PresenceApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideWatchApiService(retrofit: Retrofit): WatchApiService {
        return retrofit.create(WatchApiService::class.java)
    }

    @Provides
    @Singleton
    fun providePostHistoryApiService(retrofit: Retrofit): PostHistoryApiService {
        return retrofit.create(PostHistoryApiService::class.java)
    }
}
