package com.xxla.mh.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Message
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BottomNavItem(
    val route: String,
    val icon: ImageVector,
    val title: String
) {
    object Home : BottomNavItem("home", Icons.Default.Home, "首页")
    object Chat : BottomNavItem("chat", Icons.Default.Message, "聊天")
    object Upload : BottomNavItem("upload", Icons.Default.Add, "发布")
    object Profile : BottomNavItem("profile", Icons.Default.Person, "我的")
}

val bottomNavItems = listOf(
    BottomNavItem.Home,
    BottomNavItem.Chat,
    BottomNavItem.Upload,
    BottomNavItem.Profile
)
