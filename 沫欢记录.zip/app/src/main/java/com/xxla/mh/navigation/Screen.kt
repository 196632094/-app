package com.xxla.mh.navigation
import com.google.gson.Gson

sealed class Screen(val route: String) {
    // 主要导航屏幕
    object Home : Screen("home")
    object Upload : Screen("upload")
    object Profile : Screen("profile")
    object Chat : Screen("chat")
    // 一起看入口
    object WatchTogether : Screen("watch_together")
    // 想念记录列表
    object MissYouSent : Screen("missyou_sent")
    // 情侣空间
    object CoupleSpace : Screen("couple_space")
    object CoupleAlbum : Screen("couple_album")
    object ChatConversation : Screen("chat_conversation/{peerId}?name={name}&avatar={avatar}") {
        fun createRoute(peerId: String, name: String = "", avatar: String = ""): String {
            val n = java.net.URLEncoder.encode(name, "UTF-8")
            val a = java.net.URLEncoder.encode(avatar, "UTF-8")
            return "chat_conversation/$peerId?name=$n&avatar=$a"
        }
    }
    
    // 认证屏幕
    object Login : Screen("login")
    object Register : Screen("register")
    
    // 视频相关屏幕
    object VideoPlayer : Screen("video_player/{videoId}") {
        fun createRoute(videoId: String, source: String? = null): String {
            return if (source.isNullOrBlank()) {
                "video_player/$videoId"
            } else {
                "video_player/$videoId?source=$source"
            }
        }

        // 自定义深链，支持携带起始进度
        fun createDeepLink(videoId: String, source: String? = null, startMs: Long? = null): String {
            val s = (startMs ?: 0L).toString()
            val src = source ?: ""
            return "mh://video_play?videoId=$videoId&source=$src&startMs=$s"
        }
    }
    
    object VideoDetail : Screen("video_detail/{videoId}") {
        fun createRoute(videoId: String) = "video_detail/$videoId"
    }
    
    // 帖子详情
    object PostDetail : Screen("post_detail/{postId}") {
        fun createRoute(postId: String) = "post_detail/$postId"
    }
    
    // 视频编辑
    object EditVideo : Screen("edit_video/{videoId}") {
        fun createRoute(videoId: String) = "edit_video/$videoId"
    }
    
    // 帖子编辑
    object EditPost : Screen("edit_post/{postId}") {
        fun createRoute(postId: String) = "edit_post/$postId"
    }
    
    // 用户相关屏幕
    object UserProfile : Screen("user_profile/{userId}") {
        fun createRoute(userId: String) = "user_profile/$userId"
    }
    object FollowersList : Screen("followers/{userId}") {
        fun createRoute(userId: String) = "followers/$userId"
    }
    object FollowingList : Screen("following/{userId}") {
        fun createRoute(userId: String) = "following/$userId"
    }
    
    object Settings : Screen("settings")
    object History : Screen("history")
    object Messages : Screen("messages")
    object Favorites : Screen("favorites")
    
    // 搜索屏幕
    object AnimeSearch : Screen("anime_search")
    object AnimeDetail : Screen("anime_detail?url={url}&title={title}") {
        fun createRoute(url: String, title: String = ""): String {
            val encodedUrl = java.net.URLEncoder.encode(url, "UTF-8")
            val encodedTitle = java.net.URLEncoder.encode(title, "UTF-8")
            return "anime_detail?url=$encodedUrl&title=$encodedTitle"
        }
    }
    object AnimePlay : Screen("anime_play?title={title}&episodeUrl={episodeUrl}&videoUrl={videoUrl}&headers={headers}&startMs={startMs}&peerId={peerId}&peerName={peerName}&peerAvatar={peerAvatar}") {
        fun createRoute(
            title: String,
            episodeUrl: String,
            videoUrl: String? = null,
            headers: Map<String, String>? = null,
            startMs: Long? = null,
            peerId: String? = null,
            peerName: String? = null,
            peerAvatar: String? = null
        ): String {
            val t = java.net.URLEncoder.encode(title, "UTF-8")
            val u = java.net.URLEncoder.encode(episodeUrl, "UTF-8")
            val v = java.net.URLEncoder.encode(videoUrl ?: "", "UTF-8")
            val hJson = Gson().toJson(headers ?: emptyMap<String, String>())
            val h = java.net.URLEncoder.encode(hJson, "UTF-8")
            val s = (startMs ?: 0L).toString()
            val pid = java.net.URLEncoder.encode(peerId ?: "", "UTF-8")
            val pn = java.net.URLEncoder.encode(peerName ?: "", "UTF-8")
            val pa = java.net.URLEncoder.encode(peerAvatar ?: "", "UTF-8")
            return "anime_play?title=$t&episodeUrl=$u&videoUrl=$v&headers=$h&startMs=$s&peerId=$pid&peerName=$pn&peerAvatar=$pa"
        }

        // External deep link (custom scheme) for sharing outside the app
        fun createDeepLink(title: String, episodeUrl: String, videoUrl: String? = null, headers: Map<String, String>? = null, startMs: Long? = null): String {
            val t = java.net.URLEncoder.encode(title, "UTF-8")
            val u = java.net.URLEncoder.encode(episodeUrl, "UTF-8")
            val v = java.net.URLEncoder.encode(videoUrl ?: "", "UTF-8")
            val hJson = Gson().toJson(headers ?: emptyMap<String, String>())
            val h = java.net.URLEncoder.encode(hJson, "UTF-8")
            val s = (startMs ?: 0L).toString()
            return "mh://anime_play?title=$t&episodeUrl=$u&videoUrl=$v&headers=$h&startMs=$s"
        }
    }
    object Search : Screen("search")
    object SearchResult : Screen("search_result/{query}") {
        fun createRoute(query: String) = "search_result/$query"
    }
}
