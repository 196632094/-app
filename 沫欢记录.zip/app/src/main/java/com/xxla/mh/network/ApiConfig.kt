package com.xxla.mh.network

import com.xxla.mh.BuildConfig

object ApiConfig {
    // 统一域名配置（不带结尾斜杠），由 BuildConfig 注入
    val API_BASE: String = BuildConfig.API_BASE
}
