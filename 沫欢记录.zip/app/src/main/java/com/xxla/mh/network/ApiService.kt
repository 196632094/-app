package com.xxla.mh.network

import com.xxla.mh.data.User
import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {
    @POST("api/auth/login")
    suspend fun login(@Body loginRequest: LoginRequest): Response<AuthResponse>

    @POST("api/auth/register")
    suspend fun register(@Body registerRequest: RegisterRequest): Response<AuthResponse>

    // 一体化登录/注册（用户名+密码）
    @POST("api/auth/loginOrRegister")
    suspend fun loginOrRegister(@Body loginRequest: LoginRequest): Response<AuthResponse>

    // 上传头像
    @Multipart
    @POST("api/user/avatar")
    suspend fun uploadAvatar(@Part avatar: MultipartBody.Part): Response<UploadAvatarResponse>

    // 更新资料（昵称/签名）
    @POST("api/user/profile")
    suspend fun updateProfile(@Body body: UpdateProfileRequest): Response<UpdateProfileResponse>
}

data class LoginRequest(
    val username: String,
    val password: String
)

data class RegisterRequest(
    val username: String,
    val email: String,
    val password: String
)

data class AuthResponse(
    val success: Boolean,
    val message: String,
    val data: AuthData?
)

data class AuthData(
    val user: User,
    val token: String,
    val isNewUser: Boolean? = null
)

data class UploadAvatarResponse(
    val success: Boolean,
    val message: String,
    val data: UploadAvatarData
)

data class UploadAvatarData(
    val avatarUrl: String,
    val user: User
)

data class UpdateProfileRequest(
    val nickname: String? = null,
    val signature: String? = null
)

data class UpdateProfileResponse(
    val success: Boolean,
    val message: String,
    val data: UpdateProfileData?
)

data class UpdateProfileData(
    val user: User
)
