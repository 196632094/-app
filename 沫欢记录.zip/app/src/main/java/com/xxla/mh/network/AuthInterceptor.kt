package com.xxla.mh.network

import com.xxla.mh.data.UserPreferencesRepository
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(
    private val userPreferencesRepository: UserPreferencesRepository
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        // Read token synchronously for simplicity; avoids making OkHttp interceptor suspend
        val token = runBlocking {
            userPreferencesRepository.userPreferencesFlow.first().token
        }
        val builder = original.newBuilder()
        if (!token.isNullOrBlank()) {
            builder.addHeader("Authorization", "Bearer $token")
        }
        return chain.proceed(builder.build())
    }
}

