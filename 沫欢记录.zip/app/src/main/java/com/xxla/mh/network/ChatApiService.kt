package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.DELETE

/**
 * 私信聊天相关API
 */
interface ChatApiService {
    // 联系人列表（含互相关注等状态）
    @GET("api/chat/contacts")
    suspend fun getContacts(): Response<ChatContactListResponse>

    // 会话消息列表（与指定用户的双向聊天记录）
    @GET("api/chat/{peerId}/messages")
    suspend fun getConversation(
        @Path("peerId") peerId: String,
        @Query("limit") limit: Int? = null,
        @Query("before") before: Long? = null,
        @Query("after") after: Long? = null
    ): Response<ChatMessageListResponse>

    // 发送消息
    @POST("api/chat/{peerId}/messages")
    suspend fun sendMessage(
        @Path("peerId") peerId: String,
        @Body req: SendMessageRequest
    ): Response<ChatSendMessageResponse>

    // 将与某人的未读消息标记为已读
    @POST("api/chat/{peerId}/read")
    suspend fun markRead(@Path("peerId") peerId: String): Response<ChatMarkReadResponse>

    // 未读消息数量（所有会话汇总）
    @GET("api/chat/unreadCount")
    suspend fun getUnreadCount(): Response<UnreadCountResponse>

    // 撤回消息（2分钟窗口，服务端校验）
    @POST("api/chat/{peerId}/messages/{messageId}/recall")
    suspend fun recallMessage(
        @Path("peerId") peerId: String,
        @Path("messageId") messageId: String
    ): Response<ChatRecallResponse>
}

// 数据模型
data class ChatContactListResponse(
    val success: Boolean,
    val message: String,
    val data: ChatContactListData
)

data class ChatContactListData(
    val contacts: List<ChatContact>
)

data class ChatContact(
    val id: String,
    val username: String,
    val nickname: String?,
    val avatar: String?,
    val isFollowing: Boolean?,
    val isFollower: Boolean?,
    val isFriend: Boolean?,
    val online: Boolean? = null,
    val lastOnlineAt: Long? = null,
    val unreadCount: Int? = null
)

data class ChatMessageListResponse(
    val success: Boolean,
    val message: String,
    val data: ChatMessageListData
)

data class ChatMessageListData(
    val messages: List<ChatMessage>
)

data class ChatMessage(
    val id: String,
    val fromUserId: String,
    val toUserId: String,
    val content: String,
    val timestamp: Long,
    val isMine: Boolean,
    val read: Boolean,
    val recalled: Boolean?
)

data class SendMessageRequest(
    val content: String
)

data class ChatSendMessageResponse(
    val success: Boolean,
    val message: String,
    val data: ChatMessage
)

data class ChatRecallResponse(
    val success: Boolean,
    val message: String,
    val data: ChatMessage
)

data class ChatMarkReadResponse(
    val success: Boolean,
    val message: String,
    val data: MarkReadData
)

data class MarkReadData(
    val changed: Int
)

