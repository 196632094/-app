package com.xxla.mh.network

import okhttp3.MultipartBody
import retrofit2.Response
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path

/**
 * 情侣共同相册相关API
 */
interface CoupleAlbumApiService {
    // 列出共同相册图片
    @GET("api/couple/album")
    suspend fun getAlbum(): Response<CoupleAlbumListResponse>

    // 上传共同相册图片（最多12张）
    @Multipart
    @POST("api/couple/album/upload")
    suspend fun uploadImages(
        @Part images: List<MultipartBody.Part>
    ): Response<CoupleAlbumUploadResponse>

    // 删除共同相册图片
    @DELETE("api/couple/album/{filename}")
    suspend fun deleteImage(@Path("filename") filename: String): Response<BaseResponse>
}

data class CoupleAlbumListResponse(
    val success: Boolean,
    val message: String,
    val data: List<CoupleAlbumItem>
)

data class CoupleAlbumUploadResponse(
    val success: Boolean,
    val message: String,
    val data: List<CoupleAlbumItem>
)

data class CoupleAlbumItem(
    val id: String,
    val url: String,
    val uploadedAtMs: Long,
    // 可选：后端若提供视频标记与元数据，前端用于展示
    val isVideo: Boolean? = null,
    val durationSec: Int? = null,
    val coverUrl: String? = null
)
