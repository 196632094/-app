package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/**
 * 情侣空间相关API
 */
interface CoupleApiService {
    // 获取情侣信息（若当前用户属于情侣ID集，则返回对方及关系信息）
    @GET("api/couple")
    suspend fun getCoupleInfo(): Response<CoupleInfoResponse>

    // 设定/更新情侣关系
    @POST("api/couple")
    suspend fun setCouple(@Body req: CoupleUpdateRequest): Response<BaseResponse>
}

data class CoupleInfoResponse(
    val success: Boolean,
    val message: String,
    val data: CoupleInfo?
)

data class CoupleInfo(
    val partner: ChatContact,
    val startAt: Long?
)

data class CoupleUpdateRequest(
    val partnerId: String,
    val startedAtMs: Long?
)
