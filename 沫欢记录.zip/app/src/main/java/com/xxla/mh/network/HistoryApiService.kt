package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * 观看历史云端API
 */
interface HistoryApiService {
    @GET("api/history")
    suspend fun getHistory(): Response<HistoryListResponse>

    @POST("api/history")
    suspend fun addOrUpdate(@Body req: AddHistoryRequest): Response<BaseResponse>

    @DELETE("api/history/{id}")
    suspend fun delete(@Path("id") id: String): Response<BaseResponse>

    @DELETE("api/history")
    suspend fun clearAll(): Response<BaseResponse>
}

data class AddHistoryRequest(
    val videoId: String,
    val watchedDuration: Int,
    val totalDuration: Int
)

data class HistoryListResponse(
    val success: Boolean,
    val message: String,
    val data: HistoryListData
)

data class HistoryListData(
    val history: List<HistoryItemRemote>
)

data class HistoryItemRemote(
    val id: String,
    val videoId: String,
    val title: String,
    val thumbnailUrl: String?,
    val authorName: String?,
    val watchTime: String?, // ISO格式
    val watchedDuration: Int?,
    val totalDuration: Int?
)

