package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.POST

/**
 * 消息中心相关API服务
 */
interface MessageApiService {
    // 获取消息列表，按类型筛选：like/comment/follow/system/all
    @GET("api/messages")
    suspend fun getMessages(@Query("type") type: String): Response<MessageListResponse>

    // 标记消息为已读
    @POST("api/messages/{id}/read")
    suspend fun markAsRead(@Path("id") messageId: String): Response<BaseResponse>

    // 删除单条消息
    @DELETE("api/messages/{id}")
    suspend fun deleteMessage(@Path("id") messageId: String): Response<BaseResponse>

    // 清空所有消息
    @DELETE("api/messages")
    suspend fun clearAllMessages(): Response<BaseResponse>

    // 未读消息数量
    @GET("api/messages/unreadCount")
    suspend fun getUnreadCount(): Response<UnreadCountResponse>
}

data class MessageListResponse(
    val success: Boolean,
    val message: String,
    val data: MessageListData
)

data class MessageListData(
    val messages: List<MessageItem>
)

/**
 * 服务端消息模型
 */
data class MessageItem(
    val id: String,
    val type: String,
    val senderId: String?,
    val senderName: String?,
    val senderAvatar: String?,
    val content: String?,
    val time: String?,
    val timestamp: Long?,
    val relatedId: String?
)

data class UnreadCountResponse(
    val success: Boolean,
    val message: String,
    val data: UnreadCountData
)

data class UnreadCountData(
    val count: Int
)

