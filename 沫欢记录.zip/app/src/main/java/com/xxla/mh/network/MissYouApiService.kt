package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.DELETE
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * 想念（Miss-You）相关API
 */
interface MissYouApiService {
    // 发送想念
    @POST("api/missyou")
    suspend fun sendMissYou(@Body req: MissYouSendRequest): Response<MissYouSendResponse>

    // 获取我待接收的最近一条想念
    @GET("api/missyou/pending")
    suspend fun getPending(): Response<MissYouPendingResponse>

    // 确认收到想念
    @POST("api/missyou/ack")
    suspend fun acknowledge(@Body req: MissYouAckRequest): Response<MissYouAckResponse>

    // 我发出的想念记录列表（支持分页：limit/before/after）
    @GET("api/missyou/sent")
    suspend fun getSent(
        @Query("limit") limit: Int? = null,
        @Query("before") before: Long? = null,
        @Query("after") after: Long? = null
    ): Response<MissYouSentListResponse>

    // 删除我发出的某条想念
    @DELETE("api/missyou/{id}")
    suspend fun deleteSent(@Path("id") id: String): Response<MissYouDeleteResponse>
}

// 请求与响应模型
data class MissYouSendRequest(
    val content: String,
    val preset: String? = null
)

data class MissYouSendResponse(
    val success: Boolean,
    val message: String,
    val data: MissYouItem?
)

data class MissYouAckRequest(
    val id: String
)

data class MissYouAckResponse(
    val success: Boolean,
    val message: String,
    val data: MissYouItem?
)

data class MissYouPendingResponse(
    val success: Boolean,
    val message: String,
    val data: MissYouPendingItem?
)

data class MissYouSentListResponse(
    val success: Boolean,
    val message: String,
    val data: MissYouSentListData?
)

data class MissYouSentListData(
    val items: List<MissYouItem>,
    val hasMore: Boolean? = null,
    val nextBefore: Long? = null
)

data class MissYouDeleteResponse(
    val success: Boolean,
    val message: String
)

// 记录项
data class MissYouItem(
    val id: String,
    val toUserId: String?,
    val toName: String?,
    val content: String,
    val preset: String? = null,
    val sentAt: String,
    val received: Boolean,
    val receivedAt: String?
)

// 待接收项（用于展示全屏）
data class MissYouPendingItem(
    val id: String,
    val fromUserId: String,
    val fromName: String,
    val content: String,
    val preset: String? = null,
    val sentAt: String
)
