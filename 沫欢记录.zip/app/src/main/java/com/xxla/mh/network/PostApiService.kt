package com.xxla.mh.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Multipart
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Query
import retrofit2.http.Path
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.Header

/**
 * 通用内容发布（文章/图片/音乐）
 */
interface PostApiService {
    // 列表获取：文章/图片/音乐
    @GET("api/posts")
    suspend fun getPosts(
        @Query("type") type: String = "all",
        @Query("page") page: Int,
        @Query("size") size: Int,
        @Header("X-No-Retry") noRetry: String? = null
    ): Response<PostListResponse>

    @Multipart
    @POST("api/posts/upload")
    suspend fun uploadPost(
        @Part("type") type: RequestBody,
        @Part images: List<MultipartBody.Part>?,
        @Part audio: MultipartBody.Part?,
        @Part cover: MultipartBody.Part?,
        @Part("title") title: RequestBody?,
        @Part("content") content: RequestBody?,
        @Part("description") description: RequestBody?,
        @Part("tags") tags: RequestBody?,
        @Part("isPublic") isPublic: RequestBody
    ): Response<UploadPostResponse>

    // 更新帖子（编辑元信息，或可选替换媒体/封面）
    @Multipart
    @PUT("api/posts/{postId}")
    suspend fun updatePost(
        @Path("postId") postId: String,
        @Part("type") type: RequestBody?,
        @Part images: List<MultipartBody.Part>?,
        @Part audio: MultipartBody.Part?,
        @Part cover: MultipartBody.Part?,
        @Part("title") title: RequestBody?,
        @Part("content") content: RequestBody?,
        @Part("description") description: RequestBody?,
        @Part("tags") tags: RequestBody?,
        @Part("isPublic") isPublic: RequestBody?
    ): Response<BaseResponse>

    // 获取帖子详情
    @GET("api/posts/{postId}")
    suspend fun getPostDetail(@Path("postId") postId: String): Response<PostDetailResponse>

    // 点赞帖子
    @POST("api/posts/{postId}/like")
    suspend fun likePost(@Path("postId") postId: String): Response<BaseResponse>

    // 取消点赞帖子
    @DELETE("api/posts/{postId}/like")
    suspend fun unlikePost(@Path("postId") postId: String): Response<BaseResponse>

    // 删除帖子
    @DELETE("api/posts/{postId}")
    suspend fun deletePost(@Path("postId") postId: String): Response<BaseResponse>

    // 获取帖子评论
    @GET("api/posts/{postId}/comments")
    suspend fun getComments(
        @Path("postId") postId: String,
        @Query("page") page: Int,
        @Query("size") size: Int
    ): Response<CommentListResponse>

    // 发表评论到帖子
    @POST("api/posts/{postId}/comments")
    suspend fun postComment(
        @Path("postId") postId: String,
        @Body comment: CommentRequest
    ): Response<CommentResponse>

    // 点赞帖子中的评论
    @POST("api/posts/{postId}/comments/{commentId}/like")
    suspend fun likeComment(
        @Path("postId") postId: String,
        @Path("commentId") commentId: String
    ): Response<BaseResponse>

    // 取消点赞帖子中的评论
    @DELETE("api/posts/{postId}/comments/{commentId}/like")
    suspend fun unlikeComment(
        @Path("postId") postId: String,
        @Path("commentId") commentId: String
    ): Response<BaseResponse>

    // 删除帖子中的评论（仅作者可删，顶层会级联其回复）
    @DELETE("api/posts/{postId}/comments/{commentId}")
    suspend fun deleteComment(
        @Path("postId") postId: String,
        @Path("commentId") commentId: String
    ): Response<BaseResponse>
}

data class PostListResponse(
    val success: Boolean,
    val message: String,
    val data: PostListData
)

data class PostListData(
    val posts: List<PostItem>,
    val totalPages: Int,
    val currentPage: Int
)

data class PostItem(
    val id: String,
    val type: String, // article | images | music
    val title: String?,
    val content: String?,
    val description: String?,
    val images: List<String>?,
    val audioUrl: String?,
    val coverUrl: String?,
    val duration: Int?,
    val author: UserBrief?,
    val createdAt: String?,
    // 后端列表接口补充的统计与状态（为兼容，设为可空）
    val likeCount: Int? = null,
    val commentCount: Int? = null,
    val isLiked: Boolean? = null
)

data class PostDetailResponse(
    val success: Boolean,
    val message: String,
    val data: PostDetail
)

data class PostDetail(
    val id: String,
    val type: String,
    val title: String?,
    val content: String?,
    val description: String?,
    val images: List<String>?,
    val audioUrl: String?,
    val coverUrl: String?,
    val duration: Int?,
    val likeCount: Int,
    val commentCount: Int,
    val author: UserBrief,
    val tags: List<String>,
    val isLiked: Boolean,
    val createdAt: String
)

data class UploadPostResponse(
    val success: Boolean,
    val message: String,
    val data: UploadPostData
)

data class UploadPostData(
    val postId: String,
    val type: String,
    val urls: List<String>?,
    val audioUrl: String?,
    val coverUrl: String?
)
