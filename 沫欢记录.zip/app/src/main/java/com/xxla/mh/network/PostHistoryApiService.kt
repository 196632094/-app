package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * 帖子浏览历史 云端API
 */
interface PostHistoryApiService {
    @GET("api/post-history")
    suspend fun getPostHistory(): Response<PostHistoryListResponse>

    @POST("api/post-history")
    suspend fun addOrUpdate(@Body req: AddPostHistoryRequest): Response<BaseResponse>

    @DELETE("api/post-history/{id}")
    suspend fun delete(@Path("id") id: String): Response<BaseResponse>

    @DELETE("api/post-history")
    suspend fun clearAll(): Response<BaseResponse>
}

data class AddPostHistoryRequest(
    val postId: String
)

data class PostHistoryListResponse(
    val success: Boolean,
    val message: String,
    val data: PostHistoryListData
)

data class PostHistoryListData(
    val history: List<PostHistoryItemRemote>
)

data class PostHistoryItemRemote(
    val id: String,
    val postId: String,
    val title: String,
    val coverUrl: String?,
    val authorName: String?,
    val readTime: String?, // ISO格式
    val type: String?
)

