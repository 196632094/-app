package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.POST

/**
 * 在线心跳 API
 */
interface PresenceApiService {
    @POST("api/presence/heartbeat")
    suspend fun heartbeat(): Response<BaseResponse>
}

