package com.xxla.mh.network

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * 通用网络重试拦截器：在网络不稳定导致连接失败时，针对 GET 请求进行自动重试。
 *
 * 规则：
 * - 默认仅对 GET 请求生效（幂等），避免对 POST/PUT 等产生重复提交风险。
 * - 可通过请求头 `X-No-Retry: true` 显式禁用重试（用于首页）。
 * - 对典型网络异常（UnknownHost/Connect/Timeout）与 503/504 响应进行有限次重试。
 * - 重试次数与退避时间较小，以提升交互体验：最多 2 次，分别等待 500ms、1000ms。
 */
class RetryInterceptor(
    private val maxAttempts: Int = 2,
    private val baseDelayMs: Long = 500L
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val method = request.method.uppercase()

        // 显式禁用重试
        val noRetryHeader = request.header("X-No-Retry")
        val noRetry = noRetryHeader?.lowercase() == "true"

        // 仅对 GET 并且未禁用重试的情况启用
        val enableRetry = !noRetry && method == "GET"

        if (!enableRetry) {
            return chain.proceed(request)
        }

        var attempt = 0
        var lastException: IOException? = null
        var lastResponse: Response? = null

        while (attempt <= maxAttempts) {
            try {
                val response = chain.proceed(request)
                // 针对 503/504（服务不可用/网关超时）尝试重试
                if (response.code == 503 || response.code == 504) {
                    lastResponse = response
                    // 关闭响应以避免连接泄漏
                    try { response.close() } catch (_: Exception) {}
                    if (attempt == maxAttempts) break
                    backoffDelay(attempt)
                    attempt++
                    continue
                }
                return response
            } catch (e: IOException) {
                lastException = e
                // 仅在典型的网络异常下重试
                val isNetworkIssue = e is UnknownHostException || e is ConnectException || e is SocketTimeoutException
                if (!isNetworkIssue || attempt == maxAttempts) {
                    break
                }
                backoffDelay(attempt)
                attempt++
            }
        }

        // 如果有最后一次响应（非成功的 503/504），优先返回它；否则抛出异常
        lastResponse?.let { return it }
        throw lastException ?: IOException("Request failed and no further detail available")
    }

    private fun backoffDelay(attempt: Int) {
        // 线性退避：0->500ms, 1->1000ms
        val delay = baseDelayMs * (attempt + 1)
        try {
            Thread.sleep(delay)
        } catch (_: InterruptedException) { /* ignore */ }
    }
}

