package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface SearchApiService {
    // 搜索视频
    @GET("api/search/videos")
    suspend fun searchVideos(
        @Query("query") query: String,
        @Query("page") page: Int? = null,
        @Query("size") size: Int? = null
    ): Response<SearchVideoResponse>

    // 搜索用户
    @GET("api/search/users")
    suspend fun searchUsers(
        @Query("query") query: String,
        @Query("page") page: Int? = null,
        @Query("size") size: Int? = null
    ): Response<SearchUserResponse>
}

// 数据模型
data class SearchVideoResponse(
    val success: Boolean,
    val message: String,
    val data: SearchVideoListData
)

data class SearchVideoListData(
    val videos: List<SearchVideoItem>,
    val totalPages: Int?,
    val currentPage: Int?
)

data class SearchVideoItem(
    val id: String,
    val title: String,
    val coverUrl: String?,
    val videoUrl: String?,
    val duration: Int?,
    val viewCount: Int?,
    val likeCount: Int?,
    val author: UserBrief?
)

data class SearchUserResponse(
    val success: Boolean,
    val message: String,
    val data: SearchUserListData
)

data class SearchUserListData(
    val users: List<SearchUserItem>,
    val totalPages: Int?,
    val currentPage: Int?
)

data class SearchUserItem(
    val id: String,
    val username: String,
    val nickname: String?,
    val avatar: String?,
    val followersCount: Int?,
    val videosCount: Int?,
    val isFollowing: Boolean?,
    val isFollower: Boolean?,
    val isFriend: Boolean?
)
