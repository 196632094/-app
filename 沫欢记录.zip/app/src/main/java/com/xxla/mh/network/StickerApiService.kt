package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.GET

/**
 * 贴纸列表 API
 */
interface StickerApiService {
    @GET("api/enjoy")
    suspend fun getStickers(): Response<StickerResponse>
}

data class StickerResponse(
    val success: Boolean,
    val message: String,
    val data: StickerData?
)

data class StickerData(
    val items: List<StickerItem> = emptyList(),
    val count: Int = 0
)

data class StickerItem(
    val name: String,
    val url: String
)
