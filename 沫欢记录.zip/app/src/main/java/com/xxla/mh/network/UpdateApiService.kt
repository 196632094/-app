package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.GET

interface UpdateApiService {
    @GET("api/update-config")
    suspend fun getUpdateConfig(): Response<UpdateConfigResponse>
}

data class UpdateConfigResponse(
    val success: Boolean,
    val message: String,
    val data: UpdateConfigData?
)

data class UpdateConfigData(
    val enabled: Boolean,
    val builtin: Boolean = false,
    val url: String?,
    val notes: String? = null,
    val version: String? = null
)
