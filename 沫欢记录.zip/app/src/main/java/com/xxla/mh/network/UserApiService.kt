package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path

/**
 * 用户相关API服务
 */
interface UserApiService {
    // 获取用户统计：总获赞（不含评论）与作品数量
    @GET("api/users/{userId}/stats")
    suspend fun getUserStats(@Path("userId") userId: String): Response<UserStatsResponse>

    // 关注用户
    @retrofit2.http.POST("api/users/{userId}/follow")
    suspend fun follow(@Path("userId") userId: String): Response<SimpleResponse>

    // 取消关注
    @retrofit2.http.DELETE("api/users/{userId}/follow")
    suspend fun unfollow(@Path("userId") userId: String): Response<SimpleResponse>

    // 粉丝列表
    @GET("api/users/{userId}/followers")
    suspend fun getFollowers(@Path("userId") userId: String): Response<UserListResponse>

    // 关注列表
    @GET("api/users/{userId}/following")
    suspend fun getFollowing(@Path("userId") userId: String): Response<UserListResponse>
}

data class UserStatsResponse(
    val success: Boolean,
    val message: String,
    val data: UserStatsData
)

data class UserStatsData(
    val likesCount: Int,
    val videosCount: Int,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val isFollowing: Boolean = false
)

data class SimpleResponse(
    val success: Boolean,
    val message: String
)

data class UserListResponse(
    val success: Boolean,
    val message: String,
    val data: UserListData
)

data class UserListData(
    val users: List<UserBriefWithRelation>
)

// 为粉丝/关注列表提供的“带关系”的用户简要信息
data class UserBriefWithRelation(
    val id: String,
    val username: String,
    val nickname: String?,
    val avatar: String?,
    val isFollowing: Boolean? = null, // 我是否关注TA
    val isFollower: Boolean? = null,  // TA是否关注我（粉丝）
    val isFriend: Boolean? = null     // 是否互相关注
)

