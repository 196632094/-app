package com.xxla.mh.network

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*
import retrofit2.http.Header

interface VideoApiService {
    // 获取视频列表
    @GET("api/videos")
    suspend fun getVideos(
        @Query("page") page: Int,
        @Query("size") size: Int,
        @Query("category") category: String? = null,
        @Header("X-No-Retry") noRetry: String? = null
    ): Response<VideoListResponse>

    // 获取视频详情
    @GET("api/videos/{videoId}")
    suspend fun getVideoDetail(@Path("videoId") videoId: String): Response<VideoDetailResponse>

    // 上传视频
    @Multipart
    @POST("api/videos/upload")
    suspend fun uploadVideo(
        @Part video: MultipartBody.Part,
        @Part("title") title: RequestBody,
        @Part("description") description: RequestBody,
        @Part("tags") tags: RequestBody,
        @Part thumbnail: MultipartBody.Part? = null,
        @Part("isPublic") isPublic: RequestBody
    ): Response<UploadVideoResponse>

    // 点赞视频
    @POST("api/videos/{videoId}/like")
    suspend fun likeVideo(@Path("videoId") videoId: String): Response<BaseResponse>

    // 取消点赞
    @DELETE("api/videos/{videoId}/like")
    suspend fun unlikeVideo(@Path("videoId") videoId: String): Response<BaseResponse>

    // 记录唯一播放（每用户每视频仅一次）
    @POST("api/videos/{videoId}/view")
    suspend fun recordView(@Path("videoId") videoId: String): Response<RecordViewResponse>

    // 获取视频评论
    @GET("api/videos/{videoId}/comments")
    suspend fun getComments(
        @Path("videoId") videoId: String,
        @Query("page") page: Int,
        @Query("size") size: Int
    ): Response<CommentListResponse>

    // 发表评论
    @POST("api/videos/{videoId}/comments")
    suspend fun postComment(
        @Path("videoId") videoId: String,
        @Body comment: CommentRequest
    ): Response<CommentResponse>

    // 点赞评论
    @POST("api/videos/{videoId}/comments/{commentId}/like")
    suspend fun likeComment(
        @Path("videoId") videoId: String,
        @Path("commentId") commentId: String
    ): Response<BaseResponse>

    // 取消点赞评论
    @DELETE("api/videos/{videoId}/comments/{commentId}/like")
    suspend fun unlikeComment(
        @Path("videoId") videoId: String,
        @Path("commentId") commentId: String
    ): Response<BaseResponse>

    // 删除视频中的评论（仅作者可删，顶层会级联其回复）
    @DELETE("api/videos/{videoId}/comments/{commentId}")
    suspend fun deleteComment(
        @Path("videoId") videoId: String,
        @Path("commentId") commentId: String
    ): Response<BaseResponse>

    // 获取视频弹幕
    @GET("api/videos/{videoId}/danmaku")
    suspend fun getDanmaku(@Path("videoId") videoId: String): Response<DanmakuListResponse>

    // 发送弹幕
    @POST("api/videos/{videoId}/danmaku")
    suspend fun sendDanmaku(
        @Path("videoId") videoId: String,
        @Body danmaku: DanmakuRequest
    ): Response<BaseResponse>

    // 删除视频
    @DELETE("api/videos/{videoId}")
    suspend fun deleteVideo(@Path("videoId") videoId: String): Response<BaseResponse>

    // 更新视频（可选替换文件/封面）
    @Multipart
    @PUT("api/videos/{videoId}")
    suspend fun updateVideo(
        @Path("videoId") videoId: String,
        @Part("title") title: RequestBody?,
        @Part("description") description: RequestBody?,
        @Part("tags") tags: RequestBody?,
        @Part thumbnail: MultipartBody.Part? = null,
        @Part("isPublic") isPublic: RequestBody?,
        @Part video: MultipartBody.Part? = null
    ): Response<VideoDetailResponse>
}

// 数据模型
data class VideoListResponse(
    val success: Boolean,
    val message: String,
    val data: VideoListData
)

data class VideoListData(
    val videos: List<VideoItem>,
    val totalPages: Int,
    val currentPage: Int
)

data class VideoItem(
    val id: String,
    val title: String,
    val coverUrl: String,
    val videoUrl: String,
    val duration: Int,
    val viewCount: Int,
    val likeCount: Int,
    val commentCount: Int,
    val author: UserBrief,
    val createdAt: String,
    val isLiked: Boolean
)

data class UserBrief(
    val id: String,
    val username: String,
    val nickname: String?,
    val avatar: String?
)

data class VideoDetailResponse(
    val success: Boolean,
    val message: String,
    val data: VideoDetail
)

data class VideoDetail(
    val id: String,
    val title: String,
    val description: String,
    val videoUrl: String,
    val coverUrl: String,
    val duration: Int,
    val viewCount: Int,
    val likeCount: Int,
    val commentCount: Int,
    val author: UserBrief,
    val tags: List<String>,
    val isLiked: Boolean,
    val createdAt: String
)

data class UploadVideoResponse(
    val success: Boolean,
    val message: String,
    val data: UploadVideoData
)

data class UploadVideoData(
    val videoId: String,
    val videoUrl: String
)

data class BaseResponse(
    val success: Boolean,
    val message: String
)

data class RecordViewResponse(
    val success: Boolean,
    val message: String,
    val data: ViewRecordData
)

data class ViewRecordData(
    val viewCount: Int,
    val isNewView: Boolean
)

data class CommentListResponse(
    val success: Boolean,
    val message: String,
    val data: CommentListData
)

data class CommentListData(
    val comments: List<Comment>,
    val totalPages: Int,
    val currentPage: Int
)

data class Comment(
    val id: String,
    val content: String,
    val author: UserBrief,
    val createdAt: String,
    val likeCount: Int,
    val isLiked: Boolean,
    val parentId: String?
)

data class CommentRequest(
    val content: String,
    val parentId: String? = null
)

data class CommentResponse(
    val success: Boolean,
    val message: String,
    val data: Comment
)

data class DanmakuListResponse(
    val success: Boolean,
    val message: String,
    val data: List<Danmaku>
)

data class Danmaku(
    val id: String,
    val content: String,
    val time: Float,
    val color: String,
    val type: Int,
    val userId: String
)

data class DanmakuRequest(
    val content: String,
    val time: Float,
    val color: String,
    val type: Int
)
