package com.xxla.mh.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

data class WatchStartRequest(val contentKey: String)
data class WatchHeartbeatRequest(val contentKey: String)
data class WatchStopRequest(val contentKey: String)

data class WatchOnlineData(
    val onlineCount: Int,
    val userIds: List<String>
)

data class WatchOnlineResponse(
    val success: Boolean,
    val message: String,
    val data: WatchOnlineData
)

/**
 * 一起看会话在线统计 API
 */
interface WatchApiService {
    @POST("api/watch/start")
    suspend fun start(@Body body: WatchStartRequest): Response<BaseResponse>

    @POST("api/watch/heartbeat")
    suspend fun heartbeat(@Body body: WatchHeartbeatRequest): Response<BaseResponse>

    @POST("api/watch/stop")
    suspend fun stop(@Body body: WatchStopRequest): Response<BaseResponse>

    @GET("api/watch/online")
    suspend fun online(@Query("contentKey") contentKey: String): Response<WatchOnlineResponse>
}

