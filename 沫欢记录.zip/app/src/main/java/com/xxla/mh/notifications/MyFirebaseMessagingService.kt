package com.xxla.mh.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import android.util.Log

class MyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        val type = data["type"] ?: "center"
        val count = data["count"]?.toIntOrNull() ?: 1

        if (type == "chat") {
            NotificationHelper.notifyChatUnread(applicationContext, count)
        } else {
            NotificationHelper.notifyCenterUnread(applicationContext, count)
        }
    }

    override fun onNewToken(token: String) {
        Log.d("FCM", "New FCM token: $token")
        // 可在此上报后端以实现推送绑定（后端未集成时跳过）
    }
}
