package com.xxla.mh.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.provider.Settings
import com.xxla.mh.MainActivity
import com.xxla.mh.R
import com.xxla.mh.network.MessageItem

object NotificationHelper {
    const val CHANNEL_CHAT = "chat_messages"
    const val CHANNEL_SYSTEM = "app_messages"

    private const val ID_CHAT_SUMMARY = 2001
    private const val ID_CENTER_SUMMARY = 2002

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val chatChannel = NotificationChannel(
                CHANNEL_CHAT,
                "私信提醒",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "聊天消息与未读提醒"
                enableLights(true)
                lightColor = Color.BLUE
                enableVibration(true)
            }

            val sysChannel = NotificationChannel(
                CHANNEL_SYSTEM,
                "消息中心",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "点赞/评论/关注/系统通知"
                enableLights(true)
                lightColor = Color.GREEN
                enableVibration(true)
            }

            nm.createNotificationChannel(chatChannel)
            nm.createNotificationChannel(sysChannel)
        }
    }

    fun notifyChatUnread(context: Context, count: Int) {
        if (count <= 0) return
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("start_route", com.xxla.mh.navigation.Screen.Chat.route)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or pendingIntentFlagImmutable()
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_CHAT)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("新私信")
            .setContentText("未读私信：$count 条")
            .setAutoCancel(true)
            .setContentIntent(pi)

        NotificationManagerCompat.from(context).notify(ID_CHAT_SUMMARY, builder.build())
    }

    fun notifyCenterUnread(context: Context, count: Int) {
        if (count <= 0) return
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("start_route", "message_center_screen")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context,
            1002,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or pendingIntentFlagImmutable()
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_SYSTEM)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("新消息")
            .setContentText("消息中心未读：$count 条")
            .setAutoCancel(true)
            .setContentIntent(pi)

        NotificationManagerCompat.from(context).notify(ID_CENTER_SUMMARY, builder.build())
    }

    private fun pendingIntentFlagImmutable(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
    }

    fun openAppNotificationSettings(context: Context) {
        val intent = Intent().apply {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O -> {
                    action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    putExtra("android.provider.extra.APP_PACKAGE", context.packageName)
                }
                else -> {
                    action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                    data = Uri.fromParts("package", context.packageName, null)
                }
            }
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun notifyCenterItem(
        context: Context,
        id: String,
        type: String?,
        senderName: String?,
        content: String?
    ) {
        val title = when (type) {
            "like" -> "新的点赞"
            "comment" -> "新的评论"
            "follow" -> "新的关注"
            "system" -> "系统通知"
            else -> "新消息"
        }
        val text = buildString {
            senderName?.takeIf { it.isNotBlank() }?.let { append(it).append("：") }
            content?.takeIf { it.isNotBlank() }?.let { append(it) }
        }.ifBlank { "查看消息中心" }

        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("start_route", "message_center_screen")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            context,
            id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or pendingIntentFlagImmutable()
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_SYSTEM)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(pi)

        NotificationManagerCompat.from(context).notify(10000 + id.hashCode(), builder.build())
    }
}
