package com.xxla.mh.notifications

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.xxla.mh.network.ApiConfig
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 周期性轮询未读数量并触发摘要通知。
 * 作为 FCM 的补充，以确保在未集成推送或关闭时也能收到提醒。
 */
class NotificationPollingWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

    private val KEY_TOKEN = stringPreferencesKey("token")
    private val KEY_LOGGED_IN = booleanPreferencesKey("is_logged_in")
    private val KEY_NOTIF_IDS = stringPreferencesKey("notif_message_ids")

    override suspend fun doWork(): Result {
        try {
            val prefs = applicationContext.dataStore.data
                .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
                .map { it }
                .first()

            val token = prefs[KEY_TOKEN]
            val loggedIn = prefs[KEY_LOGGED_IN] ?: false
            if (!loggedIn || token.isNullOrBlank()) {
                return Result.success()
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .build()

            val base = ApiConfig.API_BASE.trimEnd('/')

            // Chat 未读
            runCatching {
                val req = Request.Builder()
                    .url("$base/api/chat/unreadCount")
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string()
                if (resp.isSuccessful && body != null) {
                    val count = JSONObject(body).optJSONObject("data")?.optInt("count") ?: 0
                    NotificationHelper.notifyChatUnread(applicationContext, count)
                }
            }

            // 消息中心未读摘要
            runCatching {
                val req = Request.Builder()
                    .url("$base/api/messages/unreadCount")
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string()
                if (resp.isSuccessful && body != null) {
                    val count = JSONObject(body).optJSONObject("data")?.optInt("count") ?: 0
                    NotificationHelper.notifyCenterUnread(applicationContext, count)
                }
            }

            // 拉取最新消息并做本地去重后逐条通知（最多展示前 5 条）
            runCatching {
                val req = Request.Builder()
                    .url("$base/api/messages?type=all")
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()
                val resp = client.newCall(req).execute()
                val body = resp.body?.string()
                if (resp.isSuccessful && body != null) {
                    val root = JSONObject(body)
                    val messages = root.optJSONObject("data")?.optJSONArray("messages")
                    if (messages != null) {
                        val notifiedStr = prefs[KEY_NOTIF_IDS] ?: ""
                        val notifiedSet = notifiedStr.split(',').filter { it.isNotBlank() }.toMutableSet()
                        val newIds = mutableListOf<String>()

                        val limit = minOf(5, messages.length())
                        for (i in 0 until limit) {
                            val obj = messages.optJSONObject(i) ?: continue
                            val id = obj.optString("id")
                            if (id.isNullOrBlank() || notifiedSet.contains(id)) continue

                            val type = obj.optString("type")
                            val senderName = obj.optString("senderName")
                            val content = obj.optString("content")
                            NotificationHelper.notifyCenterItem(applicationContext, id, type, senderName, content)
                            newIds.add(id)
                        }

                        if (newIds.isNotEmpty()) {
                            // 维护最多 100 条历史，避免无限增长
                            val merged = (newIds + notifiedSet).take(100)
                            applicationContext.dataStore.edit { store ->
                                store[KEY_NOTIF_IDS] = merged.joinToString(",")
                            }
                        }
                    }
                }
            }

            return Result.success()
        } catch (_: Exception) {
            return Result.retry()
        }
    }
}
