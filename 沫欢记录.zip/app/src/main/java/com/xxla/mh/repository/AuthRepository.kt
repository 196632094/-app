package com.xxla.mh.repository

import android.content.Context
import android.net.Uri
import com.xxla.mh.data.User
import com.xxla.mh.data.UserPreferencesRepository
import com.xxla.mh.network.ApiService
import com.xxla.mh.network.LoginRequest
import com.xxla.mh.network.UpdateProfileRequest
import com.xxla.mh.network.RegisterRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val apiService: ApiService,
    private val userPreferencesRepository: UserPreferencesRepository,
    @ApplicationContext private val context: Context
) {
    suspend fun login(username: String, password: String): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.login(LoginRequest(username, password))
                if (response.isSuccessful) {
                    val authResponse = response.body()
                    if (authResponse != null && authResponse.success && authResponse.data != null) {
                        // 保存用户信息和token
                        userPreferencesRepository.saveUserLogin(authResponse.data.user, authResponse.data.token)
                        Result.success(authResponse.data.user)
                    } else {
                        Result.failure(Exception(authResponse?.message ?: "登录失败"))
                    }
                } else {
                    Result.failure(Exception("登录失败: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    data class AuthSuccess(val user: User, val isNewUser: Boolean)

    suspend fun loginOrRegister(username: String, password: String): Result<AuthSuccess> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.loginOrRegister(LoginRequest(username, password))
                if (response.isSuccessful) {
                    val authResponse = response.body()
                    if (authResponse != null && authResponse.success && authResponse.data != null) {
                        userPreferencesRepository.saveUserLogin(authResponse.data.user, authResponse.data.token)
                        val isNew = authResponse.data.isNewUser ?: false
                        Result.success(AuthSuccess(authResponse.data.user, isNew))
                    } else {
                        Result.failure(Exception(authResponse?.message ?: "登录/注册失败"))
                    }
                } else {
                    Result.failure(Exception("登录/注册失败: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun register(username: String, email: String, password: String): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.register(RegisterRequest(username, email, password))
                if (response.isSuccessful) {
                    val authResponse = response.body()
                    if (authResponse != null && authResponse.success && authResponse.data != null) {
                        // 保存用户信息和token
                        userPreferencesRepository.saveUserLogin(authResponse.data.user, authResponse.data.token)
                        Result.success(authResponse.data.user)
                    } else {
                        Result.failure(Exception(authResponse?.message ?: "注册失败"))
                    }
                } else {
                    Result.failure(Exception("注册失败: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun uploadAvatar(avatarUri: Uri): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val file = createTempFileFromUri(context, avatarUri)
                val body = file.asRequestBody("image/*".toMediaTypeOrNull())
                val part = MultipartBody.Part.createFormData("avatar", file.name, body)

                val response = apiService.uploadAvatar(part)

                // 删除临时文件
                file.delete()

                if (response.isSuccessful) {
                    val resp = response.body()
                    if (resp != null && resp.success) {
                        val currentToken = userPreferencesRepository.userPreferencesFlow.first().token ?: ""
                        userPreferencesRepository.saveUserLogin(resp.data.user, currentToken)
                        Result.success(resp.data.user)
                    } else {
                        Result.failure(Exception(resp?.message ?: "上传头像失败"))
                    }
                } else {
                    Result.failure(Exception("上传头像失败: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun logout() {
        userPreferencesRepository.clearUserData()
    }

    suspend fun updateProfile(nickname: String?, signature: String?): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val response = apiService.updateProfile(UpdateProfileRequest(nickname = nickname, signature = signature))
                if (response.isSuccessful) {
                    val resp = response.body()
                    if (resp != null && resp.success && resp.data != null) {
                        val currentToken = userPreferencesRepository.userPreferencesFlow.first().token ?: ""
                        userPreferencesRepository.saveUserLogin(resp.data.user, currentToken)
                        Result.success(resp.data.user)
                    } else {
                        Result.failure(Exception(resp?.message ?: "更新资料失败"))
                    }
                } else {
                    Result.failure(Exception("更新资料失败: ${response.code()}"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    private fun createTempFileFromUri(context: Context, uri: Uri): File {
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("无法读取文件: $uri")
        val tempFile = File.createTempFile("upload_", ".tmp", context.cacheDir)
        FileOutputStream(tempFile).use { output ->
            inputStream.use { inStream ->
                inStream.copyTo(output)
            }
        }
        return tempFile
    }
}
