package com.xxla.mh.repository

import com.xxla.mh.network.UserApiService
import com.xxla.mh.network.UserBriefWithRelation
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProfileRepository @Inject constructor(
    private val userApiService: UserApiService
) {
    suspend fun getUserStats(userId: String): Result<UserStats> {
        return try {
            val resp = userApiService.getUserStats(userId)
            if (resp.isSuccessful && resp.body() != null && resp.body()!!.success) {
                val data = resp.body()!!.data
                Result.success(
                    UserStats(
                        likesCount = data.likesCount,
                        videosCount = data.videosCount,
                        followersCount = data.followersCount,
                        followingCount = data.followingCount,
                        isFollowing = data.isFollowing
                    )
                )
            } else {
                Result.failure(Exception(resp.body()?.message ?: "获取用户统计失败"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun follow(userId: String): Result<Unit> {
        return try {
            val resp = userApiService.follow(userId)
            if (resp.isSuccessful && resp.body()?.success == true) Result.success(Unit)
            else Result.failure(Exception(resp.body()?.message ?: "关注失败"))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun unfollow(userId: String): Result<Unit> {
        return try {
            val resp = userApiService.unfollow(userId)
            if (resp.isSuccessful && resp.body()?.success == true) Result.success(Unit)
            else Result.failure(Exception(resp.body()?.message ?: "取消关注失败"))
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getFollowers(userId: String): Result<List<UserBriefWithRelation>> {
        return try {
            val resp = userApiService.getFollowers(userId)
            if (resp.isSuccessful && resp.body() != null && resp.body()!!.success) {
                Result.success(resp.body()!!.data.users)
            } else {
                Result.failure(Exception(resp.body()?.message ?: "获取粉丝列表失败"))
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    suspend fun getFollowing(userId: String): Result<List<UserBriefWithRelation>> {
        return try {
            val resp = userApiService.getFollowing(userId)
            if (resp.isSuccessful && resp.body() != null && resp.body()!!.success) {
                Result.success(resp.body()!!.data.users)
            } else {
                Result.failure(Exception(resp.body()?.message ?: "获取关注列表失败"))
            }
        } catch (e: Exception) { Result.failure(e) }
    }
}

data class UserStats(
    val likesCount: Int,
    val videosCount: Int,
    val followersCount: Int,
    val followingCount: Int,
    val isFollowing: Boolean
)

