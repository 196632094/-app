package com.xxla.mh.ui.anime

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.anime.AnimeChannel
import com.xxla.mh.data.anime.AnimeDataSource
import com.xxla.mh.data.anime.AnimeDetail
import com.xxla.mh.data.anime.AnimeEpisode
import com.xxla.mh.data.anime.AggregatedEpisode
import com.xxla.mh.data.anime.EpisodeSource
import com.xxla.mh.data.anime.PlayInfo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AnimeDetailViewModel @Inject constructor(
    private val dataSource: AnimeDataSource
) : ViewModel() {

    private val _detail = MutableStateFlow<AnimeDetail?>(null)
    val detail: StateFlow<AnimeDetail?> = _detail.asStateFlow()

    private val _channels = MutableStateFlow<List<AnimeChannel>>(emptyList())
    val channels: StateFlow<List<AnimeChannel>> = _channels.asStateFlow()

    private val _selectedChannelIndex = MutableStateFlow(0)
    val selectedChannelIndex: StateFlow<Int> = _selectedChannelIndex.asStateFlow()

    private val _selectedEpisode: MutableStateFlow<AnimeEpisode?> = MutableStateFlow(null)
    val selectedEpisode: StateFlow<AnimeEpisode?> = _selectedEpisode.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _playInfo = MutableStateFlow<PlayInfo?>(null)
    val playInfo: StateFlow<PlayInfo?> = _playInfo.asStateFlow()

    // 整合后的剧集列表（去重并汇总各线路）
    private val _aggregated = MutableStateFlow<List<AggregatedEpisode>>(emptyList())
    val aggregated: StateFlow<List<AggregatedEpisode>> = _aggregated.asStateFlow()

    fun loadDetail(url: String) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val d = withContext(Dispatchers.IO) { dataSource.getDetail(url) }
                _detail.value = d
                _channels.value = d.channels
                _selectedChannelIndex.value = 0
                _selectedEpisode.value = d.channels.firstOrNull()?.episodes?.firstOrNull()
                _aggregated.value = aggregateEpisodes(d.channels)
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    fun selectChannel(index: Int) {
        _selectedChannelIndex.value = index
        val ep = _channels.value.getOrNull(index)?.episodes?.firstOrNull()
        _selectedEpisode.value = ep
        _playInfo.value = null
    }

    fun selectEpisode(episode: AnimeEpisode) {
        _selectedEpisode.value = episode
        _playInfo.value = null
    }

    // 从整合项中选择具体线路的剧集
    fun selectEpisodeSource(source: EpisodeSource) {
        _selectedEpisode.value = source.episode
        _playInfo.value = null
    }

    fun resolvePlay() {
        val ep = _selectedEpisode.value ?: return
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                _playInfo.value = withContext(Dispatchers.IO) { dataSource.resolvePlay(ep.url) }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    // --- 聚合逻辑 ---
    private fun aggregateEpisodes(channels: List<AnimeChannel>): List<AggregatedEpisode> {
        val map = linkedMapOf<String, MutableList<EpisodeSource>>()
        channels.forEach { ch ->
            ch.episodes.forEach { ep ->
                val key = normalizeEpisodeKey(ep)
                val list = map.getOrPut(key) { mutableListOf() }
                list.add(EpisodeSource(channelName = ch.name, episode = ep))
            }
        }
        val items = map.entries.map { (key, sources) ->
            val title = sources.firstOrNull()?.episode?.name ?: key
            AggregatedEpisode(key = key, title = title, sources = sources)
        }
        return items.sortedWith(compareBy({ safeInt(it.key) }, { it.title }))
    }

    private fun normalizeEpisodeKey(ep: AnimeEpisode): String {
        ep.sort?.trim()?.let { if (it.isNotEmpty()) return it }
        val name = ep.name.lowercase().replace(" ", "")
        val num = Regex("(\\d+)").find(name)?.value
        return num ?: name
    }

    private fun safeInt(s: String): Int {
        return s.toIntOrNull() ?: Int.MAX_VALUE
    }
}
