package com.xxla.mh.ui.anime

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.anime.AnimeDataSource
import com.xxla.mh.data.PlaybackProgressRepository
import com.xxla.mh.data.anime.PlayInfo
import com.xxla.mh.data.WatchRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AnimePlayViewModel @Inject constructor(
    private val dataSource: AnimeDataSource,
    private val progressRepo: PlaybackProgressRepository,
    private val watchRepo: WatchRepository
) : ViewModel() {
    private val _playInfo = MutableStateFlow<PlayInfo?>(null)
    val playInfo: StateFlow<PlayInfo?> = _playInfo.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    // --- Watch Together State ---
    private val _watchContentKey = MutableStateFlow<String?>(null)
    val watchContentKey: StateFlow<String?> = _watchContentKey.asStateFlow()

    private val _watchersCount = MutableStateFlow(0)
    val watchersCount: StateFlow<Int> = _watchersCount.asStateFlow()

    private val _friendWatching = MutableStateFlow(false)
    val friendWatching: StateFlow<Boolean> = _friendWatching.asStateFlow()

    // 在线用户ID列表（含自己），便于界面自动识别好友进入
    private val _watchersIds = MutableStateFlow<List<String>>(emptyList())
    val watchersIds: StateFlow<List<String>> = _watchersIds.asStateFlow()

    private var heartbeatRunning = false

    fun setInitial(info: PlayInfo?) {
        _error.value = null
        _loading.value = false
        _playInfo.value = info
    }

    fun resolve(episodeUrl: String) {
        _loading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                _playInfo.value = withContext(Dispatchers.IO) { dataSource.resolvePlay(episodeUrl) }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    fun saveProgress(episodeUrl: String, positionMs: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { progressRepo.savePosition(episodeUrl, positionMs) }
        }
    }

    fun readProgress(episodeUrl: String) = progressRepo.readPosition(episodeUrl)

    /** 清理旧的播放进度：动态阈值，默认基础为 200 条 */
    fun cleanupProgress(baseEntries: Int = 200) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { progressRepo.trimDynamically("anime", baseEntries) }
        }
    }

    /** 开始一起看：加入会话并启动心跳与人数轮询 */
    fun beginWatch(contentKey: String, friendId: String? = null) {
        _watchContentKey.value = contentKey
        _friendWatching.value = false
        viewModelScope.launch {
            runCatching { watchRepo.start(contentKey) }
            // 启动心跳循环（每 10s）
            if (!heartbeatRunning) {
                heartbeatRunning = true
                launch {
                    while (heartbeatRunning && _watchContentKey.value != null) {
                        val key = _watchContentKey.value ?: break
                        runCatching { watchRepo.heartbeat(key) }
                        kotlinx.coroutines.delay(10_000)
                    }
                }
            }
            // 启动人数轮询
            launch {
                val key = contentKey
                watchRepo.pollOnline(key, 5000).collect { (count, ids) ->
                    _watchersCount.value = count
                    _watchersIds.value = ids
                    _friendWatching.value = friendId?.let { ids.contains(it) } ?: false
                }
            }
        }
    }

    /** 停止一起看：退出会话并停止心跳 */
    fun endWatch() {
        val key = _watchContentKey.value ?: return
        viewModelScope.launch {
            runCatching { watchRepo.stop(key) }
        }
        heartbeatRunning = false
        _watchContentKey.value = null
        _friendWatching.value = false
        _watchersCount.value = 0
        _watchersIds.value = emptyList()
    }

    /** 清除指定剧集的播放进度 */
    fun clearProgressForEpisode(episodeUrl: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { progressRepo.clearPositionNS("anime", episodeUrl) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // 视图模型销毁时做一次轻量化清理
        cleanupProgress()
        endWatch()
    }
}
