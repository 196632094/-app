package com.xxla.mh.ui.components

/**
 * 全局情侣状态：缓存当前用户的伴侣ID，用于 isLover 动态判断。
 */
object LoverStatus {
    @Volatile
    var partnerId: String? = null

    // 兼容早期静态标注（沁沫、时欢），作为后备方案
    private val staticIds = setOf(
        "u-70f6911f-aefa-490b-b032-5059edcd3c38",
        "u-9e327818-8e06-4452-a781-6747a22cde21"
    )

    fun isLover(userId: String?): Boolean {
        val id = userId ?: return false
        val p = partnerId
        return id == p || staticIds.contains(id)
    }
}

