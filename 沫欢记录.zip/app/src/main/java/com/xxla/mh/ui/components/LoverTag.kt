package com.xxla.mh.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// 向后兼容：保留此前公开的 isLover 函数名，改为委托 LoverStatus
fun isLover(userId: String?): Boolean = LoverStatus.isLover(userId)

@Composable
fun LoverTag(userId: String? = null, modifier: Modifier = Modifier) {
    val label = when (userId) {
        "u-70f6911f-aefa-490b-b032-5059edcd3c38" -> "欢的恋人"
        "u-9e327818-8e06-4452-a781-6747a22cde21" -> "沫的恋人"
        else -> "恋人"
    }
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
