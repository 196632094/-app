package com.xxla.mh.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.ui.screens.chat.MissYouViewModel

@Composable
fun MissYouOverlay(viewModel: MissYouViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    LaunchedEffect(Unit) { viewModel.loadPendingOnce() }
    if (!uiState.showOverlay || uiState.pending == null) return

    val pending = uiState.pending ?: return
    var revealedText by remember(pending) { mutableStateOf("") }
    // 逐字显示效果
    LaunchedEffect(pending) {
            val txt = pending.content
        revealedText = ""
        for (i in 1..txt.length) {
            revealedText = txt.substring(0, i)
            kotlinx.coroutines.delay(35)
        }
    }

    // 心形动画（呼吸放缩 + 渐隐）
    val infinite = rememberInfiniteTransition()
    val scale by infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1200, easing = FastOutSlowInEasing))
    )
    val alpha by infinite.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1200, easing = FastOutSlowInEasing))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFFFFEBEE), Color(0xFFFCE4EC))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.Favorite,
                contentDescription = null,
                tint = Color(0xFFE91E63),
                modifier = Modifier.scale(scale).alpha(alpha)
            )
            Text(
                text = "来自 ${pending.fromName} 的想念",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFD81B60)
            )
            Text(
                text = revealedText,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = Color(0xFF4E342E)
            )
            Text(
                text = formatTime(pending.sentAt),
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
            Button(onClick = { viewModel.acknowledge() }, enabled = !uiState.acking) {
                Text(text = if (uiState.acking) "处理中…" else "收到想念")
            }
        }
    }
}

private fun formatTime(iso: String): String {
    return try {
        val instant = java.time.Instant.parse(iso)
        val dt = java.time.ZonedDateTime.ofInstant(instant, java.time.ZoneId.systemDefault())
        java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").format(dt)
    } catch (_: Exception) {
        iso
    }
}
