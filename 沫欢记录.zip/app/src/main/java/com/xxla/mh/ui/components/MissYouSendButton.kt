package com.xxla.mh.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.ui.screens.chat.MissYouViewModel

/**
 * 想念传话按钮：悬浮在界面角落，点击弹出发送弹窗（内容 + 预设）。
 * 避免占用空间，默认放置在右下角。
 */
@Composable
fun MissYouSendButton(
    modifier: Modifier = Modifier,
    viewModel: MissYouViewModel = hiltViewModel(),
    onMoreClick: (() -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var content by remember { mutableStateOf("") }
    var preset by remember { mutableStateOf("heartbeat") }

    // 弹窗打开时加载最近发送记录（服务器分页，取前5条）
    LaunchedEffect(showDialog) {
        if (showDialog) {
            viewModel.loadSent(limit = 5)
        }
    }

    // 悬浮按钮：右下角，避开系统栏
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
            .then(modifier),
        contentAlignment = Alignment.BottomEnd
    ) {
        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .padding(16.dp)
                .size(56.dp)
                .clip(CircleShape)
        ) {
            Icon(imageVector = Icons.Filled.Favorite, contentDescription = "想念传话")
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { if (!uiState.sending) showDialog = false },
            title = { Text(text = "想念传话") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        singleLine = false,
                        label = { Text("内容") },
                        placeholder = { Text("写下此刻的想念…") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(text = "预设效果")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("heartbeat", "aurora", "fireworks", "ribbon", "plane").forEach { name ->
                            SuggestionChip(
                                onClick = { preset = name },
                                label = { Text(name) },
                                colors = androidx.compose.material3.SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (preset == name) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                                    labelColor = if (preset == name) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }

                    // 最近发送记录（便于二次发送与删除）
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "最近发送")
                        TextButton(onClick = { onMoreClick?.invoke() }) { Text("更多") }
                    }
                    val recent = uiState.sentList.take(5)
                    recent.forEach { item ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(text = item.content)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(text = "预设：${item.preset ?: "未知"}")
                                Text(text = if (item.received) "状态：已收到" else "状态：未收到")
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    content = item.content
                                    item.preset?.let { preset = it }
                                }, enabled = !uiState.sending) { Text("重发") }
                                TextButton(onClick = { viewModel.deleteSent(item.id) }, enabled = !uiState.sending) { Text("删除") }
                            }
                        }
                    }
                    if (uiState.error != null) {
                        Text(text = uiState.error ?: "", color = Color.Red)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val txt = content.trim()
                        if (txt.isNotEmpty()) {
                            viewModel.send(txt, preset)
                            showDialog = false
                            content = ""
                        }
                    },
                    enabled = !uiState.sending
                ) { Text("发送") }
            },
            dismissButton = {
                TextButton(onClick = { if (!uiState.sending) showDialog = false }) { Text("取消") }
            }
        )
    }
}
