package com.xxla.mh.ui.components

import android.annotation.SuppressLint
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.network.ApiConfig
import com.xxla.mh.ui.screens.chat.MissYouViewModel

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MissYouWebOverlay(
    viewModel: MissYouViewModel = hiltViewModel(),
    tokenVm: MissYouWebOverlayViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    LaunchedEffect(Unit) { viewModel.loadPendingOnce() }
    if (!uiState.showOverlay || uiState.pending == null) return

    val token by tokenVm.tokenState.collectAsState()

    // 构造资产页面 URL，携带必要参数
    val assetUrl = run {
        val base = ApiConfig.API_BASE.trimEnd('/')
        val sb = StringBuilder("file:///android_asset/missyou.html?base=")
        sb.append(java.net.URLEncoder.encode(base, "UTF-8"))
        if (!token.isNullOrBlank()) {
            sb.append("&token=")
            sb.append(java.net.URLEncoder.encode(token, "UTF-8"))
        }
        sb.toString()
    }

    // 避开系统状态栏/导航栏，确保覆盖层视觉居中
    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize().background(Color.Transparent),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.cacheMode = WebSettings.LOAD_NO_CACHE
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)

                    // 桥接：Web 页面确认成功后通知原生以关闭覆盖层
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun onAckSuccess(id: String?) {
                            // 切回主线程，关闭覆盖层
                            android.os.Handler(context.mainLooper).post {
                                viewModel.dismissOverlay()
                            }
                        }
                    }, "MissYouBridge")

                    // 保持在单页内加载（避免外跳）
                    webViewClient = object : WebViewClient() {}

                    loadUrl(assetUrl)
                }
            },
            update = { webView ->
                // token 变化时刷新（通常不会频繁变化）
                webView.loadUrl(assetUrl)
            }
        )
    }
}
