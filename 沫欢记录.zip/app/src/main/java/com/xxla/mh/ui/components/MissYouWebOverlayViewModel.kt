package com.xxla.mh.ui.components

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.UserPreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class MissYouWebOverlayViewModel @Inject constructor(
    userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {
    // 暴露 token 状态，供 WebView 拼接查询参数
    val tokenState = userPreferencesRepository.userPreferencesFlow
        .map { it.token }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)
}

