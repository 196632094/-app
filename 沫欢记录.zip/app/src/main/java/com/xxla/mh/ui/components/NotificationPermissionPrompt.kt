package com.xxla.mh.ui.components

import android.Manifest
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState
import com.xxla.mh.notifications.NotificationHelper

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun NotificationPermissionPrompt() {
    val context = LocalContext.current
    val notificationsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
    // 仅在本次会话首次进入时弹一次
    val hasShownThisSession = rememberSaveable { mutableStateOf(false) }
    val showPrompt = rememberSaveable { mutableStateOf(false) }

    val permissionState = if (Build.VERSION.SDK_INT >= 33) {
        rememberPermissionState(Manifest.permission.POST_NOTIFICATIONS)
    } else null

    // 开头一次性检测并弹窗（仅一次）
    LaunchedEffect(Unit) {
        if (!hasShownThisSession.value && !notificationsEnabled) {
            showPrompt.value = true
            hasShownThisSession.value = true
        }
    }

    if (showPrompt.value) {
        AlertDialog(
            onDismissRequest = { showPrompt.value = false },
            title = {
                Text(text = if (Build.VERSION.SDK_INT >= 33) "开启通知以获取消息提醒" else "请在系统设置中开启应用通知")
            },
            text = {
                Text("允许通知后可及时收到聊天与系统消息提醒。")
            },
            confirmButton = {
                TextButton(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) {
                        permissionState?.launchPermissionRequest()
                    } else {
                        NotificationHelper.openAppNotificationSettings(context)
                    }
                    showPrompt.value = false
                }) {
                    Text(text = "允许")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrompt.value = false }) {
                    Text(text = "以后再说")
                }
            }
        )
    }
}
