package com.xxla.mh.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import com.xxla.mh.util.UrlUtils

/**
 * 通用用户头像组件
 * @param avatarUrl 头像图片地址
 * @param size 头像尺寸
 */
@Composable
fun UserAvatar(
    avatarUrl: String,
    size: Dp,
    onClick: (() -> Unit)? = null
) {
    // 将可能的相对路径转换为绝对URL；为空则使用默认头像
    val resolved = UrlUtils.toAbsolute(avatarUrl)
    val effectiveUrl = if (resolved.isBlank()) UrlUtils.toAbsolute("/storage/avatars/default.png") else resolved
    AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(effectiveUrl)
            .crossfade(true)
            .build(),
        contentDescription = "用户头像",
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .let { if (onClick != null) it.clickable { onClick() } else it }
    )
}
