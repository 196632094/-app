package com.xxla.mh.ui.player

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.StyledPlayerView
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.util.MimeTypes
import com.google.gson.Gson
import java.util.Locale

class FullscreenPlayerActivity : ComponentActivity() {
    private var exoPlayer: ExoPlayer? = null
    private var playerView: StyledPlayerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 仅在全屏页横屏显示
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        // 沉浸式全屏
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        playerView = StyledPlayerView(this).apply {
            useController = true
        }
        setContentView(playerView)

        val url = intent.getStringExtra(EXTRA_URL)
        val startMs = intent.getLongExtra(EXTRA_START_MS, 0L)
        val isMuted = intent.getBooleanExtra(EXTRA_MUTED, false)
        val headersJson = intent.getStringExtra(EXTRA_HEADERS) ?: ""
        val headers: Map<String, String> = try {
            Gson().fromJson(headersJson, Map::class.java) as Map<String, String>
        } catch (_: Exception) { emptyMap() }
        if (url.isNullOrEmpty()) {
            finish()
            return
        }

        val forcedUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
        val forcedHeaders = headers.toMutableMap().apply {
            this["User-Agent"] = forcedUa
            this["Referer"] = ""
        }
        val httpFactory = DefaultHttpDataSource.Factory()
            .setDefaultRequestProperties(forcedHeaders)
            .setUserAgent(forcedUa)
        val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)

        exoPlayer = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().also { player ->
                playerView?.player = player
                playerView?.keepScreenOn = true
                val builder = MediaItem.Builder().setUri(Uri.parse(url))
                if (url.lowercase(Locale.ROOT).contains(".m3u8")) {
                    builder.setMimeType(MimeTypes.APPLICATION_M3U8)
                }
                player.setMediaItem(builder.build())
                player.prepare()
                player.seekTo(startMs)
                player.volume = if (isMuted) 0f else 1f
                player.playWhenReady = true
            }

        // 使用 OnBackPressedDispatcher 处理返回手势
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val pos = exoPlayer?.currentPosition ?: 0L
                setResult(Activity.RESULT_OK, Intent().putExtra(RESULT_POSITION_MS, pos))
                finish()
            }
        })
    }

    override fun onDestroy() {
        playerView?.player = null
        exoPlayer?.release()
        exoPlayer = null
        playerView = null

        // 恢复系统栏
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "extra_url"
        const val EXTRA_START_MS = "extra_start_ms"
        const val EXTRA_MUTED = "extra_muted"
        const val EXTRA_HEADERS = "extra_headers"
        const val RESULT_POSITION_MS = "result_position_ms"
    }
}
