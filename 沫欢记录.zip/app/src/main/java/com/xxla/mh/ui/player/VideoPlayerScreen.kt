package com.xxla.mh.ui.player

import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import android.app.Activity
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Canvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.ui.screens.profile.HistoryItem
import com.xxla.mh.ui.screens.profile.HistoryViewModel
import java.text.SimpleDateFormat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.util.MimeTypes
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.StyledPlayerView
import com.xxla.mh.ui.screens.comment.CommentItem
import com.xxla.mh.ui.screens.comment.CommentViewModel
import com.xxla.mh.ui.screens.auth.AuthViewModel
import com.xxla.mh.ui.theme.AppPrimary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*
import androidx.activity.compose.BackHandler

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoPlayerScreen(
    videoId: String,
    source: String? = null,
    initialStartMs: Long = 0L,
    onBackClick: () -> Unit,
    viewModel: VideoPlayerViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    
    val videoState by viewModel.videoState.collectAsState()
    // val danmakuList by viewModel.danmakuList.collectAsState()
    val isPlaying = remember { mutableStateOf(true) }
    val showControls = remember { mutableStateOf(true) }
    val danmakuInput = remember { mutableStateOf("") }
    var isMuted by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableStateOf(0L) }
    var durationMs by remember { mutableStateOf(0L) }
    var bufferedPosition by remember { mutableStateOf(0L) }
    var descExpanded by remember { mutableStateOf(false) }

    // 评论相关状态
    val commentViewModel: CommentViewModel = hiltViewModel()
    val historyViewModel: HistoryViewModel = hiltViewModel()
    val authVM: AuthViewModel = hiltViewModel()
    val currentUserId = authVM.getCurrentUser()?.id
    val commentState by commentViewModel.commentState.collectAsState()
    val commentText by commentViewModel.commentText.collectAsState()
    val replyingToAlias by commentViewModel.replyingToAlias.collectAsState()
    // 进度持久化：读取已保存位置，并解析最终起始位置
    val savedProgress by viewModel.readProgress(videoId).collectAsState(initial = null)
    val resolvedStartMs = remember(initialStartMs, savedProgress) {
        val base = if (initialStartMs > 0) initialStartMs else (savedProgress ?: 0L)
        base.coerceAtLeast(0L)
    }
    
    // 获取视频详情和弹幕
    LaunchedEffect(videoId) {
        viewModel.getVideoDetail(videoId)
        viewModel.getDanmakuList(videoId)
        // 加载评论
        commentViewModel.loadComments(videoId)
    }
    
    // 控制栏自动隐藏
    LaunchedEffect(showControls.value) {
        if (showControls.value) {
            delay(3000)
            showControls.value = false
        }
    }
    // 当前视频链接（用于全屏页传参）
    val currentUrl = videoState.videoDetail?.videoUrl
    
    // ExoPlayer 实例（统一使用带 UA 的 HLS 数据源）
    val exoPlayer = remember {
        val forcedUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
        val httpFactory = DefaultHttpDataSource.Factory()
            .setDefaultRequestProperties(mapOf("Referer" to "", "User-Agent" to forcedUa))
            .setUserAgent(forcedUa)
        val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().apply {
                videoState.videoDetail?.videoUrl?.let { url ->
                    val builder = MediaItem.Builder().setUri(Uri.parse(url))
                    if (url.lowercase(Locale.ROOT).contains(".m3u8")) {
                        builder.setMimeType(MimeTypes.APPLICATION_M3U8)
                    }
                    setMediaItem(builder.build())
                    prepare()
                    playWhenReady = true
                    // 初始定位（允许在准备前设置）
                    if (resolvedStartMs > 0) seekTo(resolvedStartMs)
                }
                // STATE_READY 后进行一次夹紧定位，确保不越界
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        if (state == Player.STATE_READY) {
                            val dur = duration
                            if (dur > 0) {
                                val clampTarget = kotlin.math.min(resolvedStartMs, kotlin.math.max(0L, dur - 1000L))
                                val pos = currentPosition
                                if (kotlin.math.abs(pos - clampTarget) > 600) {
                                    seekTo(clampTarget)
                                }
                            }
                        }
                    }
                })
            }
    }

    // 当视频URL加载完成后，更新播放器媒体并开始播放
    LaunchedEffect(videoState.videoDetail?.videoUrl) {
        val url = videoState.videoDetail?.videoUrl
        if (!url.isNullOrBlank()) {
            val builder = MediaItem.Builder().setUri(Uri.parse(url))
            if (url.lowercase(Locale.ROOT).contains(".m3u8")) {
                builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            exoPlayer.setMediaItem(builder.build())
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
            isPlaying.value = true
            durationMs = exoPlayer.duration
            // 播放开始后记录唯一播放量
            viewModel.recordView(videoId)
        }
    }
    
    // 暂时移除弹幕上下文与解析器，避免第三方库 API 兼容性问题
    
    // 生命周期管理
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    exoPlayer.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (isPlaying.value) exoPlayer.play()
                }
                Lifecycle.Event.ON_DESTROY -> {
                    // 销毁前保存一次当前进度并进行清理
                    val dur = exoPlayer.duration
                    if (dur > 0) {
                        val clamped = kotlin.math.min(exoPlayer.currentPosition, kotlin.math.max(0L, dur - 1000L))
                        viewModel.saveProgress(videoId, clamped)
                        viewModel.cleanupProgress()
                    }
                    exoPlayer.release()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // 释放前亦保存一次当前进度（防止某些情况下未触发 ON_DESTROY）
            val dur = exoPlayer.duration
            if (dur > 0) {
                val clamped = kotlin.math.min(exoPlayer.currentPosition, kotlin.math.max(0L, dur - 1000L))
                viewModel.saveProgress(videoId, clamped)
                viewModel.cleanupProgress()
            }
            exoPlayer.release()
        }
    }

    // 处理系统返回键：记录历史后返回
    BackHandler(enabled = true) {
        // 退出前保存当前进度（夹紧到时长内，避免越界）
        val dur = exoPlayer.duration
        if (dur > 0) {
            val clamped = kotlin.math.min(exoPlayer.currentPosition, kotlin.math.max(0L, dur - 1000L))
            viewModel.saveProgress(videoId, clamped)
        }
        val detail = videoState.videoDetail
        if (detail != null) {
            val watchedSec = (currentPosition / 1000L).toInt()
            val totalSec = (durationMs / 1000L).toInt()
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            val item = HistoryItem(
                id = java.util.UUID.randomUUID().toString(),
                videoId = detail.id,
                title = detail.title,
                thumbnailUrl = detail.coverUrl,
                authorName = detail.author.nickname ?: detail.author.username,
                watchTime = sdf.format(java.util.Date()),
                watchedDuration = watchedSec,
                totalDuration = totalSec
            )
            historyViewModel.addHistoryItem(item)
        }
        onBackClick()
    }
    
    // 外层滚动布局：顶部 16:9 视频，底部信息与评论
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // 顶部视频区域 16:9
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
            ) {
                // 拖拽标记：用于在拖拽时暂缓自动进度刷新
                var isScrubbing by remember { mutableStateOf(false) }
                // 最近一次持久化的进度，用于节流
                var lastPersistPos by remember { mutableStateOf(0L) }
                // 播放进度刷新与持久化：当正在播放时，每500ms更新一次UI显示的进度，并每≈5秒保存一次进度
                LaunchedEffect(isPlaying.value) {
                    while (isPlaying.value) {
                        if (!isScrubbing) {
                            currentPosition = exoPlayer.currentPosition
                        }
                        durationMs = exoPlayer.duration
                        bufferedPosition = exoPlayer.bufferedPosition

                        // 周期性持久化（节流、避免拖拽时写入）
                        if (!isScrubbing && durationMs > 0) {
                            val delta = kotlin.math.abs(currentPosition - lastPersistPos)
                            if (delta >= 5_000L && currentPosition > 0L) {
                                val clamp = kotlin.math.min(currentPosition, kotlin.math.max(0L, durationMs - 1000L))
                                viewModel.saveProgress(videoId, clamp)
                                lastPersistPos = currentPosition
                            }
                        }

                        delay(500)
                    }
                }

                AndroidView(
                    factory = { ctx ->
                        FrameLayout(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            val playerView = StyledPlayerView(ctx).apply {
                                player = exoPlayer
                                useController = false
                            }
                            addView(playerView)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // 点击屏幕切换控制栏显示状态（置于底层，避免覆盖进度条拦截手势）
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .align(Alignment.Center)
                        .clickable { showControls.value = !showControls.value }
                )

                // 顶部控制栏（渐变）
                AnimatedVisibility(
                    visible = showControls.value,
                    enter = EnterTransition.None,
                    exit = ExitTransition.None,
                    modifier = Modifier.align(Alignment.TopCenter)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    0f to Color.Black.copy(alpha = 0.55f),
                                    0.6f to Color.Black.copy(alpha = 0.25f),
                                    1f to Color.Transparent
                                )
                            )
                    ) {
                        TopAppBar(
                            title = {
                                Text(
                                    text = videoState.videoDetail?.title ?: "",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = Color.White
                                )
                            },
                            navigationIcon = {
                                IconButton(onClick = {
                                    // 返回前保存进度并记录历史
                                    val dur = exoPlayer.duration
                                    if (dur > 0) {
                                        val clamped = kotlin.math.min(exoPlayer.currentPosition, kotlin.math.max(0L, dur - 1000L))
                                        viewModel.saveProgress(videoId, clamped)
                                    }
                                    val detail = videoState.videoDetail
                                    if (detail != null) {
                                        val watchedSec = (currentPosition / 1000L).toInt()
                                        val totalSec = (durationMs / 1000L).toInt()
                                        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                                        val item = HistoryItem(
                                            id = java.util.UUID.randomUUID().toString(),
                                            videoId = detail.id,
                                            title = detail.title,
                                            thumbnailUrl = detail.coverUrl,
                                            authorName = detail.author.nickname ?: detail.author.username,
                                            watchTime = sdf.format(java.util.Date()),
                                            watchedDuration = watchedSec,
                                            totalDuration = totalSec
                                        )
                                        historyViewModel.addHistoryItem(item)
                                    }
                                    onBackClick()
                                }) {
                                    Icon(
                                        Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "返回",
                                        tint = Color.White
                                    )
                                }
                            },
                            actions = {
                                IconButton(onClick = {
                                    val dur = exoPlayer.duration
                                    val pos = exoPlayer.currentPosition
                                    val clamped = if (dur > 0) kotlin.math.min(pos, kotlin.math.max(0L, dur - 1000L)) else pos
                                    // 在分享前同步保存进度，确保链接携带最新进度
                                    viewModel.saveProgress(videoId, clamped)
                                    val deepLink = com.xxla.mh.navigation.Screen.VideoPlayer.createDeepLink(
                                        videoId = videoId,
                                        source = source,
                                        startMs = clamped
                                    )
                                    val titleForShare = videoState.videoDetail?.title ?: videoId
                                    val shareText = com.xxla.mh.util.ShareUtils.buildShareText(
                                        title = titleForShare,
                                        deepLink = deepLink,
                                        positionMs = clamped
                                    )
                                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                                    }
                                    try {
                                        context.startActivity(android.content.Intent.createChooser(intent, "分享"))
                                    } catch (_: Throwable) {
                                        android.widget.Toast.makeText(context, "无法打开分享", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }) {
                                    Icon(
                                        Icons.Filled.Share,
                                        contentDescription = "分享",
                                        tint = Color.White
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = Color.Transparent
                            )
                        )
                    }
                }

                // 底部控制栏
                AnimatedVisibility(
                    visible = showControls.value,
                    enter = EnterTransition.None,
                    exit = ExitTransition.None,
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    0f to Color.Transparent,
                                    0.4f to Color.Black.copy(alpha = 0.25f),
                                    1f to Color.Black.copy(alpha = 0.65f)
                                )
                            )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = {
                                    if (isPlaying.value) exoPlayer.pause() else exoPlayer.play()
                                    isPlaying.value = !isPlaying.value
                                }) {
                                    Icon(
                                        if (isPlaying.value) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = if (isPlaying.value) "暂停" else "播放",
                                        tint = Color.White
                                    )
                                }
                                // 中间留白以对齐右侧按钮
                                Spacer(modifier = Modifier.weight(1f))

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        isMuted = !isMuted
                                        exoPlayer.volume = if (isMuted) 0f else 1f
                                    }) {
                                        Icon(
                                            if (isMuted) Icons.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                            contentDescription = if (isMuted) "取消静音" else "静音",
                                            tint = Color.White
                                        )
                                    }

                                    // 全屏：启动独立的全屏 Activity，仅在该页面横屏
                                    val context = LocalContext.current
                                    val fullscreenLauncher = rememberLauncherForActivityResult(
                                        ActivityResultContracts.StartActivityForResult()
                                    ) { result ->
                                        if (result.resultCode == Activity.RESULT_OK) {
                                            val newPos = result.data?.getLongExtra(
                                                FullscreenPlayerActivity.RESULT_POSITION_MS,
                                                exoPlayer.currentPosition
                                            ) ?: exoPlayer.currentPosition
                                            exoPlayer.seekTo(newPos)
                                            exoPlayer.play()
                                            isPlaying.value = true
                                        }
                                    }
                                    IconButton(onClick = {
                                        exoPlayer.pause()
                                        val intent = Intent(context, FullscreenPlayerActivity::class.java).apply {
                                            putExtra(FullscreenPlayerActivity.EXTRA_URL, currentUrl ?: "")
                                            putExtra(FullscreenPlayerActivity.EXTRA_START_MS, exoPlayer.currentPosition)
                                            putExtra(FullscreenPlayerActivity.EXTRA_MUTED, isMuted)
                                            // 通用播放器暂无特定 headers，这里传递空 JSON，保持全屏页兼容逻辑一致
                                            putExtra(FullscreenPlayerActivity.EXTRA_HEADERS, com.google.gson.Gson().toJson(emptyMap<String, String>()))
                                        }
                                        if (!currentUrl.isNullOrBlank()) {
                                            fullscreenLauncher.launch(intent)
                                        }
                                    }) {
                                        Icon(
                                            Icons.Filled.Fullscreen,
                                            contentDescription = "全屏",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }

                            val safeDuration = durationMs.coerceAtLeast(1L)
                            // 自定义仿 B 站拖拽进度条（缓冲+进度+拇指），支持随意拖拽
                            val density = LocalDensity.current
                            // 局部拖拽进度（避免累计计算误差）
                            val progressFraction = (currentPosition.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
                            val bufferFraction = (bufferedPosition.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
                            var dragFraction by remember(progressFraction) { mutableStateOf(progressFraction) }

                            BoxWithConstraints(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(28.dp)
                            ) {
                                // 画轨道与拇指
                                Canvas(modifier = Modifier
                                    .fillMaxWidth()
                                    .height(20.dp)
                                    .align(Alignment.Center)
                                    .pointerInput(safeDuration) {
                                        // 点击跳转
                                        detectTapGestures(onTap = { offset ->
                                            val targetFraction = (offset.x / size.width).coerceIn(0f, 1f)
                                            val targetMs = (safeDuration * targetFraction).toLong()
                                            isScrubbing = true
                                            currentPosition = targetMs
                                            exoPlayer.seekTo(targetMs)
                                            isScrubbing = false
                                        })
                                    }
                                    .pointerInput(safeDuration) {
                                        // 拖拽调整
                                        detectDragGestures(
                                            onDragStart = { startOffset: Offset ->
                                                isScrubbing = true
                                                dragFraction = (startOffset.x / size.width).coerceIn(0f, 1f)
                                                currentPosition = (safeDuration * dragFraction).toLong()
                                            },
                                            onDrag = { change: PointerInputChange, dragAmount: Offset ->
                                                dragFraction = (dragFraction + dragAmount.x / size.width).coerceIn(0f, 1f)
                                                currentPosition = (safeDuration * dragFraction).toLong()
                                            },
                                            onDragEnd = {
                                                exoPlayer.seekTo(currentPosition)
                                                isScrubbing = false
                                            },
                                            onDragCancel = {
                                                isScrubbing = false
                                            }
                                        )
                                    }
                                ) {
                                    val trackHeight = 6.dp.toPx()
                                    val y = size.height / 2f
                                    // 背景轨道
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.12f),
                                        start = Offset(0f, y),
                                        end = Offset(size.width, y),
                                        strokeWidth = trackHeight,
                                        cap = StrokeCap.Round
                                    )
                                    // 缓冲轨道
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.35f),
                                        start = Offset(0f, y),
                                        end = Offset(size.width * bufferFraction, y),
                                        strokeWidth = trackHeight,
                                        cap = StrokeCap.Round
                                    )
                                    // 进度轨道
                                    val pf = (if (isScrubbing) dragFraction else progressFraction)
                                    drawLine(
                                        color = AppPrimary,
                                        start = Offset(0f, y),
                                        end = Offset(size.width * pf, y),
                                        strokeWidth = trackHeight,
                                        cap = StrokeCap.Round
                                    )
                                    // 拇指
                                    val thumbX = size.width * pf
                                    drawCircle(color = AppPrimary, radius = 8.dp.toPx(), center = Offset(thumbX, y))
                                }

                                // 拖拽时显示时间气泡（跟随拇指）
                                if (isScrubbing) {
                                    val pf = (currentPosition.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
                                    val timeText = formatDuration(currentPosition)
                                    val xOffset = with(density) { (pf * this@BoxWithConstraints.maxWidth.toPx()).toDp() }

                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .offset(x = xOffset - 16.dp)
                                    ) {
                                        Surface(
                                            color = Color.Black.copy(alpha = 0.7f),
                                            shape = MaterialTheme.shapes.small
                                        ) {
                                            Text(
                                                text = timeText,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // 左右时间显示：当前时间 / 总时长
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = formatDuration(currentPosition),
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = formatDuration(durationMs),
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // 中心播放按钮移除：避免和底部控制栏重复
            }
        }

        // 标题与作者信息
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = videoState.videoDetail?.title ?: "",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(videoState.videoDetail?.author?.avatar)
                            .crossfade(true)
                            .build(),
                        contentDescription = "作者头像",
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape),
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = videoState.videoDetail?.author?.nickname
                                    ?: videoState.videoDetail?.author?.username
                                    ?: "",
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f)
                            )
                            if (com.xxla.mh.ui.components.isLover(videoState.videoDetail?.author?.id)) {
                                Spacer(modifier = Modifier.width(6.dp))
                                com.xxla.mh.ui.components.LoverTag(videoState.videoDetail?.author?.id)
                            }
                        }
                        Text(
                            text = "${videoState.videoDetail?.viewCount ?: 0} 次观看 · ${videoState.videoDetail?.createdAt ?: ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // 点赞按钮
                    val liked = videoState.videoDetail?.isLiked ?: false
                    IconButton(onClick = { viewModel.toggleLike(videoId) }) {
                        Icon(
                            imageVector = if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "点赞",
                            tint = if (liked) AppPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 简介与标签
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = "简介",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                val desc = videoState.videoDetail?.description ?: ""
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = if (descExpanded) Int.MAX_VALUE else 3,
                    overflow = TextOverflow.Ellipsis
                )
                TextButton(onClick = { descExpanded = !descExpanded }) {
                    Text(if (descExpanded) "收起" else "展开")
                }

                // 标签
                val tags = videoState.videoDetail?.tags ?: emptyList()
                if (tags.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        tags.forEach { tag ->
                            AssistChip(onClick = { /* TODO: 跳转标签 */ }, label = { Text(tag) })
                        }
                    }
                }
            }
        }

        // 评论输入与标题
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "评论 (${videoState.videoDetail?.commentCount ?: 0})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column {
                    if (!replyingToAlias.isNullOrBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "回复 ${replyingToAlias}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            TextButton(onClick = { commentViewModel.clearReply() }) {
                                Text("取消")
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val isPosting by commentViewModel.isPosting.collectAsState()
                        val keyboardController = LocalSoftwareKeyboardController.current
                        val focusManager = LocalFocusManager.current
                        OutlinedTextField(
                            value = commentText,
                            onValueChange = { commentViewModel.updateCommentText(it) },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("添加评论...") },
                            maxLines = 3,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (!isPosting && commentText.isNotBlank()) {
                                        commentViewModel.postComment(videoId)
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }
                                }
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (!isPosting && commentText.isNotBlank()) {
                                    commentViewModel.postComment(videoId)
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                }
                            },
                            enabled = commentText.isNotBlank() && !isPosting
                        ) {
                            if (isPosting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("发送中")
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("发送")
                            }
                        }
                    }
                }
            }
        }

        // 评论列表
        when (val state = commentState) {
            is com.xxla.mh.ui.screens.comment.CommentState.Success -> {
                items(state.comments) { c ->
                    CommentItem(
                        comment = c,
                        currentUserId = currentUserId,
                        onLikeClick = { commentViewModel.toggleLikeComment(videoId, it) },
                        onReplyClick = { id, alias -> commentViewModel.startReplyTo(id, alias) },
                        onDeleteComment = { commentViewModel.deleteComment(it) },
                        onDeleteReply = { commentViewModel.deleteReply(it) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
            is com.xxla.mh.ui.screens.comment.CommentState.Error -> {
                item {
                    Text(
                        text = state.message,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
            is com.xxla.mh.ui.screens.comment.CommentState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

// 格式化时间
private fun formatDuration(durationMs: Long): String {
    if (durationMs <= 0) return "00:00"
    val totalSeconds = durationMs / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) String.format("%d:%02d:%02d", hours, minutes, seconds)
    else String.format("%02d:%02d", minutes, seconds)
}

// 弹幕显示接口
interface IDisplayer {
    companion object {
        const val DANMAKU_STYLE_STROKEN = 1
    }
}
