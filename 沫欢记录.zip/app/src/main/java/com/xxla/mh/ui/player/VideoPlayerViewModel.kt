package com.xxla.mh.ui.player

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.network.Danmaku
import com.xxla.mh.network.DanmakuRequest
import com.xxla.mh.network.VideoApiService
import com.xxla.mh.network.VideoDetail
import com.xxla.mh.data.VideoRepository
import com.xxla.mh.util.UrlUtils
import com.xxla.mh.data.PlaybackProgressRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VideoPlayerViewModel @Inject constructor(
    private val videoRepository: VideoRepository,
    private val videoApiService: VideoApiService,
    private val progressRepo: PlaybackProgressRepository
) : ViewModel() {

    // 视频状态
    private val _videoState = MutableStateFlow(VideoPlayerState())
    val videoState: StateFlow<VideoPlayerState> = _videoState.asStateFlow()

    // 弹幕列表
    private val _danmakuList = MutableStateFlow<List<Danmaku>>(emptyList())
    val danmakuList: StateFlow<List<Danmaku>> = _danmakuList.asStateFlow()

    // 获取视频详情
    fun getVideoDetail(videoId: String) {
        viewModelScope.launch {
            try {
                _videoState.value = _videoState.value.copy(isLoading = true)
                val response = videoApiService.getVideoDetail(videoId)
                if (response.isSuccessful && response.body() != null) {
                    val rawDetail = response.body()!!.data
                    val videoDetail = rawDetail.copy(
                        videoUrl = UrlUtils.toAbsolute(rawDetail.videoUrl),
                        coverUrl = UrlUtils.toAbsolute(rawDetail.coverUrl),
                        author = rawDetail.author.copy(
                            avatar = rawDetail.author.avatar?.let { UrlUtils.toAbsolute(it) }
                        )
                    )
                    _videoState.value = _videoState.value.copy(
                        isLoading = false,
                        videoDetail = videoDetail,
                        error = null
                    )
                } else {
                    _videoState.value = _videoState.value.copy(
                        isLoading = false,
                        error = "获取视频详情失败: ${response.message()}"
                    )
                }
            } catch (e: Exception) {
                _videoState.value = _videoState.value.copy(
                    isLoading = false,
                    error = "获取视频详情失败: ${e.message}"
                )
            }
        }
    }

    // 获取弹幕列表
    fun getDanmakuList(videoId: String) {
        viewModelScope.launch {
            try {
                val response = videoApiService.getDanmaku(videoId)
                if (response.isSuccessful && response.body() != null) {
                    _danmakuList.value = response.body()!!.data
                }
            } catch (e: Exception) {
                // 处理错误
            }
        }
    }

    // 发送弹幕
    suspend fun sendDanmaku(videoId: String, content: String, time: Float, color: String, type: Int): Boolean {
        return try {
            val request = DanmakuRequest(content, time, color, type)
            val response = videoApiService.sendDanmaku(videoId, request)
            
            if (response.isSuccessful) {
                // 添加到本地弹幕列表，立即显示
                val newDanmaku = Danmaku(
                    id = System.currentTimeMillis().toString(), // 临时ID
                    content = content,
                    time = time,
                    color = color,
                    type = type,
                    userId = "" // 当前用户ID，实际应从用户会话获取
                )
                _danmakuList.value = _danmakuList.value + newDanmaku
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    // 点赞/取消点赞（统一委托仓库，乐观更新与失败回滚）
    fun toggleLike(videoId: String) {
        val currentDetail = _videoState.value.videoDetail ?: return
        val currentlyLiked = currentDetail.isLiked
        val updated = currentDetail.copy(
            isLiked = !currentlyLiked,
            likeCount = currentDetail.likeCount + if (!currentlyLiked) 1 else -1
        )
        _videoState.value = _videoState.value.copy(videoDetail = updated)

        viewModelScope.launch {
            val ok = try {
                if (currentlyLiked) videoRepository.unlikeVideo(videoId) else videoRepository.likeVideo(videoId)
            } catch (e: Exception) { false }
            if (!ok) {
                // 回滚
                _videoState.value = _videoState.value.copy(videoDetail = currentDetail)
            }
        }
    }

    // 记录唯一播放，成功后更新播放量
    fun recordView(videoId: String) {
        viewModelScope.launch {
            try {
                val newCount = videoRepository.recordVideoView(videoId)
                if (newCount != null) {
                    val detail = _videoState.value.videoDetail
                    if (detail != null) {
                        _videoState.value = _videoState.value.copy(
                            videoDetail = detail.copy(viewCount = newCount)
                        )
                    }
                }
            } catch (_: Exception) {
                // 忽略统计失败，避免影响播放流程
            }
        }
    }

    // 播放进度持久化（命名空间：video）
    fun saveProgress(videoId: String, positionMs: Long) {
        viewModelScope.launch {
            runCatching { progressRepo.savePositionNS("video", videoId, positionMs) }
        }
    }

    fun readProgress(videoId: String) = progressRepo.readPositionNS("video", videoId)

    fun cleanupProgress(baseEntries: Int = 200) {
        viewModelScope.launch { runCatching { progressRepo.trimDynamically("video", baseEntries) } }
    }

    fun clearProgress(videoId: String) {
        viewModelScope.launch { runCatching { progressRepo.clearPositionNS("video", videoId) } }
    }
}

// 视频播放器状态
data class VideoPlayerState(
    val isLoading: Boolean = false,
    val videoDetail: VideoDetail? = null,
    val error: String? = null
)
