package com.xxla.mh.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.xxla.mh.ui.components.LoadingIndicator
import com.xxla.mh.ui.theme.ResponsiveUtils

/**
 * 后台管理系统主界面
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    navController: NavController,
    viewModel: AdminViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val horizontalPadding = ResponsiveUtils.getHorizontalPadding()
    
    var selectedTab by remember { mutableStateOf(AdminTab.CONTENT_REVIEW) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("后台管理系统") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
        ) {
            // 管理系统标签栏
            TabRow(selectedTabIndex = selectedTab.ordinal) {
                AdminTab.values().forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = { Text(tab.title) },
                        icon = {
                            when (tab) {
                                AdminTab.CONTENT_REVIEW -> Icon(Icons.Default.VideoLibrary, contentDescription = null)
                                AdminTab.USER_MANAGEMENT -> Icon(Icons.Default.People, contentDescription = null)
                                AdminTab.STATISTICS -> Icon(Icons.Default.BarChart, contentDescription = null)
                            }
                        }
                    )
                }
            }
            
            // 内容区域
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = horizontalPadding)
            ) {
                when (selectedTab) {
                    AdminTab.CONTENT_REVIEW -> ContentReviewSection(viewModel)
                    AdminTab.USER_MANAGEMENT -> UserManagementSection(viewModel)
                    AdminTab.STATISTICS -> StatisticsSection(viewModel)
                }
                
                // 加载状态
                if (uiState.isLoading) {
                    LoadingIndicator()
                }
                
                // 错误状态
                if (uiState.error != null) {
                    ErrorMessage(
                        message = uiState.error!!,
                        onRetry = { viewModel.retry(selectedTab) }
                    )
                }
            }
        }
    }
}

@Composable
fun ContentReviewSection(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    
    LaunchedEffect(Unit) {
        viewModel.loadContentForReview()
    }
    
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        items(uiState.pendingVideos) { video ->
            ContentReviewItem(
                video = video,
                onApprove = { viewModel.approveContent(video.id) },
                onReject = { viewModel.rejectContent(video.id) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentReviewItem(
    video: PendingVideo,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = video.title,
                style = MaterialTheme.typography.titleMedium
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "上传者: ${video.authorName}",
                style = MaterialTheme.typography.bodyMedium
            )
            
            Text(
                text = "上传时间: ${video.uploadTime}",
                style = MaterialTheme.typography.bodySmall
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = video.description,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onReject,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("拒绝")
                }
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Button(
                    onClick = onApprove
                ) {
                    Text("通过")
                }
            }
        }
    }
}

@Composable
fun UserManagementSection(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    
    LaunchedEffect(Unit) {
        viewModel.loadUsers()
    }
    
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        items(uiState.users) { user ->
            UserManagementItem(
                user = user,
                onBan = { viewModel.banUser(user.id) },
                onUnban = { viewModel.unbanUser(user.id) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserManagementItem(
    user: UserInfo,
    onBan: () -> Unit,
    onUnban: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = user.username,
                    style = MaterialTheme.typography.titleMedium
                )
                
                Text(
                    text = "注册时间: ${user.registerTime}",
                    style = MaterialTheme.typography.bodySmall
                )
                
                Text(
                    text = "状态: ${if (user.isBanned) "已禁用" else "正常"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (user.isBanned) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
            
            if (user.isBanned) {
                Button(
                    onClick = onUnban
                ) {
                    Text("解除禁用")
                }
            } else {
                OutlinedButton(
                    onClick = onBan,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("禁用账号")
                }
            }
        }
    }
}

@Composable
fun StatisticsSection(viewModel: AdminViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    
    LaunchedEffect(Unit) {
        viewModel.loadStatistics()
    }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        StatisticsCard(
            title = "用户统计",
            items = listOf(
                "总用户数" to "${uiState.statistics.totalUsers}",
                "今日新增" to "${uiState.statistics.newUsersToday}",
                "活跃用户" to "${uiState.statistics.activeUsers}"
            )
        )
        
        StatisticsCard(
            title = "内容统计",
            items = listOf(
                "视频总数" to "${uiState.statistics.totalVideos}",
                "今日上传" to "${uiState.statistics.newVideosToday}",
                "待审核" to "${uiState.statistics.pendingReviewVideos}"
            )
        )
        
        StatisticsCard(
            title = "互动统计",
            items = listOf(
                "评论总数" to "${uiState.statistics.totalComments}",
                "弹幕总数" to "${uiState.statistics.totalDanmaku}",
                "点赞总数" to "${uiState.statistics.totalLikes}"
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsCard(
    title: String,
    items: List<Pair<String, String>>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            items.forEach { (label, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    
                    Text(
                        text = value,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun ErrorMessage(
    message: String,
    onRetry: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.8f)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.error
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Button(
            onClick = onRetry
        ) {
            Text("重试")
        }
    }
}

enum class AdminTab(val title: String) {
    CONTENT_REVIEW("内容审核"),
    USER_MANAGEMENT("用户管理"),
    STATISTICS("数据统计")
}
