package com.xxla.mh.ui.screens.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.repository.AdminRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

/**
 * 后台管理系统的ViewModel
 */
@HiltViewModel
class AdminViewModel @Inject constructor(
    private val adminRepository: AdminRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()
    
    fun loadContentForReview() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val pendingVideos = adminRepository.getPendingVideos()
                _uiState.update { it.copy(pendingVideos = pendingVideos, isLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "加载待审核内容失败: ${e.message}", isLoading = false) }
            }
        }
    }
    
    fun loadUsers() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val users = adminRepository.getUsers()
                _uiState.update { it.copy(users = users, isLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "加载用户列表失败: ${e.message}", isLoading = false) }
            }
        }
    }
    
    fun loadStatistics() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val statistics = adminRepository.getStatistics()
                _uiState.update { it.copy(statistics = statistics, isLoading = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "加载统计数据失败: ${e.message}", isLoading = false) }
            }
        }
    }
    
    fun approveContent(videoId: String) {
        viewModelScope.launch {
            try {
                adminRepository.approveVideo(videoId)
                // 更新UI状态，移除已审核的视频
                _uiState.update { state ->
                    state.copy(
                        pendingVideos = state.pendingVideos.filter { it.id != videoId }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "审核操作失败: ${e.message}") }
            }
        }
    }
    
    fun rejectContent(videoId: String) {
        viewModelScope.launch {
            try {
                adminRepository.rejectVideo(videoId)
                // 更新UI状态，移除已拒绝的视频
                _uiState.update { state ->
                    state.copy(
                        pendingVideos = state.pendingVideos.filter { it.id != videoId }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "拒绝操作失败: ${e.message}") }
            }
        }
    }
    
    fun banUser(userId: String) {
        viewModelScope.launch {
            try {
                adminRepository.banUser(userId)
                // 更新UI状态，将用户标记为已禁用
                _uiState.update { state ->
                    state.copy(
                        users = state.users.map { 
                            if (it.id == userId) it.copy(isBanned = true) else it 
                        }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "禁用用户失败: ${e.message}") }
            }
        }
    }
    
    fun unbanUser(userId: String) {
        viewModelScope.launch {
            try {
                adminRepository.unbanUser(userId)
                // 更新UI状态，将用户标记为正常
                _uiState.update { state ->
                    state.copy(
                        users = state.users.map { 
                            if (it.id == userId) it.copy(isBanned = false) else it 
                        }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "解除禁用失败: ${e.message}") }
            }
        }
    }
    
    fun retry(tab: AdminTab) {
        when (tab) {
            AdminTab.CONTENT_REVIEW -> loadContentForReview()
            AdminTab.USER_MANAGEMENT -> loadUsers()
            AdminTab.STATISTICS -> loadStatistics()
        }
    }
    
    // 模拟数据，实际项目中应从API获取
    init {
        // 初始化模拟数据
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        
        val mockPendingVideos = listOf(
            PendingVideo(
                id = "v1",
                title = "Unity UGUI系统详解",
                description = "本视频详细讲解了Unity UGUI系统的使用方法，包括Canvas设置、布局组件和响应式设计等内容。",
                thumbnailUrl = "https://example.com/thumb1.jpg",
                authorName = "UI设计师小明",
                uploadTime = formatter.format(Date(System.currentTimeMillis() - 3600000))
            ),
            PendingVideo(
                id = "v2",
                title = "多分辨率UI适配技巧",
                description = "分享几种常用的UI适配方法，解决不同屏幕尺寸下的显示问题。",
                thumbnailUrl = "https://example.com/thumb2.jpg",
                authorName = "游戏开发者小红",
                uploadTime = formatter.format(Date(System.currentTimeMillis() - 7200000))
            ),
            PendingVideo(
                id = "v3",
                title = "UI动画效果实现",
                description = "教你如何制作流畅的UI动画效果，提升用户体验。",
                thumbnailUrl = "https://example.com/thumb3.jpg",
                authorName = "动效设计师小张",
                uploadTime = formatter.format(Date(System.currentTimeMillis() - 10800000))
            )
        )
        
        val mockUsers = listOf(
            UserInfo(
                id = "u1",
                username = "UI设计师小明",
                avatar = "https://example.com/avatar1.jpg",
                registerTime = "2023-01-15",
                isBanned = false
            ),
            UserInfo(
                id = "u2",
                username = "游戏开发者小红",
                avatar = "https://example.com/avatar2.jpg",
                registerTime = "2023-02-20",
                isBanned = false
            ),
            UserInfo(
                id = "u3",
                username = "恶意用户小黑",
                avatar = "https://example.com/avatar3.jpg",
                registerTime = "2023-03-10",
                isBanned = true
            )
        )
        
        val mockStatistics = Statistics(
            totalUsers = 1250,
            newUsersToday = 45,
            activeUsers = 680,
            totalVideos = 3200,
            newVideosToday = 78,
            pendingReviewVideos = 12,
            totalComments = 15600,
            totalDanmaku = 45800,
            totalLikes = 28900
        )
        
        _uiState.update { 
            it.copy(
                pendingVideos = mockPendingVideos,
                users = mockUsers,
                statistics = mockStatistics
            ) 
        }
    }
}

/**
 * 后台管理系统UI状态
 */
data class AdminUiState(
    val pendingVideos: List<PendingVideo> = emptyList(),
    val users: List<UserInfo> = emptyList(),
    val statistics: Statistics = Statistics(),
    val isLoading: Boolean = false,
    val error: String? = null
)

/**
 * 待审核视频数据类
 */
data class PendingVideo(
    val id: String,
    val title: String,
    val description: String,
    val thumbnailUrl: String,
    val authorName: String,
    val uploadTime: String
)

/**
 * 用户信息数据类
 */
data class UserInfo(
    val id: String,
    val username: String,
    val avatar: String,
    val registerTime: String,
    val isBanned: Boolean
)

/**
 * 统计数据类
 */
data class Statistics(
    val totalUsers: Int = 0,
    val newUsersToday: Int = 0,
    val activeUsers: Int = 0,
    val totalVideos: Int = 0,
    val newVideosToday: Int = 0,
    val pendingReviewVideos: Int = 0,
    val totalComments: Int = 0,
    val totalDanmaku: Int = 0,
    val totalLikes: Int = 0
)