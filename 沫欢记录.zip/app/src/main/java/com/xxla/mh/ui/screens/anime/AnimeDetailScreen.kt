package com.xxla.mh.ui.screens.anime

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.data.anime.AnimeEpisode
import com.xxla.mh.data.anime.AggregatedEpisode
import com.xxla.mh.data.anime.EpisodeSource
import com.xxla.mh.data.anime.PlayInfo
import com.xxla.mh.ui.anime.AnimeDetailViewModel
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.text.selection.SelectionContainer
import com.xxla.mh.data.anime.DebugLogStore

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimeDetailScreen(
    detailUrl: String,
    onStartPlay: (PlayInfo, String) -> Unit,
    onBack: () -> Unit,
    viewModel: AnimeDetailViewModel = hiltViewModel()
) {
    val detail by viewModel.detail.collectAsState()
    val channels by viewModel.channels.collectAsState()
    val aggregated by viewModel.aggregated.collectAsState()
    val selectedChannelIndex by viewModel.selectedChannelIndex.collectAsState()
    val selectedEpisode by viewModel.selectedEpisode.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()
    val playInfo by viewModel.playInfo.collectAsState()
    var showFailureDialog by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(detailUrl) { viewModel.loadDetail(detailUrl) }
    var showSuccessDialog by remember { mutableStateOf(false) }
    LaunchedEffect(playInfo) {
        val v = playInfo?.videoUrl.orEmpty()
        val isDirect = v.startsWith("http") && (v.endsWith(".m3u8") || v.endsWith(".mp4") || v.contains("m3u8"))
        showSuccessDialog = playInfo != null && isDirect
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(detail?.title ?: "详情") },
                navigationIcon = {
                    IconButton(onClick = { onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            if (loading) {
                Box(modifier = Modifier.fillMaxSize()) {
                    androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
            } else {
                if (error != null) {
                    Text(text = "加载失败：${error}", modifier = Modifier.padding(12.dp))
                }

                // 频道列表（仍保留，用于设置默认线路）
                if (channels.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(channels.size) { idx ->
                            val ch = channels[idx]
                            Text(
                                text = ch.name,
                                modifier = Modifier
                                    .clickable { viewModel.selectChannel(idx) }
                                    .padding(8.dp),
                            )
                        }
                    }
                }

                // 剧集整合列表：合并多线路的同一集，避免重复
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(12.dp)
                ) {
                    items(aggregated.size) { idx ->
                        val agg: AggregatedEpisode = aggregated[idx]
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // 默认点击使用当前选中频道对应的源；若无则用第一个源
                                    val defaultChannel = channels.getOrNull(selectedChannelIndex)?.name
                                    val src = agg.sources.firstOrNull { it.channelName == defaultChannel }
                                        ?: agg.sources.firstOrNull()
                                    if (src != null) {
                                        viewModel.selectEpisodeSource(src)
                                        viewModel.resolvePlay()
                                        showFailureDialog = true
                                    }
                                }
                                .padding(8.dp)
                        ) {
                            // 标题
                            Text(text = agg.title)
                            // 可选线路：以标签形式展示，点击选择对应线路
                            if (agg.sources.size > 1) {
                                val displaySources = agg.sources.take(3)
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(displaySources.size) { sIdx ->
                                        val s: EpisodeSource = displaySources[sIdx]
                                        Text(
                                            text = "线路${sIdx + 1}",
                                            modifier = Modifier
                                                .clickable {
                                                    viewModel.selectEpisodeSource(s)
                                                    viewModel.resolvePlay()
                                                    showFailureDialog = true
                                                }
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFailureDialog && !loading && playInfo == null && error != null) {
        AlertDialog(
            onDismissRequest = { showFailureDialog = false },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    clipboard.setText(AnnotatedString(DebugLogStore.dump()))
                }) { Text("复制日志") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showFailureDialog = false }) { Text("关闭") }
            },
            title = { Text("获取失败") },
            text = {
                SelectionContainer {
                    Text(DebugLogStore.dump())
                }
            }
        )
    }

    val p = playInfo
    if (showSuccessDialog && p != null) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    showSuccessDialog = false
                    // 将选中的剧集网页地址传给播放页面（作为 WebView 加载的原始页面），避免把详情页地址或视频直链误用
                    val episodePageUrl = selectedEpisode?.url ?: detailUrl
                    onStartPlay(p, episodePageUrl)
                }) { Text("播放") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showSuccessDialog = false }) { Text("关闭") }
            },
            title = { Text("解析成功：直链") },
            text = {
                Column {
                    SelectionContainer { Text(p.videoUrl) }
                    Spacer(modifier = Modifier.height(8.dp))
                    androidx.compose.material3.TextButton(onClick = {
                        clipboard.setText(AnnotatedString(p.videoUrl))
                    }) { Text("复制直链") }
                }
            }
        )
    }

    BackHandler { onBack() }
}
