package com.xxla.mh.ui.screens.anime

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.AssistChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.ui.PlayerView
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.util.MimeTypes
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.snapshotFlow
import coil.compose.AsyncImage
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.google.gson.Gson
import com.xxla.mh.util.UrlUtils
import com.xxla.mh.ui.screens.chat.ChatViewModel
import com.xxla.mh.ui.screens.anime.WatchInviteViewModel
import com.xxla.mh.ui.anime.AnimePlayViewModel
import com.xxla.mh.ui.screens.chat.ChatConversationViewModel
import com.xxla.mh.ui.screens.profile.ProfileViewModel
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import com.xxla.mh.ui.player.FullscreenPlayerActivity
import kotlinx.coroutines.delay
import java.util.Locale
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.CookieManager
import androidx.compose.material3.TextButton
import android.widget.Toast
import com.xxla.mh.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimePlayScreen(
    title: String,
    episodeUrl: String,
    initialVideoUrl: String? = null,
    initialHeaders: Map<String, String> = emptyMap(),
    initialStartMs: Long? = null,
    peerId: String? = null,
    peerName: String? = null,
    peerAvatar: String? = null,
    onBack: () -> Unit,
    viewModel: AnimePlayViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val playInfo by viewModel.playInfo.collectAsState()
    val chatViewModel: ChatViewModel = hiltViewModel()
    val chatUiState by chatViewModel.uiState.collectAsState()
    val inviteViewModel: WatchInviteViewModel = hiltViewModel()
    val conversationViewModel: ChatConversationViewModel = hiltViewModel()
    val convUiState by conversationViewModel.uiState.collectAsState()
    // 服务器态一起看：在线人数与好友是否在看
    val watchersCountVm by viewModel.watchersCount.collectAsState()
    val friendWatchingVm by viewModel.friendWatching.collectAsState()
    val watchersIds by viewModel.watchersIds.collectAsState()
    val watchKey by viewModel.watchContentKey.collectAsState()
    // 当前登录用户信息（用于排除自己，识别好友）
    val profileViewModel: ProfileViewModel = hiltViewModel()
    val authUi by profileViewModel.authState.collectAsState()
    val selfUserId = authUi.user?.id ?: ""
    val isPlaying = remember { mutableStateOf(true) }
    val showControls = remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableStateOf(0L) }
    var durationMs by remember { mutableStateOf(0L) }
    var bufferedPosition by remember { mutableStateOf(0L) }
    var useBrowserPlayer by remember { mutableStateOf(false) }
    var inviteOpen by remember { mutableStateOf(false) }
    var contactQuery by remember { mutableStateOf("") }
    // 拖拽标记需要在更高作用域，以便周期保存逻辑可见
    var isScrubbing by remember { mutableStateOf(false) }

    // 动态对端：初始来自导航参数，后续根据在线用户自动填充
    var livePeerId by remember { mutableStateOf(peerId) }

    // 读取已保存的播放进度（如无传入 startMs 则使用此值）
    val savedProgress by viewModel.readProgress(episodeUrl).collectAsState(initial = null)
    val resolvedStartMs = (initialStartMs ?: savedProgress ?: 0L).coerceAtLeast(0L)

    LaunchedEffect(episodeUrl, initialVideoUrl) {
        if (initialVideoUrl != null && initialVideoUrl.isNotBlank()) {
            viewModel.setInitial(com.xxla.mh.data.anime.PlayInfo(initialVideoUrl, initialHeaders))
        } else {
            viewModel.resolve(episodeUrl)
        }
    }

    // 一起看：设置聊天对端并加载会话，标记进入
    LaunchedEffect(peerId) {
        if (!peerId.isNullOrBlank()) {
            conversationViewModel.setPeer(peerId, peerName, peerAvatar)
            conversationViewModel.loadConversation()
            conversationViewModel.markRead()
            // 启动服务端会话：心跳 + 在线人数轮询
            viewModel.beginWatch(contentKey = episodeUrl, friendId = peerId)
            // 同步 livePeerId
            livePeerId = peerId
        }
    }

    // 未指定好友时，也应启动服务端会话以获得在线列表
    LaunchedEffect(episodeUrl, watchKey) {
        if (watchKey == null) {
            viewModel.beginWatch(contentKey = episodeUrl, friendId = peerId)
        }
    }

    // 自动识别好友进入：当在线ID列表出现非自己ID时，设置聊天对端
    LaunchedEffect(watchersIds, selfUserId) {
        if (livePeerId.isNullOrBlank()) {
            val candidate = watchersIds.firstOrNull { it.isNotBlank() && it != selfUserId }
            if (candidate != null) {
                livePeerId = candidate
                conversationViewModel.setPeer(candidate, peerName, peerAvatar)
                conversationViewModel.loadConversation()
                conversationViewModel.loadPeerRelation()
                conversationViewModel.markRead()
            }
        }
    }

    val player = remember(playInfo) {
        if (playInfo != null) {
            val forcedUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
            val forcedHeaders = playInfo!!.headers.toMutableMap().apply {
                this["User-Agent"] = forcedUa
                this["Referer"] = ""
            }
            val httpFactory = DefaultHttpDataSource.Factory()
                .setDefaultRequestProperties(forcedHeaders)
                .setUserAgent(forcedUa)
            val mediaSourceFactory = DefaultMediaSourceFactory(httpFactory)
            ExoPlayer.Builder(context)
                .setMediaSourceFactory(mediaSourceFactory)
                .build().apply {
                    val builder = MediaItem.Builder().setUri(playInfo!!.videoUrl)
                    if (playInfo!!.videoUrl.lowercase(Locale.ROOT).contains(".m3u8")) {
                        builder.setMimeType(MimeTypes.APPLICATION_M3U8)
                    }
                    setMediaItem(builder.build())
                    prepare()
                    playWhenReady = true
                    isPlaying.value = true
                    isMuted = (volume == 0f)
                    try {
                        val start = resolvedStartMs
                        if (start > 0L) {
                            seekTo(start)
                            currentPosition = start
                        }
                    } catch (_: Throwable) {}
                    addListener(object : com.google.android.exoplayer2.Player.Listener {
                        override fun onPlaybackStateChanged(state: Int) {
                            if (state == com.google.android.exoplayer2.Player.STATE_READY) {
                                val start = resolvedStartMs
                                val dur = duration
                                if (start > 0L && dur > 0) {
                                    val safeStart = start.coerceIn(0L, dur - 1000L)
                                    if (kotlin.math.abs(currentPosition - safeStart) > 500) {
                                        seekTo(safeStart)
                                        currentPosition = safeStart
                                    }
                                }
                            }
                        }
                        override fun onPlayerError(error: com.google.android.exoplayer2.PlaybackException) {
                            useBrowserPlayer = true
                        }
                    })
                }
        } else null
    }

    val fullscreenLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { /* 可在未来恢复播放进度 */ }
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = {
                        val dur = durationMs
                        val safePos = if (dur > 0L) currentPosition.coerceIn(0L, dur - 1000L) else currentPosition
                        viewModel.saveProgress(episodeUrl, safePos)
                        onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    // 外部分享（带进度）
                    IconButton(onClick = {
                        val dur = durationMs
                        val safePos = if (dur > 0L) currentPosition.coerceIn(0L, dur - 1000L) else currentPosition
                        // 先保存一次进度
                        viewModel.saveProgress(episodeUrl, safePos)
                        val route = com.xxla.mh.navigation.Screen.AnimePlay.createDeepLink(
                            title = title,
                            episodeUrl = episodeUrl,
                            videoUrl = playInfo?.videoUrl ?: (initialVideoUrl ?: ""),
                            headers = playInfo?.headers ?: initialHeaders,
                            startMs = safePos
                        )
                        val shareText = com.xxla.mh.util.ShareUtils.buildShareText(
                            title = title,
                            deepLink = route,
                            positionMs = safePos
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        try {
                            context.startActivity(Intent.createChooser(intent, "分享"))
                        } catch (_: Throwable) {
                            Toast.makeText(context, "无法打开分享", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Filled.Share, contentDescription = "分享")
                    }
                    IconButton(onClick = { inviteOpen = true }) {
                        Icon(Icons.Filled.Send, contentDescription = "邀请一起看")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (inviteOpen) {
            LaunchedEffect(inviteOpen) {
                if (inviteOpen) chatViewModel.loadContacts()
            }
            AlertDialog(
                onDismissRequest = { inviteOpen = false },
                title = { Text(text = "邀请一起看") },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(text = "选择联系人发送当前播放邀请：")
                        Spacer(modifier = Modifier.height(8.dp))
                        if (chatUiState.isLoading) {
                            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        } else if (chatUiState.error != null) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(text = "加载联系人失败：${chatUiState.error}", color = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.height(8.dp))
                                TextButton(onClick = { chatViewModel.loadContacts() }) { Text("重试") }
                            }
                        } else {
                            OutlinedTextField(
                                value = contactQuery,
                                onValueChange = { contactQuery = it },
                                label = { Text("搜索联系人") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            val filtered = remember(chatUiState.contacts, contactQuery) {
                                if (contactQuery.isBlank()) chatUiState.contacts
                                else chatUiState.contacts.filter { it.name.contains(contactQuery, ignoreCase = true) }
                            }
                            if (filtered.isEmpty()) {
                                Text(text = "未找到匹配的联系人")
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                                ) {
                                    items(filtered) { c ->
                                        Surface(tonalElevation = 1.dp, shape = MaterialTheme.shapes.small) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(8.dp)
                                                    .clickable {
                                                        val payload = WatchInviteViewModel.InvitePayload(
                                                            title = title,
                                                            episodeUrl = episodeUrl,
                                                            videoUrl = playInfo?.videoUrl ?: (initialVideoUrl ?: ""),
                                                            headers = playInfo?.headers ?: initialHeaders,
                                                            positionMs = currentPosition
                                                        )
                                                        inviteViewModel.sendInvite(c.id, payload) { ok, err ->
                                                            inviteOpen = false
                                                            if (ok) {
                                                                Toast.makeText(context, "已发送邀请给 ${c.name}", Toast.LENGTH_SHORT).show()
                                                            } else {
                                                                Toast.makeText(context, "发送失败：${err ?: "未知错误"}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    },
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                AsyncImage(
                                                    model = UrlUtils.toAbsolute(c.avatar),
                                                    contentDescription = null,
                                                    modifier = Modifier.size(40.dp).clip(MaterialTheme.shapes.small)
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(text = c.name)
                                                    val sub = when {
                                                        c.isFriend -> "好友"
                                                        c.isFollowing -> "已关注"
                                                        c.isFollower -> "关注了你"
                                                        else -> null
                                                    }
                                                    if (sub != null) Text(text = sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                                }
                                                if (c.online) {
                                                    AssistChip(onClick = {}, label = { Text("在线") })
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { inviteOpen = false }) { Text("取消") }
                }
            )
        }
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            // 顶部 16:9 播放器区域
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color.Black)
                    .pointerInput(Unit) { detectTapGestures(onTap = { showControls.value = !showControls.value }) }
            ) {
                if (useBrowserPlayer) {
                    val forcedUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"
                    val ua = forcedUa
                    val cookies = playInfo?.headers?.get("Cookie")
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.mediaPlaybackRequiresUserGesture = false
                                settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                settings.userAgentString = ua
                                CookieManager.getInstance().setAcceptCookie(true)
                                if (!cookies.isNullOrBlank()) {
                                    try {
                                        CookieManager.getInstance().setCookie(episodeUrl, cookies)
                                        playInfo?.videoUrl?.let { CookieManager.getInstance().setCookie(it, cookies) }
                                    } catch (_: Throwable) { }
                                }
                                webChromeClient = WebChromeClient()
                                webViewClient = object : WebViewClient() {}
                                val directUrl = playInfo?.videoUrl?.takeIf { it.isNotBlank() } ?: (initialVideoUrl ?: "")
                                if (directUrl.isNotBlank()) {
                                    val startSecondsStr = try {
                                        val sec = (resolvedStartMs.coerceAtLeast(0L)) / 1000.0
                                        java.lang.String.format(java.util.Locale.US, "%.3f", sec)
                                    } catch (_: Throwable) { "0" }
                                    val html = if (directUrl.contains("m3u8")) {
                                        """
                                        <html>
                                        <head>
                                          <meta name='viewport' content='width=device-width,initial-scale=1' />
                                          <style>html,body{margin:0;background:#000;height:100%} video{width:100%;height:100%;background:#000}</style>
                                          <script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
                                        </head>
                                        <body>
                                          <video id="v" controls autoplay playsinline></video>
                                          <script>
                                            (function(){
                                              var url = "$directUrl";
                                              var v = document.getElementById('v');
                                              var start = $startSecondsStr;
                                              if (window.Hls && window.Hls.isSupported()) {
                                                var hls = new Hls({enableWorker:true, xhrSetup: function(xhr, url){ try { xhr.setRequestHeader('Referer', ''); } catch(e){} }});
                                                hls.loadSource(url);
                                                hls.attachMedia(v);
                                              } else {
                                                v.src = url;
                                              }
                                              try {
                                                v.addEventListener('loadedmetadata', function(){
                                                  try { if (start > 0) v.currentTime = start; } catch(e){}
                                                });
                                              } catch(e){}
                                            })();
                                          </script>
                                        </body>
                                        </html>
                                        """.trimIndent()
                                    } else {
                                        """
                                        <html>
                                        <head>
                                          <meta name='viewport' content='width=device-width,initial-scale=1' />
                                          <style>html,body{margin:0;background:#000;height:100%} video{width:100%;height:100%;background:#000}</style>
                                        </head>
                                        <body>
                                          <video id="v" controls autoplay playsinline src="$directUrl"></video>
                                          <script>
                                            (function(){
                                              var v = document.getElementById('v');
                                              var start = $startSecondsStr;
                                              try {
                                                v.addEventListener('loadedmetadata', function(){
                                                  try { if (start > 0) v.currentTime = start; } catch(e){}
                                                });
                                              } catch(e){}
                                            })();
                                          </script>
                                        </body>
                                        </html>
                                        """.trimIndent()
                                    }
                                    if (html != null) {
                                        loadDataWithBaseURL(directUrl, html, "text/html", "utf-8", null)
                                    } else {
                                        val headers = mapOf("Referer" to "")
                                        // 非视频直链的网页回退到直接加载 URL（很少见）
                                        loadUrl(directUrl, headers)
                                    }
                                }
                            }
                        },
                        onRelease = { v -> (v as? WebView)?.destroy() }
                    )
                } else if (player != null) {
                    // 拖拽标记在外层声明，此处直接使用以控制刷新
                    // 播放进度刷新：当正在播放时，每500ms更新一次UI显示的进度
                    LaunchedEffect(isPlaying.value) {
                        while (isPlaying.value) {
                            if (!isScrubbing) {
                                currentPosition = player.currentPosition
                            }
                            durationMs = player.duration
                            bufferedPosition = player.bufferedPosition
                            delay(500)
                        }
                    }

                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            val view = LayoutInflater.from(ctx)
                                .inflate(R.layout.compose_player_view, null) as PlayerView
                            view.useController = false
                            view.layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            try {
                                view.setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                                view.setKeepContentOnPlayerReset(true)
                                view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT)
                            } catch (_: Throwable) {}
                            // 让 TextureView 在 Compose 叠层中更稳定
                            view.alpha = 0.999f
                            try { view.z = 1f } catch (_: Throwable) {}
                            view.player = player
                            view
                        }
                    )

                    
                    

                    // 底部控制栏（与首页播放器一致）
                    val debugHideControls = false
                    if (!debugHideControls) {
                        androidx.compose.animation.AnimatedVisibility(
                            visible = showControls.value,
                            enter = EnterTransition.None,
                            exit = ExitTransition.None,
                            modifier = Modifier.align(Alignment.BottomCenter)
                        ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(
                                        0.6f to Color.Transparent,
                                        0.85f to Color.Black.copy(alpha = 0.20f),
                                        1f to Color.Black.copy(alpha = 0.45f)
                                    )
                                )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = {
                                        if (isPlaying.value) player.pause() else player.play()
                                        isPlaying.value = !isPlaying.value
                                    }) {
                                        Icon(
                                            if (isPlaying.value) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                            contentDescription = if (isPlaying.value) "暂停" else "播放",
                                            tint = Color.White
                                        )
                                    }
                                    Spacer(modifier = Modifier.weight(1f))

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = {
                                            isMuted = !isMuted
                                            player.volume = if (isMuted) 0f else 1f
                                        }) {
                                            Icon(
                                                if (isMuted) Icons.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = if (isMuted) "取消静音" else "静音",
                                                tint = Color.White
                                            )
                                        }

                                        

                                        // 全屏按钮（传递 headers）
                                        IconButton(onClick = {
                                            player.pause()
                                            val url = playInfo?.videoUrl ?: ""
                                            val headersJson = com.google.gson.Gson().toJson(playInfo?.headers ?: emptyMap<String, String>())
                                            val intent = Intent(context, FullscreenPlayerActivity::class.java).apply {
                                                putExtra(FullscreenPlayerActivity.EXTRA_URL, url)
                                                putExtra(FullscreenPlayerActivity.EXTRA_START_MS, player.currentPosition)
                                                putExtra(FullscreenPlayerActivity.EXTRA_MUTED, isMuted)
                                                putExtra(FullscreenPlayerActivity.EXTRA_HEADERS, headersJson)
                                            }
                                            if (url.isNotBlank()) {
                                                fullscreenLauncher.launch(intent)
                                            }
                                        }) {
                                            Icon(
                                                Icons.Filled.Fullscreen,
                                                contentDescription = "全屏",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }

                                val safeDuration = durationMs.coerceAtLeast(1L)
                                val density = LocalDensity.current
                                val progressFraction = (currentPosition.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
                                val bufferFraction = (bufferedPosition.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
                                var dragFraction by remember(progressFraction) { mutableStateOf(progressFraction) }

                                BoxWithConstraints(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(24.dp)
                                ) {
                                    Canvas(modifier = Modifier
                                        .fillMaxWidth()
                                        .height(20.dp)
                                        .align(Alignment.Center)
                                        .pointerInput(safeDuration) {
                                            // 点击跳转
                                            detectTapGestures(onTap = { offset ->
                                                val w = size.width
                                                val frac = (offset.x / w).coerceIn(0f, 1f)
                                                val targetMs = (safeDuration * frac).toLong()
                                                player.seekTo(targetMs)
                                                currentPosition = targetMs
                                            })
                                        }
                                        .pointerInput(safeDuration) {
                                            // 拖拽调整
                                            detectDragGestures(
                                                onDragStart = {
                                                    isScrubbing = true
                                                },
                                                onDragEnd = {
                                                    isScrubbing = false
                                                    val targetMs = (safeDuration * dragFraction).toLong()
                                                    player.seekTo(targetMs)
                                                    currentPosition = targetMs
                                                }
                                            ) { change: PointerInputChange, dragAmount: Offset ->
                                                val w = size.width
                                                val delta = dragAmount.x
                                                val pxPerFrac = w
                                                val deltaFrac = delta / pxPerFrac
                                                dragFraction = (dragFraction + deltaFrac).coerceIn(0f, 1f)
                                                currentPosition = (safeDuration * dragFraction).toLong()
                                            }
                                        }
                                    ) {
                                        val w = size.width
                                        val centerY = size.height / 2f
                                        val gap = with(density) { 4.dp.toPx() }
                                        val trackHeight = with(density) { 3.dp.toPx() }
                                        val thumbRadius = with(density) { 6.dp.toPx() }

                                        // 缓冲条
                                        drawLine(
                                            color = Color.White.copy(alpha = 0.25f),
                                            start = Offset(0f, centerY),
                                            end = Offset(w * bufferFraction, centerY),
                                            strokeWidth = trackHeight,
                                            cap = StrokeCap.Round
                                        )
                                        // 进度条
                                        drawLine(
                                            color = Color.White,
                                            start = Offset(0f, centerY),
                                            end = Offset(w * dragFraction, centerY),
                                            strokeWidth = trackHeight,
                                            cap = StrokeCap.Round
                                        )
                                        // 拇指
                                        drawCircle(
                                            color = Color.White,
                                            radius = thumbRadius,
                                            center = Offset(w * dragFraction, centerY)
                                        )
                                    }
                                }
                            }
                        }
                        }
                    }
                    // 控制栏自动隐藏
                    LaunchedEffect(showControls.value) {
                        if (showControls.value) {
                            delay(3000)
                            showControls.value = false
                        }
                    }
                } else {
                    androidx.compose.material3.CircularProgressIndicator(modifier = androidx.compose.ui.Modifier.align(Alignment.Center))
                }
            }

            // 聊天区（一起看）：当识别到对端或明确传入时显示
            if (!livePeerId.isNullOrBlank()) {
                // 使用服务端权威在线统计
                val friendWatching = true
                val watchersCount = if (watchersCountVm <= 0) 1 else watchersCountVm

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(onClick = {}, label = { Text("正在观看人数：$watchersCount") })
                        Spacer(modifier = Modifier.width(8.dp))
                        AssistChip(onClick = {}, label = { Text(if (friendWatching) "好友正在观看" else "好友未在看") })
                        // 删除占位提示：对方已进入，可以聊天
                    }

                    // 头像+名称头部
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = UrlUtils.toAbsolute(convUiState.peerAvatar),
                            contentDescription = null,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = convUiState.peerName ?: "会话", style = MaterialTheme.typography.titleMedium)
                    }

                    // 列表状态与自动滚动控制
                    val listState = rememberLazyListState()
                    var initialScrollDone by remember { mutableStateOf(false) }
                    LaunchedEffect(livePeerId) { initialScrollDone = false }
                    val isNearBottom by remember {
                        derivedStateOf {
                            val layoutInfo = listState.layoutInfo
                            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                            val total = layoutInfo.totalItemsCount
                            total > 0 && lastVisible >= total - 2
                        }
                    }
                    // 用过滤后的消息控制滚动，避免滚到被隐藏的系统消息
                    val visibleMessagesForScroll = remember(convUiState.messages) {
                        convUiState.messages.filterNot { m ->
                            !m.recalled && m.content.startsWith("WATCH_") && !m.content.startsWith("WATCH_INVITE:")
                        }
                    }
                    LaunchedEffect(visibleMessagesForScroll.size, convUiState.isLoading, convUiState.loadingMore) {
                        if (visibleMessagesForScroll.isNotEmpty() && !convUiState.loadingMore) {
                            // 等一帧，确保 LazyColumn 完成布局后再滚动
                            delay(50)
                            val lastIndex = visibleMessagesForScroll.lastIndex
                            if (!initialScrollDone || isNearBottom) {
                                listState.scrollToItem(lastIndex)
                                initialScrollDone = true
                            }
                        }
                    }
                    // 发送完成后也做一次滚动，以防上面的尺寸监听未触发
                    LaunchedEffect(convUiState.sending, visibleMessagesForScroll.size) {
                        if (!convUiState.sending && visibleMessagesForScroll.isNotEmpty()) {
                            delay(50)
                            listState.animateScrollToItem(visibleMessagesForScroll.lastIndex)
                        }
                    }

                    // 消息列表（与聊天页气泡风格一致）
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .padding(horizontal = 12.dp),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp),
                        state = listState
                        ) {
                            // 使用已计算的可见消息列表，避免在 LazyListScope 内调用 remember
                            items(items = visibleMessagesForScroll, key = { it.id }) { msg ->
                                MessageBubble(
                                    item = msg,
                                    peerAvatar = convUiState.peerAvatar,
                                    myAvatar = convUiState.myAvatar,
                                    onLongPressRecall = {
                                        conversationViewModel.recallMessage(msg)
                                    },
                                    onAcceptInvite = { _ -> },
                                    onRejectInvite = { _ -> }
                                )
                            }
                        }

                    // 输入栏
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = convUiState.inputText,
                            onValueChange = { conversationViewModel.onInputChange(it) },
                            modifier = Modifier.weight(1f),
                            label = { Text("输入消息") }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = { conversationViewModel.sendMessage() }, enabled = !convUiState.sending) {
                            Icon(Icons.Filled.Send, contentDescription = "发送")
                        }
                    }
                }
            }

            // 释放前保存一次进度，并做轻量化清理
            DisposableEffect(player) {
                onDispose {
                    try {
                        val dur = durationMs
                        val safePos = if (dur > 0L) currentPosition.coerceIn(0L, dur - 1000L) else currentPosition
                        if (safePos > 0L) {
                            viewModel.saveProgress(episodeUrl, safePos)
                        }
                    } catch (_: Throwable) {}
                    viewModel.cleanupProgress()
                    player?.release()
                }
            }
        }
    }

    // 周期性保存播放进度（约每5秒，避免拖动时写入，并夹限到时长内）
    LaunchedEffect(currentPosition / 5000) {
        if (currentPosition > 0L && !isScrubbing) {
            val dur = durationMs
            val safePos = if (dur > 0L) currentPosition.coerceIn(0L, dur - 1000L) else currentPosition
            viewModel.saveProgress(episodeUrl, safePos)
        }
    }

    BackHandler {
        // 返回时写入一次最新进度（夹限到时长内）
        val dur = durationMs
        val safePos = if (dur > 0L) currentPosition.coerceIn(0L, dur - 1000L) else currentPosition
        viewModel.saveProgress(episodeUrl, safePos)
        onBack()
    }

            // 离开一起看提示
            DisposableEffect(livePeerId) {
                onDispose {
                    if (!livePeerId.isNullOrBlank()) {
                        // 停止服务端会话
                        viewModel.endWatch()
                    }
                }
            }
}

// --- 与聊天页一致的气泡与邀请解析 ---
private data class WatchInvitePayload(
    val title: String,
    val episodeUrl: String? = null,
    val videoUrl: String? = null,
    val headers: Map<String, String>? = null,
    val positionMs: Long? = null
)

private fun parseWatchInvite(content: String): WatchInvitePayload? {
    if (!content.startsWith("WATCH_INVITE:")) return null
    val json = content.removePrefix("WATCH_INVITE:")
    return runCatching { Gson().fromJson(json, WatchInvitePayload::class.java) }.getOrNull()
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    item: com.xxla.mh.ui.screens.chat.MessageItem,
    peerAvatar: String?,
    myAvatar: String?,
    onLongPressRecall: (() -> Unit)? = null,
    onAcceptInvite: ((WatchInvitePayload) -> Unit)? = null,
    onRejectInvite: ((WatchInvitePayload) -> Unit)? = null
) {
    val isMine = item.isMine
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) androidx.compose.foundation.layout.Arrangement.End else androidx.compose.foundation.layout.Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!isMine) {
            AsyncImage(
                model = UrlUtils.toAbsolute(peerAvatar),
                contentDescription = null,
                modifier = Modifier.size(28.dp).clip(MaterialTheme.shapes.small)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }

        val clipboard = LocalClipboardManager.current
        var menuOpen by remember { mutableStateOf(false) }
        Box {
            Surface(
                color = if (isMine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 2.dp,
                shape = MaterialTheme.shapes.medium
            ) {
                val bubbleText = if (item.recalled) {
                    if (isMine) "你撤回了一条消息" else "对方撤回了一条消息"
                } else item.content
                val bubbleColor = if (isMine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                val recalledColor = MaterialTheme.colorScheme.outline
                val clickableModifier = Modifier.combinedClickable(onClick = {}, onLongClick = { menuOpen = true })
                val contentLower = bubbleText.lowercase()
                val isImage = !item.recalled && (contentLower.startsWith("http://") || contentLower.startsWith("https://")) && (
                    contentLower.endsWith(".jpg") || contentLower.endsWith(".jpeg") || contentLower.endsWith(".png") || contentLower.endsWith(".gif") || contentLower.endsWith(".webp")
                )
                val invite = if (!item.recalled) parseWatchInvite(bubbleText) else null
                if (isImage) {
                    AsyncImage(
                        model = UrlUtils.toAbsolute(bubbleText),
                        contentDescription = null,
                        modifier = Modifier.size(160.dp).clip(MaterialTheme.shapes.medium).then(clickableModifier)
                    )
                } else if (invite != null) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp).then(clickableModifier)) {
                        Text(
                            text = "一起看邀请",
                            style = MaterialTheme.typography.titleSmall,
                            color = bubbleColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = invite.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = bubbleColor
                        )
                        val linkText = invite.videoUrl?.takeIf { it.isNotBlank() } ?: invite.episodeUrl?.takeIf { it.isNotBlank() }
                        if (!linkText.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = linkText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        val posMs = invite.positionMs ?: 0L
                        if (posMs > 0L) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "开始位置：${formatMs(posMs)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
                            androidx.compose.material3.Button(onClick = { onAcceptInvite?.invoke(invite) }, enabled = !item.recalled) {
                                Text("接受")
                            }
                            androidx.compose.material3.OutlinedButton(onClick = { onRejectInvite?.invoke(invite) }, enabled = !item.recalled) {
                                Text("拒绝")
                            }
                        }
                    }
                } else {
                    Text(
                        text = bubbleText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp).then(clickableModifier),
                        color = if (item.recalled) recalledColor else bubbleColor,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            androidx.compose.material3.DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                androidx.compose.material3.DropdownMenuItem(
                    text = { Text("复制") },
                    onClick = {
                        clipboard.setText(AnnotatedString(item.content))
                        menuOpen = false
                    }
                )
                if (onLongPressRecall != null && !item.recalled) {
                    androidx.compose.material3.DropdownMenuItem(
                        text = { Text("撤回") },
                        onClick = {
                            onLongPressRecall()
                            menuOpen = false
                        }
                    )
                }
            }
        }

        if (isMine) {
            Spacer(modifier = Modifier.width(6.dp))
            AsyncImage(
                model = UrlUtils.toAbsolute(myAvatar),
                contentDescription = null,
                modifier = Modifier.size(28.dp).clip(MaterialTheme.shapes.small)
            )
        }
    }
}
