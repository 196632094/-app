package com.xxla.mh.ui.screens.anime

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.xxla.mh.data.anime.AnimeSubject
import com.xxla.mh.ui.anime.AnimeSearchViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimeSearchScreen(
    onOpenDetail: (AnimeSubject) -> Unit,
    onBack: () -> Unit,
    viewModel: AnimeSearchViewModel = hiltViewModel()
) {
    val query by viewModel.query.collectAsState()
    val results by viewModel.results.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("看动漫") },
                navigationIcon = {
                    IconButton(onClick = { onBack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { viewModel.onQueryChange(it) },
                    label = { Text("搜索动漫…") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { viewModel.search() })
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { viewModel.search() }) {
                    Text("搜索")
                }
            }

            if (loading) {
                Box(modifier = Modifier.fillMaxSize()) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    when {
                        error != null -> {
                            Text(
                                text = "加载失败：${error}",
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        results.isEmpty() && query.isNotBlank() -> {
                            Text(
                                text = "未找到相关结果",
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        results.isEmpty() && query.isBlank() -> {
                            Text(
                                text = "请输入关键词进行搜索",
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(results.size) { idx ->
                            val item = results[idx]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() }
                                    ) { onOpenDetail(item) }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            ) {
                                Text(text = item.title)
                            }
                        }
                    }
                }
            }
        }
    }

    BackHandler { onBack() }
}
