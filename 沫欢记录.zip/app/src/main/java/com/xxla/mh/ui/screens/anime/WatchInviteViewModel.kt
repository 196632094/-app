package com.xxla.mh.ui.screens.anime

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.xxla.mh.ui.screens.chat.ChatRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WatchInviteViewModel @Inject constructor(
    private val chatRepository: ChatRepository
) : ViewModel() {

    data class InvitePayload(
        val title: String,
        val episodeUrl: String? = null,
        val videoUrl: String? = null,
        val headers: Map<String, String>? = null,
        val positionMs: Long? = null
    )

    fun sendInvite(peerId: String, payload: InvitePayload, onResult: (Boolean, String?) -> Unit = { _, _ -> }) {
        viewModelScope.launch {
            runCatching {
                val json = Gson().toJson(payload)
                val content = "WATCH_INVITE:${json}"
                chatRepository.sendMessage(peerId, content)
            }.onSuccess {
                onResult(true, null)
            }.onFailure {
                onResult(false, it.message)
            }
        }
    }
}
