package com.xxla.mh.ui.screens.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.xxla.mh.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    navController: NavController,
    viewModel: AuthViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    var showNewUserAvatarTip by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.isLoggedIn, uiState.isNewUser) {
        if (uiState.isLoggedIn) {
            if (uiState.isNewUser && !showNewUserAvatarTip) {
                // 仅新注册用户弹窗提示设置头像
                showNewUserAvatarTip = true
            } else if (!uiState.isNewUser && !showNewUserAvatarTip) {
                // 老用户或非新注册，直接进入首页
                navController.navigate(Screen.Home.route) {
                    launchSingleTop = true
                    restoreState = true
                }
                navController.popBackStack(Screen.Login.route, true)
                navController.popBackStack(Screen.Register.route, true)
            }
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "登录 / 注册", style = MaterialTheme.typography.titleLarge) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("用户名") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("密码") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions.Default,
                        singleLine = true,
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = if (passwordVisible) "隐藏密码" else "显示密码"
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.loginOrRegister(username, password) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        enabled = !uiState.isLoading && username.isNotBlank() && password.isNotBlank()
                    ) {
                        if (uiState.isLoading) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Text(
                                text = "立即开始",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    uiState.errorMessage?.let { error ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = error,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }

    // 新用户头像提示弹窗
    if (showNewUserAvatarTip) {
        AlertDialog(
            onDismissRequest = {
                // 稍后再说：进入首页
                showNewUserAvatarTip = false
                viewModel.markNewUserHandled()
                navController.navigate(Screen.Home.route) {
                    launchSingleTop = true
                    restoreState = true
                }
                navController.popBackStack(Screen.Login.route, true)
                navController.popBackStack(Screen.Register.route, true)
            },
            title = { Text("新用户提示") },
            text = { Text("欢迎加入！点击头像可选择图片更换。") },
            confirmButton = {
                TextButton(onClick = {
                    // 去个人主页设置头像
                    showNewUserAvatarTip = false
                    viewModel.markNewUserHandled()
                    navController.navigate(Screen.Profile.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                    navController.popBackStack(Screen.Login.route, true)
                    navController.popBackStack(Screen.Register.route, true)
                }) {
                    Text("去设置头像")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    // 稍后再说：进入首页
                    showNewUserAvatarTip = false
                    viewModel.markNewUserHandled()
                    navController.navigate(Screen.Home.route) {
                        launchSingleTop = true
                        restoreState = true
                    }
                    navController.popBackStack(Screen.Login.route, true)
                    navController.popBackStack(Screen.Register.route, true)
                }) {
                    Text("稍后再说")
                }
            }
        )
    }
}
