package com.xxla.mh.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.net.Uri
import com.xxla.mh.data.User
import com.xxla.mh.data.UserPreferencesRepository
import com.xxla.mh.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AuthUiState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val user: User? = null,
    val errorMessage: String? = null,
    val isNewUser: Boolean = false
)

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val userPreferencesRepository: UserPreferencesRepository,
    private val coupleSpaceRepository: com.xxla.mh.ui.screens.chat.CoupleSpaceRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        // 检查是否已登录（从DataStore读取）
        checkLoginStatus()
    }

    private fun checkLoginStatus() {
        viewModelScope.launch {
            userPreferencesRepository.userPreferencesFlow.collectLatest { preferences ->
                if (preferences.isLoggedIn) {
                    _uiState.value = _uiState.value.copy(
                        isLoggedIn = true,
                        isNewUser = false,
                        user = User(
                            id = preferences.userId,
                            username = preferences.username,
                            email = preferences.email,
                            avatar = preferences.avatar,
                            nickname = preferences.nickname,
                            signature = preferences.signature,
                            level = preferences.level,
                            uid = preferences.uid,
                            followingCount = preferences.followingCount,
                            followersCount = preferences.followersCount,
                            likesCount = preferences.likesCount,
                            videosCount = preferences.videosCount
                        )
                    )
                    // 登录状态有效时，加载情侣信息以供 LoverStatus 使用
                    loadCoupleStatus()
                }
            }
        }
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                errorMessage = null
            )

            try {
                val result = authRepository.login(username, password)
                result.fold(
                    onSuccess = { user ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isLoggedIn = true,
                            user = user,
                            errorMessage = null,
                            isNewUser = false
                        )
                        loadCoupleStatus()
                    },
                    onFailure = { exception ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = exception.message ?: "登录失败"
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "登录失败，请检查网络连接"
                )
            }
        }
    }

    fun register(username: String, email: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                errorMessage = null
            )

            try {
                val result = authRepository.register(username, email, password)
                result.fold(
                    onSuccess = { user ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isLoggedIn = true,
                            user = user,
                            errorMessage = null,
                            isNewUser = true
                        )
                    },
                    onFailure = { exception ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = exception.message ?: "注册失败"
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "注册失败，请检查网络连接"
                )
            }
        }
    }

    fun loginOrRegister(username: String, password: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                errorMessage = null
            )

            try {
                val result = authRepository.loginOrRegister(username, password)
                result.fold(
                    onSuccess = { authSuccess ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            isLoggedIn = true,
                            user = authSuccess.user,
                            errorMessage = null,
                            isNewUser = authSuccess.isNewUser
                        )
                        loadCoupleStatus()
                    },
                    onFailure = { exception ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = exception.message ?: "登录/注册失败"
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "登录/注册失败，请检查网络连接"
                )
            }
        }
    }

    fun uploadAvatar(uri: Uri) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoading = true,
                errorMessage = null
            )

            try {
                val result = authRepository.uploadAvatar(uri)
                result.fold(
                    onSuccess = { user ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            user = user,
                            errorMessage = null
                        )
                    },
                    onFailure = { exception ->
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = exception.message ?: "上传头像失败"
                        )
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "上传头像失败，请检查网络连接"
                )
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _uiState.value = _uiState.value.copy(
                isLoggedIn = false,
                user = null,
                isNewUser = false
            )
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    // 获取当前用户信息
    fun getCurrentUser(): User? = _uiState.value.user

    // 检查是否已登录
    fun isLoggedIn(): Boolean = _uiState.value.isLoggedIn

    // 标记新用户提示已处理，避免重复弹窗
    fun markNewUserHandled() {
        _uiState.value = _uiState.value.copy(isNewUser = false)
    }

    // 加载情侣关系，并设置全局 LoverStatus.partnerId
    private fun loadCoupleStatus() {
        viewModelScope.launch {
            try {
                val (partner, _) = coupleSpaceRepository.getCoupleInfo()
                com.xxla.mh.ui.components.LoverStatus.partnerId = partner?.id
            } catch (_: Exception) {
                // 静默失败，不影响登录流程；保留静态后备标注
            }
        }
    }

    fun updateProfile(nickname: String?, signature: String? = null) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            try {
                val result = authRepository.updateProfile(nickname, signature)
                result.fold(
                    onSuccess = { user ->
                        _uiState.value = _uiState.value.copy(isLoading = false, user = user)
                    },
                    onFailure = { e ->
                        _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = e.message ?: "更新资料失败")
                    }
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = "更新资料失败，请检查网络连接")
            }
        }
    }
}
