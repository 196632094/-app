package com.xxla.mh.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.TagFaces
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.util.UrlUtils
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.snapshotFlow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.ModalBottomSheet
import com.google.gson.Gson

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatConversationScreen(
    navController: NavController,
    peerId: String,
    name: String? = null,
    avatar: String? = null,
    viewModel: ChatConversationViewModel = hiltViewModel()
) {
    LaunchedEffect(peerId, name, avatar) {
        viewModel.setPeer(peerId, name, avatar)
        viewModel.loadConversation()
        viewModel.markRead()
        viewModel.loadPeerRelation()
    }

    val uiState by viewModel.uiState.collectAsState()
    val listState = rememberLazyListState()

    // 进入会话后首次自动滚动到底部；同时用于控制后续自动滚动的节制
    var initialScrollDone by remember { mutableStateOf(false) }
    LaunchedEffect(peerId) {
        initialScrollDone = false
    }

    // 判断是否接近底部（最后一个可见项已接近列表末尾）
    val isNearBottom by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = layoutInfo.totalItemsCount
            total > 0 && lastVisible >= total - 2
        }
    }

    // 过滤后的消息用于滚动控制，避免滚动到被隐藏的系统消息索引
    val visibleMessagesForScroll = remember(uiState.messages) {
        uiState.messages.filterNot { m ->
            !m.recalled && m.content.startsWith("WATCH_") && !m.content.startsWith("WATCH_INVITE:")
        }
    }

    // 首次加载完成后，自动滚动到最新消息
    LaunchedEffect(uiState.isLoading, visibleMessagesForScroll.size) {
        if (!uiState.isLoading && visibleMessagesForScroll.isNotEmpty() && !initialScrollDone) {
            listState.scrollToItem(visibleMessagesForScroll.lastIndex)
            initialScrollDone = true
        }
    }

    // 新消息到来时，若接近底部则自动滚动到底部；避免影响上拉查看历史
    LaunchedEffect(visibleMessagesForScroll.size, uiState.loadingMore) {
        if (visibleMessagesForScroll.isNotEmpty() && !uiState.loadingMore) {
            if (isNearBottom || !initialScrollDone) {
                listState.animateScrollToItem(visibleMessagesForScroll.lastIndex)
                initialScrollDone = true
            }
        }
    }

    // 轮询刷新最新消息与已读状态（在会话页停留期间）
    LaunchedEffect(peerId) {
        while (true) {
            kotlinx.coroutines.delay(2000)
            // 先标记已读，再轻量刷新当前窗口消息片段，确保已读状态及时反映
            viewModel.markRead()
            viewModel.refreshSlice()
        }
    }

    // 上拉到顶部加载历史消息
    LaunchedEffect(listState, uiState.hasMoreOlder, uiState.loadingMore) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .collect { (index, offset) ->
                if (index == 0 && offset == 0 && uiState.hasMoreOlder && !uiState.loadingMore) {
                    viewModel.loadOlder()
                }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = UrlUtils.toAbsolute(uiState.peerAvatar),
                            contentDescription = null,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = uiState.peerName ?: "会话", modifier = Modifier.weight(1f))
                        if (com.xxla.mh.ui.components.isLover(uiState.peerId)) {
                            Spacer(modifier = Modifier.width(6.dp))
                            com.xxla.mh.ui.components.LoverTag(uiState.peerId)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        if (uiState.isFollowing == false) {
                            AssistChip(onClick = {}, label = { Text("未关注") })
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        },
        bottomBar = {
            MessageInputBar(
                text = uiState.inputText,
                sending = uiState.sending,
                onTextChange = viewModel::onInputChange,
                onSendClick = viewModel::sendMessage,
                onLongSend = viewModel::sendMessageLongPress,
                onStickerClick = viewModel::toggleStickerPicker
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .pointerInput(uiState.messages.size) {
                    var dragSum = 0f
                    detectVerticalDragGestures(
                        onVerticalDrag = { _, dragAmount ->
                            dragSum += dragAmount
                        },
                        onDragEnd = {
                            if (dragSum > 80f) {
                                viewModel.refreshLatest()
                            }
                            dragSum = 0f
                        },
                        onDragCancel = { dragSum = 0f }
                    )
                }
        ) {
            if (uiState.showStickerPicker) {
                ModalBottomSheet(onDismissRequest = { viewModel.toggleStickerPicker() }) {
                    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(text = "真寻表情", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        if (uiState.loadingStickers) {
                            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        } else {
                            LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(uiState.stickers) { url ->
                                    Surface(shape = MaterialTheme.shapes.small, tonalElevation = 1.dp) {
                                        Box(modifier = Modifier.size(72.dp).combinedClickable(onClick = { viewModel.sendSticker(url) }, onLongClick = {})) {
                                            AsyncImage(
                                                model = UrlUtils.toAbsolute(url),
                                                contentDescription = null,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            when {
                uiState.isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                uiState.error != null -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = uiState.error ?: "错误", color = MaterialTheme.colorScheme.error)
                    }
                }
                else -> {
                    if (uiState.messages.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(text = "开始聊天吧～")
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(12.dp),
                            state = listState
                        ) {
                            // 使用已计算的可见消息列表，避免在 LazyListScope 内调用 remember
                            items(visibleMessagesForScroll, key = { it.id }) { msg ->
                                val canRecall = remember(msg.id, msg.timestamp, msg.isMine, msg.recalled) { 
                                    msg.isMine && !msg.recalled && (System.currentTimeMillis() - msg.timestamp) <= 2 * 60 * 1000
                                }
                        MessageBubble(
                            item = msg,
                            peerAvatar = uiState.peerAvatar,
                            myAvatar = uiState.myAvatar,
                            onLongPressRecall = if (canRecall) { { viewModel.recallMessage(msg) } } else null,
                            onAcceptInvite = { inv ->
                                val route = com.xxla.mh.navigation.Screen.AnimePlay.createRoute(
                                    title = inv.title,
                                    episodeUrl = inv.episodeUrl ?: "",
                                    videoUrl = inv.videoUrl ?: "",
                                    headers = inv.headers ?: emptyMap(),
                                    startMs = inv.positionMs ?: 0L,
                                    peerId = uiState.peerId,
                                    peerName = uiState.peerName,
                                    peerAvatar = uiState.peerAvatar
                                )
                                navController.navigate(route)
                            },
                            onRejectInvite = { _ -> }
                        )
                    }
                            if (uiState.loadingMore) {
                                item {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class WatchInvitePayload(
    val title: String,
    val episodeUrl: String? = null,
    val videoUrl: String? = null,
    val headers: Map<String, String>? = null,
    val positionMs: Long? = null
)

private fun parseWatchInvite(content: String): WatchInvitePayload? {
    if (!content.startsWith("WATCH_INVITE:")) return null
    val json = content.removePrefix("WATCH_INVITE:")
    return runCatching { Gson().fromJson(json, WatchInvitePayload::class.java) }.getOrNull()
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    item: MessageItem,
    peerAvatar: String?,
    myAvatar: String?,
    onLongPressRecall: (() -> Unit)? = null,
    onAcceptInvite: ((WatchInvitePayload) -> Unit)? = null,
    onRejectInvite: ((WatchInvitePayload) -> Unit)? = null
) {
    val isMine = item.isMine
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!isMine) {
            AsyncImage(
                model = UrlUtils.toAbsolute(peerAvatar),
                contentDescription = null,
                modifier = Modifier.size(28.dp).clip(MaterialTheme.shapes.small)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }

        val clipboard = LocalClipboardManager.current
        var menuOpen by remember { mutableStateOf(false) }
        Box {
            Surface(
                color = if (isMine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 2.dp,
                shape = MaterialTheme.shapes.medium
            ) {
                val bubbleText = if (item.recalled) {
                    if (isMine) "你撤回了一条消息" else "对方撤回了一条消息"
                } else item.content
                val bubbleColor = if (isMine) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                val recalledColor = MaterialTheme.colorScheme.outline
                val clickableModifier = Modifier.combinedClickable(onClick = {}, onLongClick = { menuOpen = true })
                val contentLower = bubbleText.lowercase()
                val isImage = !item.recalled && (contentLower.startsWith("http://") || contentLower.startsWith("https://")) && (
                    contentLower.endsWith(".jpg") || contentLower.endsWith(".jpeg") || contentLower.endsWith(".png") || contentLower.endsWith(".gif") || contentLower.endsWith(".webp")
                )
                val invite = if (!item.recalled) parseWatchInvite(bubbleText) else null
                if (isImage) {
                    AsyncImage(
                        model = UrlUtils.toAbsolute(bubbleText),
                        contentDescription = null,
                        modifier = Modifier.size(160.dp).clip(MaterialTheme.shapes.medium).then(clickableModifier)
                    )
                } else if (invite != null) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp).then(clickableModifier)) {
                        Text(
                            text = "一起看邀请",
                            style = MaterialTheme.typography.titleSmall,
                            color = bubbleColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = invite.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = bubbleColor
                        )
                        val linkText = invite.videoUrl?.takeIf { it.isNotBlank() } ?: invite.episodeUrl?.takeIf { it.isNotBlank() }
                        if (!linkText.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = linkText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        val posMs = invite.positionMs ?: 0L
                        if (posMs > 0L) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "开始位置：${formatMs(posMs)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = { onAcceptInvite?.invoke(invite) }, enabled = !item.recalled) {
                                Text("接受")
                            }
                            OutlinedButton(onClick = { onRejectInvite?.invoke(invite) }, enabled = !item.recalled) {
                                Text("拒绝")
                            }
                        }
                    }
                } else {
                    Text(
                        text = bubbleText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp).then(clickableModifier),
                        color = if (item.recalled) recalledColor else bubbleColor,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("复制") },
                    onClick = {
                        clipboard.setText(AnnotatedString(item.content))
                        menuOpen = false
                    }
                )
                if (onLongPressRecall != null && !item.recalled) {
                    DropdownMenuItem(
                        text = { Text("撤回") },
                        onClick = {
                            onLongPressRecall()
                            menuOpen = false
                        }
                    )
                }
            }
            // 已读/未读标记：显示在气泡旁，区分自己和对方消息
            val statusText = if (item.read) "已读" else "未读"
            val statusColor = MaterialTheme.colorScheme.onSurfaceVariant
            if (isMine) {
                Text(
                    text = statusText,
                    color = statusColor,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(start = 6.dp)
                )
            } else {
                Text(
                    text = statusText,
                    color = statusColor,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.BottomStart).padding(end = 6.dp)
                )
            }
        }

        if (isMine) {
            Spacer(modifier = Modifier.width(6.dp))
            AsyncImage(
                model = UrlUtils.toAbsolute(myAvatar),
                contentDescription = null,
                modifier = Modifier.size(28.dp).clip(MaterialTheme.shapes.small)
            )
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun MessageInputBar(
    text: String,
    sending: Boolean,
    onTextChange: (String) -> Unit,
    onSendClick: () -> Unit,
    onLongSend: () -> Unit,
    onStickerClick: () -> Unit
) {
    Surface(tonalElevation = 4.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                tonalElevation = 2.dp,
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                IconButton(onClick = onStickerClick, enabled = !sending, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.TagFaces, contentDescription = "真寻表情")
                }
            }
            if (text.isNotBlank()) {
                Text(
                    text = "正在输入…",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("输入消息…") },
                maxLines = 4,
                minLines = 1,
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSend = { onSendClick() })
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .combinedClickable(
                        enabled = !sending,
                        onClick = onSendClick,
                        onLongClick = onLongSend
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Send, contentDescription = "发送")
            }
        }
    }
}
