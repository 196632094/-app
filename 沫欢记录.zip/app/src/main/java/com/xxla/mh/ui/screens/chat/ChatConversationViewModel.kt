package com.xxla.mh.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.xxla.mh.data.UserPreferencesRepository
import com.xxla.mh.data.StickerRepository

@HiltViewModel
class ChatConversationViewModel @Inject constructor(
    private val repository: ChatRepository,
    private val userPreferencesRepository: UserPreferencesRepository,
    private val stickerRepository: StickerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConversationUiState())
    val uiState: StateFlow<ConversationUiState> = _uiState.asStateFlow()

    init {
        // 订阅本地用户偏好，获取头像以在我方消息气泡显示
        viewModelScope.launch {
            userPreferencesRepository.userPreferencesFlow.collectLatest { prefs ->
                _uiState.update { it.copy(myAvatar = prefs.avatar) }
            }
        }
    }

    fun setPeer(peerId: String, name: String? = null, avatar: String? = null) {
        _uiState.update { it.copy(peerId = peerId, peerName = name, peerAvatar = avatar) }
    }

    fun loadPeerRelation() {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            try {
                val following = repository.getIsFollowing(peerId)
                _uiState.update { it.copy(error = null, isFollowing = following) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message, isFollowing = null) }
            }
        }
    }

    fun loadConversation() {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val limit = _uiState.value.displayLimit
                val slice = repository.getConversation(peerId, limit = limit)
                _uiState.update { it.copy(
                    isLoading = false,
                    messages = slice,
                    totalCount = null,
                    hasMoreOlder = slice.size >= limit
                ) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "加载失败") }
            }
        }
    }

    fun markRead() {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            try {
                repository.markRead(peerId)
            } catch (_: Exception) { }
        }
    }

    fun onInputChange(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage() {
        val state = _uiState.value
        val peerId = state.peerId ?: return
        val content = state.inputText.trim()
        if (content.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(sending = true) }
            try {
                val msg = repository.sendMessage(peerId, content)
                _uiState.update { prev ->
                    val limit = prev.displayLimit
                    val combined = prev.messages + msg
                    val trimmed = if (combined.size > limit) combined.takeLast(limit) else combined
                    prev.copy(
                        sending = false,
                        inputText = "",
                        messages = trimmed,
                        totalCount = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(sending = false, error = e.message ?: "发送失败") }
            }
        }
    }

    fun sendMessageLongPress() {
        val state = _uiState.value
        val peerId = state.peerId ?: return
        val content = state.inputText
        if (content.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(sending = true) }
            try {
                val msg = repository.sendMessage(peerId, content)
                _uiState.update { prev ->
                    val limit = prev.displayLimit
                    val combined = prev.messages + msg
                    val trimmed = if (combined.size > limit) combined.takeLast(limit) else combined
                    prev.copy(
                        sending = false,
                        // 长按发送不清空输入框，便于连续发送或编辑
                        messages = trimmed,
                        totalCount = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(sending = false, error = e.message ?: "发送失败") }
            }
        }
    }

    fun loadOlder() {
        val peerId = _uiState.value.peerId ?: return
        val current = _uiState.value
        if (!current.hasMoreOlder || current.loadingMore) return
        viewModelScope.launch {
            _uiState.update { it.copy(loadingMore = true) }
            try {
                val earliest = current.messages.firstOrNull()?.timestamp
                val batch = 20
                val older = repository.getConversation(peerId, limit = batch, before = earliest)
                val merged = older + current.messages
                _uiState.update { it.copy(
                    loadingMore = false,
                    displayLimit = it.displayLimit + older.size,
                    messages = merged,
                    totalCount = null,
                    hasMoreOlder = older.size >= batch
                ) }
            } catch (e: Exception) {
                _uiState.update { it.copy(loadingMore = false, error = e.message ?: "加载更多失败") }
            }
        }
    }

    fun refreshLatest() {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            try {
                val current = _uiState.value
                val latest = current.messages.lastOrNull()?.timestamp
                val limit = current.displayLimit
                val newer = repository.getConversation(peerId, limit = limit, after = latest)
                val combined = current.messages + newer
                val trimmed = if (combined.size > limit) combined.takeLast(limit) else combined
                _uiState.update { it.copy(
                    isRefreshing = false,
                    messages = trimmed,
                    totalCount = null,
                    hasMoreOlder = trimmed.size >= limit
                ) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isRefreshing = false, error = e.message ?: "刷新失败") }
            }
        }
    }

    // 静默刷新当前窗口的消息，以更新已读状态（不显示加载状态）
    fun refreshSlice() {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            try {
                val limit = _uiState.value.displayLimit
                val slice = repository.getConversation(peerId, limit = limit)
                _uiState.update { it.copy(messages = slice, totalCount = null, hasMoreOlder = slice.size >= limit) }
            } catch (_: Exception) { }
        }
    }

    fun canRecall(item: MessageItem): Boolean {
        if (!item.isMine) return false
        if (item.recalled) return false
        val now = System.currentTimeMillis()
        return (now - item.timestamp) <= 2 * 60 * 1000
    }

    fun recallMessage(item: MessageItem) {
        val state = _uiState.value
        val peerId = state.peerId ?: return
        if (!canRecall(item)) {
            _uiState.update { it.copy(error = "超过2分钟无法撤回或无权限") }
            return
        }
        viewModelScope.launch {
            try {
                val updated = repository.recallMessage(peerId, item.id)
                val newList = state.messages.map { if (it.id == item.id) updated else it }
                _uiState.update { it.copy(messages = newList) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "撤回失败") }
            }
        }
    }

    fun toggleStickerPicker() {
        val wasOpen = _uiState.value.showStickerPicker
        _uiState.update { it.copy(showStickerPicker = !wasOpen) }
        if (!wasOpen && _uiState.value.stickers.isEmpty()) {
            loadStickers()
        }
    }

    fun loadStickers() {
        viewModelScope.launch {
            _uiState.update { it.copy(loadingStickers = true) }
            try {
                val list = stickerRepository.getStickers()
                _uiState.update { it.copy(loadingStickers = false, stickers = list) }
            } catch (e: Exception) {
                _uiState.update { it.copy(loadingStickers = false, error = e.message ?: "加载贴纸失败") }
            }
        }
    }

    fun sendSticker(url: String) {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(sending = true) }
            try {
                val msg = repository.sendMessage(peerId, url)
                _uiState.update { prev ->
                    val limit = prev.displayLimit
                    val combined = prev.messages + msg
                    val trimmed = if (combined.size > limit) combined.takeLast(limit) else combined
                    prev.copy(
                        sending = false,
                        messages = trimmed,
                        totalCount = null,
                        showStickerPicker = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(sending = false, error = e.message ?: "发送失败") }
            }
        }
    }

    fun sendSystemMessage(content: String) {
        val peerId = _uiState.value.peerId ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(sending = true) }
            try {
                val msg = repository.sendMessage(peerId, content)
                _uiState.update { prev ->
                    val limit = prev.displayLimit
                    val combined = prev.messages + msg
                    val trimmed = if (combined.size > limit) combined.takeLast(limit) else combined
                    prev.copy(
                        sending = false,
                        messages = trimmed,
                        totalCount = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(sending = false, error = e.message ?: "发送失败") }
            }
        }
    }
}

data class ConversationUiState(
    val isLoading: Boolean = false,
    val sending: Boolean = false,
    val messages: List<MessageItem> = emptyList(),
    val error: String? = null,
    val peerId: String? = null,
    val peerName: String? = null,
    val peerAvatar: String? = null,
    val myAvatar: String? = null,
    val isFollowing: Boolean? = null,
    val inputText: String = "",
    val isRefreshing: Boolean = false,
    val loadingMore: Boolean = false,
    val displayLimit: Int = 30,
    val totalCount: Int? = null,
    val hasMoreOlder: Boolean = false,
    val showStickerPicker: Boolean = false,
    val loadingStickers: Boolean = false,
    val stickers: List<String> = emptyList()
)
