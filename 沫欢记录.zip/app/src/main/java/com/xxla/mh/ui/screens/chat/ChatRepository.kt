package com.xxla.mh.ui.screens.chat

import com.xxla.mh.network.ChatApiService
import com.xxla.mh.network.ChatContact
import com.xxla.mh.network.ChatMessage
import com.xxla.mh.network.SearchApiService
import com.xxla.mh.network.SearchUserItem
import com.xxla.mh.network.UserApiService
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 聊天数据仓库
 */
@Singleton
class ChatRepository @Inject constructor(
    private val chatApi: ChatApiService,
    private val searchApi: SearchApiService,
    private val userApi: UserApiService
) {
    suspend fun getContacts(): List<Contact> {
        val resp = chatApi.getContacts()
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val contacts = resp.body()!!.data.contacts
        return contacts.map { it.toUi() }
    }

    suspend fun getConversation(
        peerId: String,
        limit: Int? = null,
        before: Long? = null,
        after: Long? = null
    ): List<MessageItem> {
        val resp = chatApi.getConversation(peerId, limit, before, after)
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.data.messages.map { it.toUi() }
    }

    suspend fun sendMessage(peerId: String, content: String): MessageItem {
        val resp = chatApi.sendMessage(peerId, com.xxla.mh.network.SendMessageRequest(content))
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.data.toUi()
    }

    suspend fun markRead(peerId: String): Int {
        val resp = chatApi.markRead(peerId)
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.data.changed
    }

    suspend fun getUnreadCount(): Int {
        val resp = chatApi.getUnreadCount()
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            return 0
        }
        return resp.body()!!.data.count
    }

    // 计算与指定联系人的未读消息数量（客户端侧近似计算）
    // 注意：为降低请求量，仅查询最近 N 条消息（默认 50），
    // 若未读消息非常多且早于该窗口，计数可能低估。
    suspend fun getUnreadCountByPeer(peerId: String, recentLimit: Int = 50): Int {
        val resp = chatApi.getConversation(peerId, limit = recentLimit)
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val msgs = resp.body()!!.data.messages
        return msgs.count { !it.isMine && !it.read }
    }

    // 查询与指定用户的关注关系（我是否关注TA）
    suspend fun getIsFollowing(userId: String): Boolean {
        val resp = userApi.getUserStats(userId)
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.data.isFollowing
    }

    private fun ChatContact.toUi(): Contact = Contact(
        id = id,
        name = (nickname ?: username),
        avatar = avatar,
        isFollowing = isFollowing == true,
        isFollower = isFollower == true,
        isFriend = isFriend == true,
        online = online == true,
        lastOnlineAt = lastOnlineAt,
        unreadCount = (this.unreadCount ?: 0)
    )

    private fun ChatMessage.toUi(): MessageItem = MessageItem(
        id = id,
        fromUserId = fromUserId,
        toUserId = toUserId,
        content = content,
        timestamp = timestamp,
        isMine = isMine,
        read = read,
        recalled = recalled == true
    )

    // 搜索相关
    suspend fun searchUsers(query: String, page: Int? = null, size: Int? = null): List<SearchUserItem> {
        val resp = searchApi.searchUsers(query, page, size)
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.data.users
    }

    // 撤回消息
    suspend fun recallMessage(peerId: String, messageId: String): MessageItem {
        val resp = chatApi.recallMessage(peerId, messageId)
        if (!resp.isSuccessful || resp.body() == null || !resp.body()!!.success) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.data.toUi()
    }

    suspend fun follow(userId: String): Boolean {
        val resp = userApi.follow(userId)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.success
    }

    suspend fun unfollow(userId: String): Boolean {
        val resp = userApi.unfollow(userId)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.success
    }
}

data class Contact(
    val id: String,
    val name: String,
    val avatar: String?,
    val isFollowing: Boolean,
    val isFollower: Boolean,
    val isFriend: Boolean,
    val online: Boolean = false,
    val lastOnlineAt: Long? = null,
    val lastMessage: MessageItem? = null,
    val unreadCount: Int = 0
)

data class MessageItem(
    val id: String,
    val fromUserId: String,
    val toUserId: String,
    val content: String,
    val timestamp: Long,
    val isMine: Boolean,
    val read: Boolean,
    val recalled: Boolean
)
