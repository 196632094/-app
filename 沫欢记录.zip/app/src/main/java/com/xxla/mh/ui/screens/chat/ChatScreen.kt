package com.xxla.mh.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.util.UrlUtils
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    navController: NavController,
    viewModel: ChatViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    // 当处于联系人视图（搜索为空）时，启动由 ViewModel 管理的轻量级自动刷新；否则取消。
    LaunchedEffect(uiState.searchQuery) {
        if (uiState.searchQuery.isBlank()) {
            viewModel.ensureAutoRefresh(intervalMs = 10000L)
        } else {
            viewModel.cancelAutoRefresh()
        }
    }
    // 页面销毁时确保停止自动刷新，避免后台无意义轮询。
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { viewModel.cancelAutoRefresh() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("聊天") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    TextButton(onClick = { navController.navigate(com.xxla.mh.navigation.Screen.CoupleSpace.route) }) {
                        Icon(Icons.Filled.Favorite, contentDescription = "情侣空间")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "情侣空间")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // 搜索框
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = viewModel::onQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    placeholder = { Text("搜索用户…") },
                    singleLine = true
                )

                if (uiState.isLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else if (uiState.error != null) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = uiState.error ?: "错误", color = MaterialTheme.colorScheme.error)
                    }
                } else {
                    if (uiState.searchQuery.isNotBlank()) {
                        // 搜索结果列表
                        if (uiState.isSearching) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        } else if (uiState.searchResults.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(text = "未找到相关用户")
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(12.dp)
                            ) {
                                items(uiState.searchResults) { user ->
                                    SearchUserItemRow(
                                        user = user,
                                        onProfileClick = {
                                            navController.navigate(
                                                com.xxla.mh.navigation.Screen.UserProfile.createRoute(user.id)
                                            )
                                        },
                                        onFollowToggle = { viewModel.toggleFollow(user.id, user.isFollowing == true) }
                                    )
                                }
                            }
                        }
                    } else {
                        // 联系人列表
                        if (uiState.contacts.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(text = "暂无联系人")
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(12.dp)
                            ) {
                                items(uiState.contacts, key = { it.id }) { contact ->
                                    ContactItem(
                                        contact = contact,
                                        onClick = {
                                            navController.navigate(
                                                com.xxla.mh.navigation.Screen.ChatConversation.createRoute(
                                                    peerId = contact.id,
                                                    name = contact.name,
                                                    avatar = contact.avatar ?: ""
                                                )
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactItem(contact: Contact, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(44.dp)) {
                AsyncImage(
                    model = UrlUtils.toAbsolute(contact.avatar),
                    contentDescription = null,
                    modifier = Modifier
                        .matchParentSize()
                        .clip(CircleShape)
                )
                if (contact.online) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .align(Alignment.BottomEnd)
                            .background(Color(0xFF2ECC71), CircleShape)
                            .border(2.dp, Color.White, CircleShape)
                    )
                }
                if (contact.unreadCount > 0) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer,
                        shape = CircleShape,
                        shadowElevation = 2.dp,
                        tonalElevation = 2.dp,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                    ) {
                        Text(
                            text = contact.unreadCount.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = contact.name,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    if (com.xxla.mh.ui.components.isLover(contact.id)) {
                        Spacer(modifier = Modifier.width(6.dp))
                        com.xxla.mh.ui.components.LoverTag(contact.id)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val tags = mutableListOf<String>()
                    if (contact.isFriend) tags.add("互相关注")
                    else {
                        if (contact.isFollowing) tags.add("已关注")
                        if (contact.isFollower) tags.add("关注你")
                    }
                    val presence = when {
                        contact.online -> "在线"
                        contact.lastOnlineAt != null -> "最近在线 ${formatRelative(contact.lastOnlineAt!!)}"
                        else -> null
                    }
                    if (presence != null) tags.add(presence)
                    Text(
                        text = tags.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                // 显示最后一条消息与时间（若可用）
                contact.lastMessage?.let { last ->
                    Text(
                        text = last.content,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = formatTime(last.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun formatTime(ts: Long): String {
    return try {
        val dt = java.time.Instant.ofEpochMilli(ts)
        val local = java.time.ZonedDateTime.ofInstant(dt, java.time.ZoneId.systemDefault())
        val formatter = java.time.format.DateTimeFormatter.ofPattern("MM-dd HH:mm")
        local.format(formatter)
    } catch (_: Exception) {
        ""
    }
}

private fun formatRelative(ts: Long): String {
    return try {
        val now = System.currentTimeMillis()
        val diff = (now - ts).coerceAtLeast(0)
        val minutes = diff / 60000
        when {
            minutes < 1 -> "刚刚"
            minutes < 60 -> "${minutes}分钟前"
            minutes < 60 * 24 -> "${minutes / 60}小时前"
            else -> "${minutes / 60 / 24}天前"
        }
    } catch (_: Exception) {
        ""
    }
}
@Composable
private fun SearchUserItemRow(
    user: com.xxla.mh.network.SearchUserItem,
    onProfileClick: () -> Unit,
    onFollowToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = UrlUtils.toAbsolute(user.avatar),
                contentDescription = null,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onProfileClick)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = user.nickname ?: user.username,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .weight(1f)
                            .clickable(onClick = onProfileClick)
                    )
                    if (com.xxla.mh.ui.components.isLover(user.id)) {
                        Spacer(modifier = Modifier.width(6.dp))
                        com.xxla.mh.ui.components.LoverTag(user.id)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                val tags = buildList {
                    add("作品 ${user.videosCount ?: 0}")
                    add("粉丝 ${user.followersCount ?: 0}")
                    if (user.isFriend == true) add("互相关注")
                    else {
                        if (user.isFollowing == true) add("已关注")
                        if (user.isFollower == true) add("关注你")
                    }
                }
                Text(
                    text = tags.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            FilledTonalButton(onClick = onFollowToggle) {
                Text(text = if (user.isFollowing == true) "已关注" else "关注")
            }
        }
    }
}
