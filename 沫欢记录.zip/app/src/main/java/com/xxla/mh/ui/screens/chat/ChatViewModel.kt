package com.xxla.mh.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repository: ChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var autoRefreshJob: Job? = null

    init {
        loadContacts()
    }

    fun loadContacts(silent: Boolean = false) {
        viewModelScope.launch {
            if (!silent) {
                _uiState.update { it.copy(isLoading = true, error = null) }
            } else {
                _uiState.update { it.copy(error = null) }
            }
            try {
                val contacts = repository.getContacts()
                _uiState.update { state ->
                    val next = state.copy(contacts = contacts)
                    if (!silent) next.copy(isLoading = false) else next
                }
                // 异步补充最后一条消息预览：仅在非静默刷新时执行，避免频繁重绘与网络请求
                if (!silent) {
                    viewModelScope.launch {
                        val updated = contacts.map { c ->
                            try {
                                val msgs = repository.getConversation(c.id, limit = 1)
                                val last = msgs.lastOrNull()
                                if (last != null) c.copy(lastMessage = last) else c
                            } catch (_: Exception) { c }
                        }
                        _uiState.update { it.copy(contacts = updated) }
                    }
                }

                // 未读数量由服务端在联系人接口直接返回，避免额外查询

                // 更新总未读数量
                viewModelScope.launch {
                    runCatching { repository.getUnreadCount() }
                        .onSuccess { total -> _uiState.update { it.copy(totalUnread = total) } }
                }
            } catch (e: Exception) {
                _uiState.update { state ->
                    if (!silent) state.copy(isLoading = false, error = e.message ?: "加载失败")
                    else state.copy(error = e.message ?: "加载失败")
                }
            }
        }
    }

    fun refresh() {
        loadContacts(silent = true)
    }

    fun ensureAutoRefresh(intervalMs: Long = 10000L) {
        if (autoRefreshJob?.isActive == true) return
        autoRefreshJob = viewModelScope.launch {
            while (isActive) {
                delay(intervalMs)
                try {
                    refresh()
                    refreshUnreadTotal()
                } catch (_: Exception) {}
            }
        }
    }

    fun cancelAutoRefresh() {
        autoRefreshJob?.cancel()
        autoRefreshJob = null
    }

    fun refreshUnreadTotal() {
        viewModelScope.launch {
            runCatching { repository.getUnreadCount() }
                .onSuccess { total -> _uiState.update { it.copy(totalUnread = total) } }
        }
    }

    // 搜索相关
    fun onQueryChange(q: String) {
        _uiState.update { it.copy(searchQuery = q) }
        if (q.isBlank()) {
            _uiState.update { it.copy(searchResults = emptyList(), isSearching = false, error = null) }
        } else {
            searchUsers(q)
        }
    }

    private fun searchUsers(query: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true, error = null) }
            try {
                val users = repository.searchUsers(query)
                _uiState.update { it.copy(isSearching = false, searchResults = users) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isSearching = false, error = e.message ?: "搜索失败") }
            }
        }
    }

    fun toggleFollow(userId: String, isFollowing: Boolean) {
        viewModelScope.launch {
            try {
                val ok = if (isFollowing) repository.unfollow(userId) else repository.follow(userId)
                if (ok) {
                    _uiState.update { state ->
                        state.copy(searchResults = state.searchResults.map { u ->
                            if (u.id == userId) u.copy(isFollowing = !isFollowing) else u
                        })
                    }
                    // 关注状态变更后，立即刷新联系人列表，避免需要重启应用
                    // 后端已返回：联系人 = 我关注的人 ∪ 与我有过私信往来的人
                    // 因此新关注的用户会立刻体现在聊天联系人中
                    loadContacts()
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "操作失败") }
            }
        }
    }
}

data class ChatUiState(
    val isLoading: Boolean = false,
    val contacts: List<Contact> = emptyList(),
    val error: String? = null,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val searchResults: List<com.xxla.mh.network.SearchUserItem> = emptyList(),
    val totalUnread: Int = 0
)
