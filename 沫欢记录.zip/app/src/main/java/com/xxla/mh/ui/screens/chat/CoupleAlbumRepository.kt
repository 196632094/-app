package com.xxla.mh.ui.screens.chat

import android.content.Context
import android.app.DownloadManager
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Environment
import android.webkit.URLUtil
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import com.xxla.mh.network.CoupleAlbumApiService
import com.xxla.mh.network.CoupleAlbumItem
import com.xxla.mh.network.BaseResponse
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream

@Singleton
class CoupleAlbumRepository @Inject constructor(
    private val api: CoupleAlbumApiService,
    @ApplicationContext private val context: Context
){
    suspend fun listAlbum(): List<CoupleAlbumItem> {
        val resp = api.getAlbum()
        if (!resp.isSuccessful || resp.body() == null) throw Exception(resp.errorBody()?.string() ?: resp.message())
        val body = resp.body()!!
        if (!body.success) return emptyList()
        return body.data
    }

    suspend fun uploadImages(uris: List<Uri>): List<CoupleAlbumItem> {
        if (uris.isEmpty()) return emptyList()
        val tempFiles = uris.map { createTempFileFromUri(context, it) }
        try {
            val parts = tempFiles.mapIndexed { index, f ->
                val uri = uris[index]
                val mime = context.contentResolver.getType(uri) ?: run {
                    val lower = f.name.lowercase()
                    when {
                        lower.endsWith(".mp4") -> "video/mp4"
                        lower.endsWith(".webm") -> "video/webm"
                        lower.endsWith(".mov") -> "video/quicktime"
                        lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
                        lower.endsWith(".png") -> "image/png"
                        lower.endsWith(".gif") -> "image/gif"
                        else -> "application/octet-stream"
                    }
                }
                val rb = f.asRequestBody(mime.toMediaTypeOrNull())
                MultipartBody.Part.createFormData("images", f.name, rb)
            }
            val resp = api.uploadImages(parts)
            if (!resp.isSuccessful || resp.body() == null) throw Exception(resp.errorBody()?.string() ?: resp.message())
            val body = resp.body()!!
            if (!body.success) throw Exception(body.message)
            return body.data
        } finally {
            tempFiles.forEach { runCatching { it.delete() } }
        }
    }

    suspend fun deleteImage(filename: String): Boolean {
        val resp = api.deleteImage(filename)
        if (!resp.isSuccessful || resp.body() == null) throw Exception(resp.errorBody()?.string() ?: resp.message())
        val body: BaseResponse = resp.body()!!
        return body.success
    }

    suspend fun saveToDevice(item: CoupleAlbumItem) {
        val abs = com.xxla.mh.util.UrlUtils.toAbsolute(item.url)
        val lower = abs.lowercase()
        if (lower.contains(".m3u8")) {
            throw Exception("该视频格式暂不支持保存")
        }
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val uri = Uri.parse(abs)
        val guessedName = URLUtil.guessFileName(abs, null, null)
        val isVideo = lower.endsWith(".mp4") || lower.endsWith(".mov") || lower.endsWith(".webm")
        val destDir = if (isVideo) Environment.DIRECTORY_MOVIES else Environment.DIRECTORY_PICTURES
        val request = DownloadManager.Request(uri)
            .setTitle(guessedName)
            .setDescription("保存到手机")
            .setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(destDir, guessedName)
            .addRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3")
        dm.enqueue(request)
    }

    private fun createTempFileFromUri(context: Context, uri: Uri): File {
        val cr = context.contentResolver
        val inputStream = cr.openInputStream(uri)
            ?: throw IllegalArgumentException("无法从Uri读取: $uri")

        var displayName: String? = null
        cr.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                displayName = cursor.getString(idx)
            }
        }

        val mime = cr.getType(uri)
        val suffix = when {
            !displayName.isNullOrBlank() && displayName!!.contains('.') ->
                "." + displayName!!.substringAfterLast('.')
            mime?.startsWith("video") == true -> ".mp4"
            mime?.startsWith("image") == true -> ".jpg"
            else -> ".bin"
        }

        val tempFile = File.createTempFile("upload_", suffix, context.cacheDir)
        FileOutputStream(tempFile).use { output ->
            inputStream.use { input ->
                val buffer = ByteArray(8 * 1024)
                var bytesRead: Int
                while (true) {
                    bytesRead = input.read(buffer)
                    if (bytesRead == -1) break
                    output.write(buffer, 0, bytesRead)
                }
            }
        }
        return tempFile
    }
}
