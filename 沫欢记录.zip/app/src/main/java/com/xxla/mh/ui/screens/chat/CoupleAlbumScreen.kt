package com.xxla.mh.ui.screens.chat

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import com.xxla.mh.network.CoupleAlbumItem
import com.xxla.mh.ui.components.FullscreenImageDialog
import com.xxla.mh.ui.player.FullscreenPlayerActivity
import com.xxla.mh.util.UrlUtils

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun CoupleAlbumScreen(
    navController: NavController,
    viewModel: CoupleAlbumViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(Unit) { viewModel.loadAlbum() }

    var pendingUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pendingDeleteItem by remember { mutableStateOf<CoupleAlbumItem?>(null) }
    // 底部操作表：长按项后展示
    var sheetItem by remember { mutableStateOf<CoupleAlbumItem?>(null) }
    var previewImageUrl by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        pendingUris = uris
        if (uris.isNotEmpty()) viewModel.uploadImages(uris)
    }
    val pickVideos = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        pendingUris = uris
        if (uris.isNotEmpty()) viewModel.uploadImages(uris)
    }
    var addMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(state.saveMessage) {
        val msg = state.saveMessage
        if (!msg.isNullOrEmpty()) {
            snackbarHostState.showSnackbar(message = msg)
            viewModel.clearSaveMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("共同相册") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    if (!state.selectionMode) {
                        IconButton(onClick = { viewModel.toggleSelectionMode(true) }) {
                            Icon(Icons.Filled.SelectAll, contentDescription = "选择")
                        }
                    } else {
                        // 在选择模式时，顶栏保留上传入口，批量操作放到底部栏
                    }
                    Box {
                        IconButton(onClick = { addMenuExpanded = true }) {
                            Icon(Icons.Filled.Add, contentDescription = "上传")
                        }
                        DropdownMenu(expanded = addMenuExpanded, onDismissRequest = { addMenuExpanded = false }) {
                            DropdownMenuItem(
                                text = { Text("选择图片") },
                                onClick = {
                                    addMenuExpanded = false
                                    pickImages.launch("image/*")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("选择视频") },
                                onClick = {
                                    addMenuExpanded = false
                                    pickVideos.launch("video/*")
                                }
                            )
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (state.selectionMode) {
                BottomAppBar {
                    Text(
                        text = "已选 ${state.selectedIds.size} 项",
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 16.dp)
                    )
                    IconButton(onClick = { viewModel.saveSelectedToDevice() }) {
                        Icon(Icons.Filled.Save, contentDescription = "批量保存")
                    }
                    IconButton(onClick = { viewModel.toggleSelectionMode(false) }) {
                        Icon(Icons.Filled.Close, contentDescription = "退出选择")
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                state.loading -> {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                }
                state.error != null -> {
                    Text(
                        text = state.error ?: "加载失败",
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                else -> {
                    AlbumGrid(
                        items = state.items,
                        onRequestDelete = { item -> pendingDeleteItem = item },
                        selectionMode = state.selectionMode,
                        selectedIds = state.selectedIds,
                        onToggleSelect = { id -> viewModel.toggleSelectItem(id) },
                        onOpenItem = { item ->
                            val abs = UrlUtils.toAbsolute(item.url)
                            val lower = abs.lowercase()
                            val isVideo = item.isVideo ?: (lower.endsWith(".mp4") || lower.contains(".m3u8") || lower.endsWith(".mov") || lower.endsWith(".webm"))
                            if (isVideo) {
                                val intent = Intent(context, FullscreenPlayerActivity::class.java).apply {
                                    putExtra(FullscreenPlayerActivity.EXTRA_URL, abs)
                                }
                                context.startActivity(intent)
                            } else {
                                previewImageUrl = abs
                            }
                        },
                        onLongPressAction = { item -> sheetItem = item }
                    )
                    if (state.uploading) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                        )
                    }
                    if (state.uploadError != null) {
                        AlertDialog(
                            onDismissRequest = { viewModel.clearUploadError() },
                            title = { Text("上传失败") },
                            text = { Text(state.uploadError ?: "上传失败，请重试") },
                            confirmButton = {
                                TextButton(onClick = {
                                    if (pendingUris.isNotEmpty()) {
                                        viewModel.uploadImages(pendingUris)
                                    } else {
                                        addMenuExpanded = true
                                    }
                                    viewModel.clearUploadError()
                                }) { Text("重试") }
                            },
                            dismissButton = {
                                TextButton(onClick = { viewModel.clearUploadError() }) { Text("取消") }
                            }
                        )
                    }
                    if (pendingDeleteItem != null) {
                        AlertDialog(
                            onDismissRequest = { pendingDeleteItem = null },
                            title = { Text("确认删除") },
                            text = { Text("删除后无法恢复，确定删除此图片吗？") },
                            confirmButton = {
                                TextButton(onClick = {
                                    val item = pendingDeleteItem
                                    if (item != null) {
                                        viewModel.deleteImage(item.id)
                                    }
                                    pendingDeleteItem = null
                                }) { Text("删除") }
                            },
                            dismissButton = {
                                TextButton(onClick = { pendingDeleteItem = null }) { Text("取消") }
                            }
                        )
                    }
                    if (sheetItem != null) {
                        ModalBottomSheet(onDismissRequest = { sheetItem = null }) {
                            Column(Modifier.padding(bottom = 24.dp)) {
                                ListItem(
                                    headlineContent = { Text("保存到手机") },
                                    leadingContent = { Icon(Icons.Filled.Save, contentDescription = null) },
                                    modifier = Modifier.clickable {
                                        sheetItem?.let { viewModel.saveToDevice(it) }
                                        sheetItem = null
                                    }
                                )
                                ListItem(
                                    headlineContent = { Text("删除") },
                                    leadingContent = { Icon(Icons.Filled.Delete, contentDescription = null) },
                                    modifier = Modifier.clickable {
                                        sheetItem?.let { pendingDeleteItem = it }
                                        sheetItem = null
                                    }
                                )
                            }
                        }
                    }
                    if (previewImageUrl != null) {
                        FullscreenImageDialog(url = previewImageUrl!!, onDismiss = { previewImageUrl = null })
                    }
                }
            }
        }
    }
}

@Composable
private fun AlbumGrid(
    items: List<CoupleAlbumItem>,
    onRequestDelete: (CoupleAlbumItem) -> Unit,
    selectionMode: Boolean,
    selectedIds: Set<String>,
    onToggleSelect: (String) -> Unit,
    onOpenItem: (CoupleAlbumItem) -> Unit,
    onLongPressAction: (CoupleAlbumItem) -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 120.dp),
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(items) { item ->
            Box(
                modifier = Modifier
                    .aspectRatio(1f)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .combinedClickable(
                        onLongClick = {
                            if (selectionMode) {
                                onToggleSelect(item.id)
                            } else {
                                onLongPressAction(item)
                            }
                        },
                        onClick = {
                            if (selectionMode) {
                                onToggleSelect(item.id)
                            } else {
                                onOpenItem(item)
                            }
                        }
                    )
            ) {
                val cover = UrlUtils.toAbsolute(if (item.coverUrl.isNullOrBlank()) item.url else item.coverUrl)
                AsyncImage(
                    model = cover,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize()
                )
                val lower = UrlUtils.toAbsolute(item.url).lowercase()
                val isVideo = item.isVideo ?: (lower.endsWith(".mp4") || lower.contains(".m3u8") || lower.endsWith(".mov") || lower.endsWith(".webm"))
                if (isVideo) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "播放",
                        tint = Color.White,
                        modifier = Modifier.align(Alignment.Center)
                    )
                    val d = item.durationSec
                    if (d != null && d > 0) {
                        val mm = d / 60
                        val ss = d % 60
                        val text = String.format("%d:%02d", mm, ss)
                        Text(
                            text = text,
                            color = Color.White,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                if (selectionMode) {
                    val checked = selectedIds.contains(item.id)
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { onToggleSelect(item.id) },
                        modifier = Modifier.align(Alignment.TopStart)
                    )
                    if (checked) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.15f))
                        )
                    }
                }
                IconButton(
                    onClick = { onRequestDelete(item) },
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(Icons.Filled.Delete, contentDescription = "删除")
                }
            }
        }
    }
}
