package com.xxla.mh.ui.screens.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.xxla.mh.network.CoupleAlbumItem

data class CoupleAlbumUiState(
    val loading: Boolean = false,
    val items: List<CoupleAlbumItem> = emptyList(),
    val error: String? = null,
    val uploading: Boolean = false,
    val uploadError: String? = null,
    val saveMessage: String? = null,
    val selectionMode: Boolean = false,
    val selectedIds: Set<String> = emptySet()
)

@HiltViewModel
class CoupleAlbumViewModel @Inject constructor(
    private val repo: CoupleAlbumRepository
) : ViewModel() {
    private val _state = MutableStateFlow(CoupleAlbumUiState())
    val state: StateFlow<CoupleAlbumUiState> = _state

    fun loadAlbum() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            runCatching { repo.listAlbum() }
                .onSuccess { list ->
                    val sorted = list.sortedByDescending { it.uploadedAtMs }
                    _state.update { it.copy(loading = false, items = sorted) }
                }
                .onFailure { e -> _state.update { it.copy(loading = false, error = e.message) } }
        }
    }

    fun uploadImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(uploading = true, uploadError = null) }
            runCatching { repo.uploadImages(uris) }
                .onSuccess { uploaded ->
                    // Merge: backend returns full list or only uploaded items; refresh for consistency
                    _state.update {
                        val merged = (uploaded + it.items).distinctBy { it.id }
                        it.copy(
                            items = merged.sortedByDescending { it.uploadedAtMs },
                            uploading = false,
                            uploadError = null
                        )
                    }
                    // Alternatively re-fetch to ensure freshness
                    loadAlbum()
                }
                .onFailure { e -> _state.update { it.copy(uploading = false, uploadError = e.message) } }
        }
    }

    fun deleteImage(filename: String) {
        viewModelScope.launch {
            runCatching { repo.deleteImage(filename) }
                .onSuccess { ok -> if (ok) _state.update { it.copy(items = it.items.filterNot { i -> i.id == filename }) } }
                .onFailure { e -> _state.update { it.copy(error = e.message) } }
        }
    }

    fun clearUploadError() {
        _state.update { it.copy(uploadError = null) }
    }

    fun saveToDevice(item: CoupleAlbumItem) {
        viewModelScope.launch {
            runCatching { repo.saveToDevice(item) }
                .onSuccess { _state.update { it.copy(saveMessage = "已添加到下载，完成后自动保存") } }
                .onFailure { e -> _state.update { it.copy(saveMessage = e.message ?: "保存失败") } }
        }
    }

    fun clearSaveMessage() {
        _state.update { it.copy(saveMessage = null) }
    }

    fun toggleSelectionMode(enabled: Boolean) {
        _state.update { it.copy(selectionMode = enabled, selectedIds = if (enabled) it.selectedIds else emptySet()) }
    }

    fun toggleSelectItem(id: String) {
        _state.update {
            val cur = it.selectedIds
            val next = if (cur.contains(id)) cur - id else cur + id
            it.copy(selectedIds = next)
        }
    }

    fun clearSelection() {
        _state.update { it.copy(selectedIds = emptySet()) }
    }

    fun saveSelectedToDevice() {
        val ids = state.value.selectedIds
        if (ids.isEmpty()) return
        val selected = state.value.items.filter { ids.contains(it.id) }
        viewModelScope.launch {
            var okCount = 0
            var errMsg: String? = null
            for (item in selected) {
                runCatching { repo.saveToDevice(item) }
                    .onSuccess { okCount += 1 }
                    .onFailure { e -> errMsg = e.message ?: "保存失败" }
            }
            _state.update {
                it.copy(
                    saveMessage = if (errMsg != null && okCount == 0) errMsg else "已添加 ${okCount} 个文件到下载，完成后自动保存",
                    selectionMode = false,
                    selectedIds = emptySet()
                )
            }
        }
    }
}
