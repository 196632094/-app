package com.xxla.mh.ui.screens.chat

import com.xxla.mh.network.CoupleApiService
import com.xxla.mh.network.ChatContact
import com.xxla.mh.network.CoupleUpdateRequest
import com.xxla.mh.network.BaseResponse
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CoupleSpaceRepository @Inject constructor(
    private val coupleApi: CoupleApiService
) {
    suspend fun getCoupleInfo(): Pair<Contact?, Long?> {
        val resp = coupleApi.getCoupleInfo()
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val body = resp.body()!!
        if (!body.success) {
            // 返回不成功，视为无情侣信息
            return Pair(null, null)
        }
        val data = body.data ?: return Pair(null, null)
        val partner = data.partner.toUi()
        return Pair(partner, data.startAt)
    }

    suspend fun setCouple(partnerId: String, startedAtMs: Long? = null): Boolean {
        val resp = coupleApi.setCouple(CoupleUpdateRequest(partnerId = partnerId, startedAtMs = startedAtMs))
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.success
    }


    private fun ChatContact.toUi(): Contact = Contact(
        id = id,
        name = (nickname ?: username),
        avatar = avatar,
        isFollowing = isFollowing == true,
        isFollower = isFollower == true,
        isFriend = isFriend == true,
        online = online == true,
        lastOnlineAt = lastOnlineAt
    )
}
