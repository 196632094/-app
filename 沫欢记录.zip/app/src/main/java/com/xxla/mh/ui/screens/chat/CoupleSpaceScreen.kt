package com.xxla.mh.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.util.UrlUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoupleSpaceScreen(
    navController: NavController,
    viewModel: CoupleSpaceViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val missViewModel: MissYouViewModel = hiltViewModel()
    val missState by missViewModel.uiState.collectAsState()
    androidx.compose.runtime.LaunchedEffect(Unit) { missViewModel.loadSent() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("情侣空间") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when {
                uiState.isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                uiState.error != null -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = uiState.error ?: "错误", color = MaterialTheme.colorScheme.error)
                    }
                }
                uiState.partner == null -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Card(modifier = Modifier.padding(16.dp)) {
                            Column(
                                modifier = Modifier.padding(16.dp).widthIn(max = 420.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = "不在情侣名单内", style = MaterialTheme.typography.titleMedium)
                                Text(text = "请输入对方用户ID进行绑定，绑定后可使用完整功能。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                var partnerId by remember { androidx.compose.runtime.mutableStateOf("") }
                                OutlinedTextField(
                                    value = partnerId,
                                    onValueChange = { partnerId = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    placeholder = { Text("对方用户ID，例如：u123456") },
                                    singleLine = true
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Button(onClick = {
                                        val id = partnerId.trim()
                                        if (id.isNotEmpty()) {
                                            viewModel.bindPartner(id)
                                        }
                                    }, enabled = partnerId.isNotBlank() && !uiState.isLoading) {
                                        Text(text = if (uiState.isLoading) "绑定中…" else "绑定情侣")
                                    }
                                    OutlinedButton(onClick = { viewModel.refresh() }, enabled = !uiState.isLoading) {
                                        Text("重新加载")
                                    }
                                }
                                if (uiState.error != null) {
                                    Text(text = uiState.error ?: "错误", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
                else -> {
                    val p = uiState.partner
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = UrlUtils.toAbsolute(p?.avatar),
                                contentDescription = null,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = p?.name ?: "",
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(text = if (p?.isFollowing == true) "已关注" else "未关注") }
                                    )
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(text = if (p?.isFollower == true) "对方关注了你" else "未被关注") }
                                    )
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(text = if (p?.isFriend == true) "互相关注" else "非互关") }
                                    )
                                }
                            }
                            if (p?.online == true) {
                            Text(text = "在线", color = Color(0xFF2E7D32))
                            } else {
                            Text(text = "离线", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        if (uiState.startAt != null) {
                            val start = uiState.startAt!!
                            Text(text = "关系开始于：" + formatDate(start))
                            Spacer(modifier = Modifier.height(4.dp))
                            val daysTogether = ((System.currentTimeMillis() - start) / (1000 * 60 * 60 * 24)).coerceAtLeast(0)
                            Text(text = "已相伴 ${daysTogether} 天", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val daysToNextAnniv = daysToNextAnniversary(start)
                            if (daysToNextAnniv != null) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = "距离下一周年 ${daysToNextAnniv} 天", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = {
                                navController.navigate(
                                    com.xxla.mh.navigation.Screen.ChatConversation.createRoute(
                                        peerId = p!!.id,
                                        name = p.name,
                                        avatar = p.avatar ?: ""
                                    )
                                )
                            }) {
                                Text("与TA聊天")
                            }
                            OutlinedButton(onClick = {
                                navController.navigate(
                                    com.xxla.mh.navigation.Screen.UserProfile.createRoute(p!!.id)
                                )
                            }) {
                                Text("查看主页")
                            }
                            OutlinedButton(onClick = {
                                navController.navigate(com.xxla.mh.navigation.Screen.CoupleAlbum.route)
                            }) {
                                Text("共同相册")
                            }
                        }

                        // 想念传话（发送 + 状态列表）
                        var missContent by remember { androidx.compose.runtime.mutableStateOf("") }
                        var missPreset by remember { androidx.compose.runtime.mutableStateOf("heartbeat") }
                        var showPresetDialog by remember { androidx.compose.runtime.mutableStateOf(false) }
                        Card {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(text = "想念传话", style = MaterialTheme.typography.titleMedium)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedButton(onClick = { showPresetDialog = true }) {
                                        Text("预设")
                                    }
                                    OutlinedTextField(
                                        value = missContent,
                                        onValueChange = { missContent = it },
                                        modifier = Modifier.weight(1f),
                                        placeholder = { Text("输入想对TA说的话…") }
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Button(onClick = {
                                        val text = missContent.trim()
                                        if (text.isNotEmpty()) {
                                            missViewModel.send(text, missPreset)
                                            missContent = ""
                                        }
                                    }, enabled = missContent.isNotBlank() && !missState.sending) {
                                        Text(text = if (missState.sending) "发送中…" else "传达")
                                    }
                                }

                                if (showPresetDialog) {
                                    AlertDialog(
                                        onDismissRequest = { showPresetDialog = false },
                                        title = { Text("选择动画预设") },
                                        text = {
                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                val presets = listOf("heartbeat" to "心跳·经典", "aurora" to "极光·环", "fireworks" to "烟花·心", "ribbon" to "缎带·飘", "plane" to "纸飞机·信")
                                                presets.forEach { (key, label) ->
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        RadioButton(selected = missPreset == key, onClick = { missPreset = key })
                                                        Text(label)
                                                    }
                                                }
                                            }
                                        },
                                        confirmButton = {
                                            TextButton(onClick = { showPresetDialog = false }) { Text("确定") }
                                        },
                                        dismissButton = {
                                            TextButton(onClick = { showPresetDialog = false }) { Text("取消") }
                                        }
                                    )
                                }

                                Divider()
                                Text(text = "我发出的记录", style = MaterialTheme.typography.titleSmall)
                                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                    items(missState.sentList) { item ->
                                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                            Text(text = item.content, style = MaterialTheme.typography.bodyMedium)
                                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(text = "发送：" + formatIso(item.sentAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(
                                                    text = if (item.received) "已收到：" + (item.receivedAt?.let { formatIso(it) } ?: "-") else "未收到",
                                                    style = MaterialTheme.typography.bodySmall,
                                color = if (item.received) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatDate(ts: Long): String {
    return try {
        val date = java.util.Date(ts)
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
        sdf.format(date)
    } catch (_: Exception) {
        ts.toString()
    }
}

private fun daysToNextAnniversary(startTs: Long): Int? {
    return try {
        val zone = java.time.ZoneId.systemDefault()
        val startInstant = java.time.Instant.ofEpochMilli(startTs)
        val startDate = java.time.LocalDateTime.ofInstant(startInstant, zone).toLocalDate()
        val today = java.time.LocalDate.now(zone)
    val years = java.time.Period.between(startDate, today).years
    val nextYears = years + 1
    val nextAnniv = startDate.plusYears(nextYears.toLong())
    val days = java.time.temporal.ChronoUnit.DAYS.between(today, nextAnniv).toInt()
    days.coerceAtLeast(0)
    } catch (_: Exception) {
        null
    }
}

private fun formatIso(iso: String): String {
    return try {
        val instant = java.time.Instant.parse(iso)
        val dt = java.time.ZonedDateTime.ofInstant(instant, java.time.ZoneId.systemDefault())
        java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").format(dt)
    } catch (_: Exception) {
        iso
    }
}
