package com.xxla.mh.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CoupleSpaceViewModel @Inject constructor(
    private val repository: CoupleSpaceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CoupleSpaceUiState())
    val uiState: StateFlow<CoupleSpaceUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val (partner, startAt) = repository.getCoupleInfo()
                _uiState.update { it.copy(isLoading = false, partner = partner, startAt = startAt) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "加载失败") }
            }
        }
    }

    fun bindPartner(partnerId: String, startedAtMs: Long? = null) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val ok = repository.setCouple(partnerId, startedAtMs)
                if (ok) {
                    refresh()
                } else {
                    _uiState.update { it.copy(isLoading = false, error = "绑定失败") }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "绑定失败") }
            }
        }
    }

}

data class CoupleSpaceUiState(
    val isLoading: Boolean = false,
    val partner: Contact? = null,
    val startAt: Long? = null,
    val error: String? = null
)
