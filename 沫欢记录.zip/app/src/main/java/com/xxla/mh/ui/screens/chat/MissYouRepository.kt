package com.xxla.mh.ui.screens.chat

import com.xxla.mh.network.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MissYouRepository @Inject constructor(
    private val api: MissYouApiService
) {
    suspend fun send(content: String, preset: String?): MissYouItem {
        val resp = api.sendMissYou(MissYouSendRequest(content, preset))
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val body = resp.body()!!
        if (!body.success || body.data == null) {
            throw Exception(body.message)
        }
        return body.data
    }

    suspend fun getPending(): MissYouPendingItem? {
        val resp = api.getPending()
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val body = resp.body()!!
        return if (body.success) body.data else null
    }

    suspend fun acknowledge(id: String): MissYouItem {
        val resp = api.acknowledge(MissYouAckRequest(id))
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val body = resp.body()!!
        if (!body.success || body.data == null) {
            throw Exception(body.message)
        }
        return body.data
    }

    suspend fun getSentPage(limit: Int? = null, before: Long? = null, after: Long? = null): MissYouSentListData {
        val resp = api.getSent(limit, before, after)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val body = resp.body()!!
        if (!body.success) {
            throw Exception(body.message)
        }
        return body.data ?: MissYouSentListData(emptyList(), false, null)
    }

    // 保持兼容：仅获取列表项
    suspend fun getSent(): List<MissYouItem> {
        val data = getSentPage()
        return data.items
    }

    suspend fun delete(id: String) {
        val resp = api.deleteSent(id)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        val body = resp.body()!!
        if (!body.success) {
            throw Exception(body.message)
        }
    }
}
