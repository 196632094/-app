package com.xxla.mh.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MissYouViewModel @Inject constructor(
    private val repository: MissYouRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(MissYouUiState())
    val uiState: StateFlow<MissYouUiState> = _uiState

    fun loadPendingOnce() {
        // 避免重复加载
        if (_uiState.value.hasLoaded) return
        _uiState.update { it.copy(hasLoaded = true, loading = true, error = null) }
        viewModelScope.launch {
            try {
                val pending = repository.getPending()
                _uiState.update { it.copy(loading = false, pending = pending, showOverlay = pending != null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(loading = false, error = e.message) }
            }
        }
    }

    // 仅本地关闭覆盖层（例如 WebView 页面已自行完成网络确认）
    fun dismissOverlay() {
        _uiState.update { it.copy(showOverlay = false, pending = null, acking = false) }
    }

    fun acknowledge() {
        val p = _uiState.value.pending ?: return
        _uiState.update { it.copy(acking = true, error = null) }
        viewModelScope.launch {
            try {
                repository.acknowledge(p.id)
                _uiState.update { it.copy(acking = false, showOverlay = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(acking = false, error = e.message) }
            }
        }
    }

    fun send(content: String, preset: String?) {
        _uiState.update { it.copy(sending = true, error = null) }
        viewModelScope.launch {
            try {
                repository.send(content, preset)
                // 重新加载发送记录（使用当前分页大小）
                val pageSize = _uiState.value.sentPageSize
                val page = repository.getSentPage(limit = pageSize, before = null, after = null)
                _uiState.update { it.copy(sending = false, sentList = page.items, sentHasMore = page.hasMore == true, sentNextBefore = page.nextBefore) }
            } catch (e: Exception) {
                _uiState.update { it.copy(sending = false, error = e.message) }
            }
        }
    }

    fun loadSent(limit: Int = 20) {
        viewModelScope.launch {
            try {
                val page = repository.getSentPage(limit = limit, before = null, after = null)
                _uiState.update { it.copy(sentList = page.items, sentHasMore = page.hasMore == true, sentNextBefore = page.nextBefore, sentPageSize = limit) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    fun loadSentMore() {
        val state = _uiState.value
        val pageSize = state.sentPageSize
        val nextBefore = state.sentNextBefore
        if (!state.sentHasMore || nextBefore == null) return
        viewModelScope.launch {
            try {
                val page = repository.getSentPage(limit = pageSize, before = nextBefore, after = null)
                _uiState.update { prev ->
                    prev.copy(
                        sentList = prev.sentList + page.items,
                        sentHasMore = page.hasMore == true,
                        sentNextBefore = page.nextBefore
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message) }
            }
        }
    }

    fun deleteSent(id: String) {
        _uiState.update { it.copy(sending = true, error = null) }
        viewModelScope.launch {
            try {
                repository.delete(id)
                val pageSize = _uiState.value.sentPageSize
                val page = repository.getSentPage(limit = pageSize, before = null, after = null)
                _uiState.update { it.copy(sending = false, sentList = page.items, sentHasMore = page.hasMore == true, sentNextBefore = page.nextBefore) }
            } catch (e: Exception) {
                _uiState.update { it.copy(sending = false, error = e.message) }
            }
        }
    }
}

data class MissYouUiState(
    val loading: Boolean = false,
    val sending: Boolean = false,
    val acking: Boolean = false,
    val error: String? = null,
    val hasLoaded: Boolean = false,
    val showOverlay: Boolean = false,
    val pending: com.xxla.mh.network.MissYouPendingItem? = null,
    val sentList: List<com.xxla.mh.network.MissYouItem> = emptyList(),
    val sentHasMore: Boolean = false,
    val sentNextBefore: Long? = null,
    val sentPageSize: Int = 20
)
