package com.xxla.mh.ui.screens.comment

import kotlinx.coroutines.delay
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommentRepository @Inject constructor() {
    
    // 模拟评论数据
    private val comments = mutableMapOf<String, MutableList<Comment>>()
    
    // 初始化一些模拟数据
    init {
        // 视频1的评论
        val video1Comments = mutableListOf(
            Comment(
                id = "c1",
                videoId = "1",
                userId = "u1",
                username = "用户A",
                userAvatar = "https://picsum.photos/100/100?random=1",
                content = "这个视频太棒了，学到很多！",
                timestamp = System.currentTimeMillis() - 3600000, // 1小时前
                likeCount = 15,
                isLiked = false,
                replies = listOf(
                    Reply(
                        id = "r1",
                        commentId = "c1",
                        userId = "u2",
                        username = "用户B",
                        userAvatar = "https://picsum.photos/100/100?random=2",
                        content = "我也觉得很有用！",
                        timestamp = System.currentTimeMillis() - 1800000 // 30分钟前
                    )
                )
            ),
            Comment(
                id = "c2",
                videoId = "1",
                userId = "u3",
                username = "用户C",
                userAvatar = "https://picsum.photos/100/100?random=3",
                content = "希望能出更多这样的教程",
                timestamp = System.currentTimeMillis() - 7200000, // 2小时前
                likeCount = 8,
                isLiked = true
            )
        )
        comments["1"] = video1Comments
        
        // 视频2的评论
        val video2Comments = mutableListOf(
            Comment(
                id = "c3",
                videoId = "2",
                userId = "u4",
                username = "用户D",
                userAvatar = "https://picsum.photos/100/100?random=4",
                content = "这个穿搭真的很适合夏天！",
                timestamp = System.currentTimeMillis() - 10800000, // 3小时前
                likeCount = 25,
                isLiked = false
            ),
            Comment(
                id = "c4",
                videoId = "2",
                userId = "u5",
                username = "用户E",
                userAvatar = "https://picsum.photos/100/100?random=5",
                content = "请问这件衣服在哪里可以买到？",
                timestamp = System.currentTimeMillis() - 14400000, // 4小时前
                likeCount = 3,
                isLiked = false,
                replies = listOf(
                    Reply(
                        id = "r2",
                        commentId = "c4",
                        userId = "u2",
                        username = "博主",
                        userAvatar = "https://picsum.photos/100/100?random=6",
                        content = "我在视频描述里放了链接哦~",
                        timestamp = System.currentTimeMillis() - 10800000 // 3小时前
                    )
                )
            )
        )
        comments["2"] = video2Comments
    }
    
    suspend fun getComments(videoId: String): List<Comment> {
        // 模拟网络延迟
        delay(800)
        
        // 返回指定视频的评论，如果没有则返回空列表
        return comments[videoId] ?: emptyList()
    }
    
    suspend fun postComment(videoId: String, content: String): Comment {
        // 模拟网络延迟
        delay(500)
        
        // 创建新评论
        val newComment = Comment(
            id = UUID.randomUUID().toString(),
            videoId = videoId,
            userId = "current_user", // 在实际应用中，这应该是当前登录用户的ID
            username = "当前用户", // 在实际应用中，这应该是当前登录用户的用户名
            userAvatar = "https://picsum.photos/100/100?random=10", // 在实际应用中，这应该是当前登录用户的头像
            content = content,
            timestamp = System.currentTimeMillis(),
            likeCount = 0,
            isLiked = false
        )
        
        // 添加到评论列表
        if (!comments.containsKey(videoId)) {
            comments[videoId] = mutableListOf()
        }
        comments[videoId]?.add(0, newComment)
        
        return newComment
    }
    
    suspend fun toggleLikeComment(commentId: String): Comment {
        // 模拟网络延迟
        delay(300)
        
        // 查找评论并更新点赞状态
        for (videoComments in comments.values) {
            for (i in videoComments.indices) {
                if (videoComments[i].id == commentId) {
                    val comment = videoComments[i]
                    val updatedComment = if (comment.isLiked) {
                        comment.copy(isLiked = false, likeCount = comment.likeCount - 1)
                    } else {
                        comment.copy(isLiked = true, likeCount = comment.likeCount + 1)
                    }
                    videoComments[i] = updatedComment
                    return updatedComment
                }
            }
        }
        
        // 如果找不到评论，抛出异常
        throw Exception("评论不存在")
    }
    
    suspend fun replyToComment(commentId: String, content: String): Reply {
        // 模拟网络延迟
        delay(500)
        
        // 创建新回复
        val newReply = Reply(
            id = UUID.randomUUID().toString(),
            commentId = commentId,
            userId = "current_user", // 在实际应用中，这应该是当前登录用户的ID
            username = "当前用户", // 在实际应用中，这应该是当前登录用户的用户名
            userAvatar = "https://picsum.photos/100/100?random=10", // 在实际应用中，这应该是当前登录用户的头像
            content = content,
            timestamp = System.currentTimeMillis()
        )
        
        // 查找评论并添加回复
        for (videoComments in comments.values) {
            for (i in videoComments.indices) {
                if (videoComments[i].id == commentId) {
                    val comment = videoComments[i]
                    val updatedReplies = comment.replies + newReply
                    videoComments[i] = comment.copy(replies = updatedReplies)
                    return newReply
                }
            }
        }
        
        // 如果找不到评论，抛出异常
        throw Exception("评论不存在")
    }
}