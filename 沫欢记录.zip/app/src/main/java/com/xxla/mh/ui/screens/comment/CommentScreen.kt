package com.xxla.mh.ui.screens.comment

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.TagFaces
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.util.UrlUtils
import com.xxla.mh.ui.components.ErrorView
import com.xxla.mh.ui.components.LoadingView
import com.xxla.mh.ui.components.UserAvatar
import com.xxla.mh.ui.theme.spacing
import com.xxla.mh.ui.theme.ResponsiveUtils
import com.xxla.mh.ui.screens.auth.AuthViewModel
import androidx.compose.material3.ModalBottomSheet
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalComposeUiApi::class)
@Composable
fun CommentScreen(
    navController: NavController,
    videoId: String,
    viewModel: CommentViewModel = hiltViewModel()
) {
    val authViewModel: AuthViewModel = hiltViewModel()
    val authUiState by authViewModel.uiState.collectAsState()
    val currentUserId = authUiState.user?.id
    val commentState by viewModel.commentState.collectAsState()
    val commentText by viewModel.commentText.collectAsState()
    val isPosting by viewModel.isPosting.collectAsState()
    val replyingToAlias by viewModel.replyingToAlias.collectAsState()
    val showStickerPicker by viewModel.showStickerPicker.collectAsState()
    val loadingStickers by viewModel.loadingStickers.collectAsState()
    val stickers by viewModel.stickers.collectAsState()
    val keyboardController = LocalSoftwareKeyboardController.current
    val snackbarHostState = remember { SnackbarHostState() }
    val horizontalPadding = ResponsiveUtils.getHorizontalPadding()
    
    // 加载评论
    LaunchedEffect(videoId) {
        viewModel.loadComments(videoId)
    }

    // 收集一次性事件，例如评论成功提示
    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is CommentUiEvent.ShowMessage -> snackbarHostState.showSnackbar(event.message)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("评论") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            Surface(
                tonalElevation = 3.dp,
                shadowElevation = 3.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = horizontalPadding, vertical = 8.dp)
                ) {
                    if (!replyingToAlias.isNullOrBlank()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Reply,
                                contentDescription = "回复",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "回复 ${replyingToAlias}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            TextButton(onClick = { viewModel.clearReply() }) {
                                Text("取消")
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledIconButton(
                            onClick = { viewModel.toggleStickerPicker() },
                            enabled = !isPosting
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.TagFaces,
                                contentDescription = "真寻表情"
                            )
                        }
                        OutlinedTextField(
                            value = commentText,
                            onValueChange = { viewModel.updateCommentText(it) },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("添加评论...") },
                            maxLines = 3,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (!isPosting) {
                                        viewModel.postComment(videoId)
                                        keyboardController?.hide()
                                    }
                                }
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (!isPosting) {
                                    viewModel.postComment(videoId)
                                    keyboardController?.hide()
                                }
                            },
                            enabled = commentText.isNotBlank() && !isPosting
                        ) {
                            if (isPosting) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("发送中")
                            } else {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "发送")
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        if (showStickerPicker) {
            ModalBottomSheet(onDismissRequest = { viewModel.toggleStickerPicker() }) {
                Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(text = "真寻表情", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (loadingStickers) {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(stickers) { url ->
                                Surface(shape = MaterialTheme.shapes.small, tonalElevation = 1.dp) {
                                    Box(modifier = Modifier.size(72.dp).combinedClickable(onClick = { viewModel.sendSticker(videoId, url) }, onLongClick = {})) {
                                        AsyncImage(
                                            model = UrlUtils.toAbsolute(url),
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        when (val state = commentState) {
            is CommentState.Loading -> {
                LoadingView()
            }
            is CommentState.Success -> {
                val comments = state.comments
                if (comments.isEmpty()) {
                    EmptyCommentView()
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .padding(horizontal = horizontalPadding),
                        contentPadding = PaddingValues(vertical = MaterialTheme.spacing.medium),
                        verticalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.medium)
                    ) {
                        items(comments) { comment ->
                            CommentItem(
                                comment = comment,
                                currentUserId = currentUserId,
                                onLikeClick = { viewModel.toggleLikeComment(videoId, it) },
                                onReplyClick = { id, alias -> viewModel.startReplyTo(id, alias) },
                                onDeleteComment = { viewModel.deleteComment(it) },
                                onDeleteReply = { viewModel.deleteReply(it) }
                            )
                        }
                    }
                }
            }
            is CommentState.Error -> {
                ErrorView(
                    message = state.message,
                    onRetry = { viewModel.loadComments(videoId) }
                )
            }
        }
    }
}

@Composable
fun CommentItem(
    comment: Comment,
    currentUserId: String?,
    onLikeClick: (String) -> Unit,
    onReplyClick: (String, String) -> Unit,
    onDeleteComment: (String) -> Unit,
    onDeleteReply: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        // 用户信息和评论内容
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            UserAvatar(
                avatarUrl = comment.userAvatar,
                size = 40.dp
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            val clipboard = LocalClipboardManager.current
            var menuExpanded by remember { mutableStateOf(false) }
            val isMine = currentUserId != null && currentUserId == comment.userId

            Column(
                modifier = Modifier
                    .weight(1f)
                    .combinedClickable(
                        onClick = { onReplyClick(comment.id, comment.username) },
                        onLongClick = { menuExpanded = true }
                    )
            ) {
                Text(
                    text = comment.username,
                    style = MaterialTheme.typography.titleSmall
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                val isImage = remember(comment.content) {
                    val url = comment.content
                    val lower = url.lowercase(Locale.getDefault())
                    lower.startsWith("http") && (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".gif"))
                }
                if (isImage) {
                    AsyncImage(
                        model = UrlUtils.toAbsolute(comment.content),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp)
                    )
                } else {
                    Text(
                        text = comment.content,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("复制") },
                        onClick = {
                            clipboard.setText(AnnotatedString(comment.content))
                            menuExpanded = false
                        }
                    )
                    if (isMine) {
                        DropdownMenuItem(
                            text = { Text("删除") },
                            onClick = {
                                onDeleteComment(comment.id)
                                menuExpanded = false
                            }
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // 评论时间和操作按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = comment.formattedTime,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    // 回复按钮
                    IconButton(
                        onClick = { onReplyClick(comment.id, comment.username) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Reply,
                            contentDescription = "回复",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    
                    // 点赞按钮
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { onLikeClick(comment.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "点赞",
                                tint = if (comment.isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        if (comment.likeCount > 0) {
                            Text(
                                text = comment.likeCount.toString(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        
        // 如果有回复，显示回复列表
        if (comment.replies.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 52.dp, top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                comment.replies.forEach { reply ->
                    ReplyItem(
                        reply = reply,
                        currentUserId = currentUserId,
                        onReplyClick = onReplyClick,
                        onDeleteReply = onDeleteReply
                    )
                }
            }
        }
    }
}

@Composable
fun ReplyItem(
    reply: Reply,
    currentUserId: String?,
    onReplyClick: (String, String) -> Unit,
    onDeleteReply: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        UserAvatar(
            avatarUrl = reply.userAvatar,
            size = 32.dp
        )
        
        Spacer(modifier = Modifier.width(8.dp))
        
        val clipboard = LocalClipboardManager.current
        var menuExpanded by remember { mutableStateOf(false) }
        val isMine = currentUserId != null && currentUserId == reply.userId

        Column(
            modifier = Modifier
                .weight(1f)
                .combinedClickable(
                    onClick = { onReplyClick(reply.id, reply.username) },
                    onLongClick = { menuExpanded = true }
                )
        ) {
            Text(
                text = reply.username,
                style = MaterialTheme.typography.titleSmall
            )
            
            Spacer(modifier = Modifier.height(2.dp))
            
            val isImage = remember(reply.content) {
                val url = reply.content
                val lower = url.lowercase(Locale.getDefault())
                lower.startsWith("http") && (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".gif"))
            }
            if (isImage) {
                AsyncImage(
                    model = UrlUtils.toAbsolute(reply.content),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                )
            } else {
                Text(
                    text = reply.content,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("复制") },
                    onClick = {
                        clipboard.setText(AnnotatedString(reply.content))
                        menuExpanded = false
                    }
                )
                if (isMine) {
                    DropdownMenuItem(
                        text = { Text("删除") },
                        onClick = {
                            onDeleteReply(reply.id)
                            menuExpanded = false
                        }
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = reply.formattedTime,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(
                    onClick = { onReplyClick(reply.id, reply.username) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Reply,
                        contentDescription = "回复",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyCommentView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Comment,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "暂无评论，快来发表第一条评论吧",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
