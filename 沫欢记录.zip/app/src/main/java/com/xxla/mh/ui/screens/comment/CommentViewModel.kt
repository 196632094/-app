package com.xxla.mh.ui.screens.comment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import com.xxla.mh.data.VideoRepository
import com.xxla.mh.data.StickerRepository
import com.xxla.mh.network.Comment as NetComment

@HiltViewModel
class CommentViewModel @Inject constructor(
    private val videoRepository: VideoRepository,
    private val stickerRepository: StickerRepository
) : ViewModel() {

    private val _commentState = MutableStateFlow<CommentState>(CommentState.Loading)
    val commentState: StateFlow<CommentState> = _commentState

    private val _commentText = MutableStateFlow("")
    val commentText: StateFlow<String> = _commentText

    // 发送评论中的状态，避免用户重复点击造成多次提交
    private val _isPosting = MutableStateFlow(false)
    val isPosting: StateFlow<Boolean> = _isPosting

    // 当前回复的父评论ID（null 表示发表顶层评论）
    private val _replyToCommentId = MutableStateFlow<String?>(null)
    val replyToCommentId: StateFlow<String?> = _replyToCommentId

    // 正在回复的别名（用于 UI 提示与 @前缀兼容旧数据）
    private val _replyingToAlias = MutableStateFlow<String?>(null)
    val replyingToAlias: StateFlow<String?> = _replyingToAlias

    // 当前视频ID（用于删除/点赞等需要videoId的操作）
    private var currentVideoId: String? = null

    // 贴纸选择相关状态
    private val _showStickerPicker = MutableStateFlow(false)
    val showStickerPicker: StateFlow<Boolean> = _showStickerPicker.asStateFlow()

    private val _loadingStickers = MutableStateFlow(false)
    val loadingStickers: StateFlow<Boolean> = _loadingStickers.asStateFlow()

    private val _stickers = MutableStateFlow<List<String>>(emptyList())
    val stickers: StateFlow<List<String>> = _stickers.asStateFlow()

    // 一次性事件（如成功提示）
    private val _events = MutableSharedFlow<CommentUiEvent>()
    val events: SharedFlow<CommentUiEvent> = _events.asSharedFlow()

    fun loadComments(videoId: String) {
        currentVideoId = videoId
        viewModelScope.launch {
            _commentState.value = CommentState.Loading
            try {
                val resp = videoRepository.getVideoComments(videoId, page = 1, size = 50)
                if (resp.isSuccessful) {
                    val body = resp.body()
                    val list = body?.data?.comments ?: emptyList()
                    _commentState.value = CommentState.Success(groupCommentsToUi(videoId, list))
                } else {
                    _commentState.value = CommentState.Error("加载评论失败: ${resp.code()}")
                }
            } catch (e: Exception) {
                _commentState.value = CommentState.Error("加载评论失败: ${e.message}")
            }
        }
    }

    fun updateCommentText(text: String) {
        _commentText.value = text
    }

    fun postComment(videoId: String) {
        val text = _commentText.value.trim()
        // 空文本或正在发送则直接返回，防止多次触发
        if (text.isEmpty() || _isPosting.value) return

        _isPosting.value = true
        viewModelScope.launch {
            try {
                val resp = videoRepository.postComment(videoId, text, parentId = _replyToCommentId.value)
                val body = resp.body()
                if (resp.isSuccessful && (body?.success == true)) {
                    val net = body.data
                    if (net != null) {
                        val currentState = _commentState.value
                        if (currentState is CommentState.Success) {
                            if (net.parentId != null) {
                                // 新增的是回复：插入到对应父评论的 replies 列表开头
                                val replyUi = net.toReplyUi()
                                val updated = currentState.comments.map { c ->
                                    if (c.id == net.parentId) c.copy(replies = listOf(replyUi) + c.replies) else c
                                }
                                _commentState.value = CommentState.Success(updated)
                            } else {
                                // 新增顶层评论：插入列表顶部
                                val newComment = net.toUi(videoId)
                                _commentState.value = CommentState.Success(listOf(newComment) + currentState.comments)
                            }
                        } else {
                            // 首次加载或错误后成功发送，直接重组为一个元素
                            if (net.parentId != null) {
                                // 如果是回复但当前没有父评论上下文，回退到重新加载
                                loadComments(videoId)
                            } else {
                                _commentState.value = CommentState.Success(listOf(net.toUi(videoId)))
                            }
                        }
                    }
                    _commentText.value = ""
                    clearReply()
                    // 刷新评论区并提示成功
                    loadComments(videoId)
                    _events.emit(CommentUiEvent.ShowMessage("评论成功"))
                } else {
                    // 保留原状态，后续可在UI显示错误提示
                }
            } catch (e: Exception) {
                // 保留原状态，后续可在UI显示错误提示
            } finally {
                _isPosting.value = false
            }
        }
    }

    fun toggleStickerPicker() {
        val wasOpen = _showStickerPicker.value
        _showStickerPicker.value = !wasOpen
        if (!wasOpen && _stickers.value.isEmpty()) {
            loadStickers()
        }
    }

    fun loadStickers() {
        viewModelScope.launch {
            _loadingStickers.value = true
            try {
                val list = stickerRepository.getStickers()
                _stickers.value = list
            } catch (_: Exception) {
                // 贴纸加载失败不影响评论功能
            } finally {
                _loadingStickers.value = false
            }
        }
    }

    fun sendSticker(videoId: String, url: String) {
        if (_isPosting.value) return
        _isPosting.value = true
        viewModelScope.launch {
            try {
                val resp = videoRepository.postComment(videoId, url, parentId = _replyToCommentId.value)
                val body = resp.body()
                if (resp.isSuccessful && (body?.success == true)) {
                    val net = body.data
                    if (net != null) {
                        val currentState = _commentState.value
                        if (currentState is CommentState.Success) {
                            if (net.parentId != null) {
                                val replyUi = net.toReplyUi()
                                val updated = currentState.comments.map { c ->
                                    if (c.id == net.parentId) c.copy(replies = listOf(replyUi) + c.replies) else c
                                }
                                _commentState.value = CommentState.Success(updated)
                            } else {
                                val newComment = net.toUi(videoId)
                                _commentState.value = CommentState.Success(listOf(newComment) + currentState.comments)
                            }
                        } else {
                            if (net.parentId != null) {
                                loadComments(videoId)
                            } else {
                                _commentState.value = CommentState.Success(listOf(net.toUi(videoId)))
                            }
                        }
                    }
                    clearReply()
                    _showStickerPicker.value = false
                }
            } catch (_: Exception) {
                // 保留原状态，后续可在UI显示错误提示
            } finally {
                _isPosting.value = false
            }
        }
    }

    fun startReplyTo(commentId: String, alias: String?) {
        _replyToCommentId.value = commentId
        _replyingToAlias.value = alias
        val current = _commentText.value
        if (current.isBlank() && !alias.isNullOrBlank()) {
            _commentText.value = "@${alias} "
        }
    }

    fun clearReply() {
        val alias = _replyingToAlias.value
        _replyToCommentId.value = null
        _replyingToAlias.value = null
        if (!alias.isNullOrBlank()) {
            val prefix = "@${alias} "
            val cur = _commentText.value
            if (cur.startsWith(prefix)) {
                _commentText.value = cur.removePrefix(prefix)
            }
        }
    }

    fun toggleLikeComment(videoId: String, commentId: String) {
        val currentState = _commentState.value
        if (currentState is CommentState.Success) {
            val target = currentState.comments.find { it.id == commentId }
            val currentlyLiked = target?.isLiked == true

            // 先进行乐观更新
            val updatedComments = currentState.comments.map { c ->
                if (c.id == commentId) {
                    if (currentlyLiked) c.copy(isLiked = false, likeCount = (c.likeCount - 1).coerceAtLeast(0))
                    else c.copy(isLiked = true, likeCount = c.likeCount + 1)
                } else c
            }
            _commentState.value = CommentState.Success(updatedComments)

            // 调用后端持久化
            viewModelScope.launch {
                try {
                    val resp = if (currentlyLiked) {
                        videoRepository.unlikeComment(videoId, commentId)
                    } else {
                        videoRepository.likeComment(videoId, commentId)
                    }
                    if (!resp.isSuccessful) {
                        // 回滚本地状态
                        val rollbackComments = updatedComments.map { c ->
                            if (c.id == commentId) {
                                if (currentlyLiked) c.copy(isLiked = true, likeCount = c.likeCount + 1)
                                else c.copy(isLiked = false, likeCount = (c.likeCount - 1).coerceAtLeast(0))
                            } else c
                        }
                        _commentState.value = CommentState.Success(rollbackComments)
                    }
                } catch (e: Exception) {
                    // 回滚本地状态
                    val rollbackComments = updatedComments.map { c ->
                        if (c.id == commentId) {
                            if (currentlyLiked) c.copy(isLiked = true, likeCount = c.likeCount + 1)
                            else c.copy(isLiked = false, likeCount = (c.likeCount - 1).coerceAtLeast(0))
                        } else c
                    }
                    _commentState.value = CommentState.Success(rollbackComments)
                }
            }
        }
    }

    fun deleteComment(commentId: String) {
        val videoId = currentVideoId ?: return
        viewModelScope.launch {
            try {
                val ok = videoRepository.deleteComment(videoId, commentId)
                if (ok) {
                    val currentState = _commentState.value
                    if (currentState is CommentState.Success) {
                        val updated = currentState.comments.filter { it.id != commentId }
                        _commentState.value = CommentState.Success(updated)
                    }
                } else {
                    // 可扩展：错误提示
                }
            } catch (_: Exception) {
                // 可扩展：错误提示
            }
        }
    }

    fun deleteReply(replyId: String) {
        val videoId = currentVideoId ?: return
        viewModelScope.launch {
            try {
                val ok = videoRepository.deleteComment(videoId, replyId)
                if (ok) {
                    val currentState = _commentState.value
                    if (currentState is CommentState.Success) {
                        val updated = currentState.comments.map { c ->
                            c.copy(replies = c.replies.filter { r -> r.id != replyId })
                        }
                        _commentState.value = CommentState.Success(updated)
                    }
                } else {
                    // 可扩展：错误提示
                }
            } catch (_: Exception) {
                // 可扩展：错误提示
            }
        }
    }

    private fun NetComment.toUi(videoId: String): Comment {
        val millis = parseIsoMillis(createdAt)
        val displayName = author.nickname ?: author.username
        return Comment(
            id = id,
            videoId = videoId,
            userId = author.id,
            username = displayName,
            userAvatar = author.avatar ?: "",
            content = content,
            timestamp = millis,
            likeCount = likeCount,
            isLiked = isLiked,
            replies = emptyList()
        )
    }

    private fun NetComment.toReplyUi(): Reply {
        val millis = parseIsoMillis(createdAt)
        val displayName = author.nickname ?: author.username
        return Reply(
            id = id,
            commentId = parentId ?: "",
            userId = author.id,
            username = displayName,
            userAvatar = author.avatar ?: "",
            content = content,
            timestamp = millis
        )
    }

    private fun groupCommentsToUi(videoId: String, list: List<NetComment>): List<Comment> {
        // 首先根据 parentId 分出回复
        val repliesMap = mutableMapOf<String, MutableList<Reply>>()
        val parentCandidates = mutableListOf<NetComment>()
        list.forEach { nc ->
            if (nc.parentId != null) {
                repliesMap.getOrPut(nc.parentId) { mutableListOf() }.add(nc.toReplyUi())
            } else {
                parentCandidates.add(nc)
            }
        }

        // 兼容旧数据：以 @alias 前缀推断父评论（仅当 parentId 为空时）
        val aliasToParentId = mutableMapOf<String, String>()
        parentCandidates.forEach { nc ->
            val alias = nc.author.nickname ?: nc.author.username
            aliasToParentId[alias] = nc.id
        }
        val excludeAsParent = mutableSetOf<String>()
        parentCandidates.forEach { nc ->
            val content = (nc.content ?: "")
            val m = Regex("^@(\\S+)").find(content)
            val alias = m?.groupValues?.getOrNull(1)
            val targetId = alias?.let { aliasToParentId[it] }
            if (targetId != null && targetId != nc.id) {
                // 将其视为回复
                val millis = parseIsoMillis(nc.createdAt)
                val displayName = nc.author.nickname ?: nc.author.username
                val reply = Reply(
                    id = nc.id,
                    commentId = targetId,
                    userId = nc.author.id,
                    username = displayName,
                    userAvatar = nc.author.avatar ?: "",
                    content = nc.content,
                    timestamp = millis
                )
                repliesMap.getOrPut(targetId) { mutableListOf() }.add(reply)
                excludeAsParent.add(nc.id)
            }
        }

        // 构建最终的顶层评论列表，并挂接对应的回复
        val parents = parentCandidates
            .filter { it.id !in excludeAsParent }
            .map { nc ->
                val c = nc.toUi(videoId)
                val replies = repliesMap[c.id]?.sortedBy { it.timestamp } ?: emptyList()
                c.copy(replies = replies)
            }
            .sortedByDescending { it.timestamp }

        return parents
    }

    private fun parseIsoMillis(iso: String): Long {
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
            fmt.timeZone = TimeZone.getTimeZone("UTC")
            fmt.parse(iso)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }
}

// UI 事件定义
sealed class CommentUiEvent {
    data class ShowMessage(val message: String) : CommentUiEvent()
}

sealed class CommentState {
    object Loading : CommentState()
    data class Success(val comments: List<Comment>) : CommentState()
    data class Error(val message: String) : CommentState()
}

data class Comment(
    val id: String,
    val videoId: String,
    val userId: String,
    val username: String,
    val userAvatar: String,
    val content: String,
    val timestamp: Long,
    val likeCount: Int,
    val isLiked: Boolean,
    val replies: List<Reply> = emptyList()
) {
    val formattedTime: String
        get() {
            val date = Date(timestamp)
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            return format.format(date)
        }
}

data class Reply(
    val id: String,
    val commentId: String,
    val userId: String,
    val username: String,
    val userAvatar: String,
    val content: String,
    val timestamp: Long
) {
    val formattedTime: String
        get() {
            val date = Date(timestamp)
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            return format.format(date)
        }
}
