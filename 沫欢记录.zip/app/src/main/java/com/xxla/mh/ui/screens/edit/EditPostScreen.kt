package com.xxla.mh.ui.screens.edit

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditPostScreen(
    navController: NavController,
    postId: String,
    viewModel: EditPostViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedImages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var selectedAudio by remember { mutableStateOf<Uri?>(null) }
    var selectedCover by remember { mutableStateOf<Uri?>(null) }

    val pickImagesLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        selectedImages = uris
    }
    val pickAudioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        selectedAudio = uri
    }
    val pickCoverLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        selectedCover = uri
    }

    LaunchedEffect(postId) {
        viewModel.load(postId)
    }

    // 成功保存后，回标首页与我的动态刷新，并返回
    LaunchedEffect(Unit) {
        viewModel.editSuccess.collect {
            val homeEntry = try { navController.getBackStackEntry("home") } catch (e: Exception) { null }
            homeEntry?.savedStateHandle?.set("home_refresh", true)

            val myPostsEntry = try { navController.getBackStackEntry("my_posts") } catch (e: Exception) { null }
            myPostsEntry?.savedStateHandle?.set("my_posts_refresh", true)
            myPostsEntry?.savedStateHandle?.set("my_posts_edit_success", true)
            navController.popBackStack()
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("编辑帖子") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.save(
                                newImageUris = if (selectedImages.isEmpty()) null else selectedImages,
                                newAudioUri = selectedAudio,
                                newCoverUri = selectedCover
                            )
                        },
                        enabled = !uiState.saving
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "保存")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (uiState.loading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            Text(text = "基础信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = uiState.title,
                onValueChange = { viewModel.updateTitle(it) },
                label = { Text("标题") },
                modifier = Modifier.fillMaxWidth()
            )

            when (uiState.type) {
                "article" -> {
                    OutlinedTextField(
                        value = uiState.content,
                        onValueChange = { viewModel.updateContent(it) },
                        label = { Text("正文") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        maxLines = 6
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AssistChip(onClick = { pickImagesLauncher.launch("image/*") }, label = { Text("替换插图(多选)") })
                        AssistChip(onClick = { pickCoverLauncher.launch("image/*") }, label = { Text("替换封面") })
                    }
                }
                "images" -> {
                    OutlinedTextField(
                        value = uiState.description,
                        onValueChange = { viewModel.updateDescription(it) },
                        label = { Text("描述") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        maxLines = 5
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AssistChip(onClick = { pickImagesLauncher.launch("image/*") }, label = { Text("替换图片集(多选)") })
                        AssistChip(onClick = { pickCoverLauncher.launch("image/*") }, label = { Text("替换封面") })
                    }
                }
                "music" -> {
                    OutlinedTextField(
                        value = uiState.description,
                        onValueChange = { viewModel.updateDescription(it) },
                        label = { Text("描述") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        maxLines = 5
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AssistChip(onClick = { pickAudioLauncher.launch("audio/*") }, label = { Text("替换音频文件") })
                        AssistChip(onClick = { pickCoverLauncher.launch("image/*") }, label = { Text("替换封面") })
                    }
                }
            }

            OutlinedTextField(
                value = uiState.tagsText,
                onValueChange = { viewModel.updateTagsText(it) },
                label = { Text("标签（空格分隔）") },
                modifier = Modifier.fillMaxWidth()
            )

            Row {
                Text(text = "是否公开", modifier = Modifier.weight(1f))
                Switch(checked = uiState.isPublic, onCheckedChange = { viewModel.updatePublic(it) })
            }

            if (uiState.saving) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
