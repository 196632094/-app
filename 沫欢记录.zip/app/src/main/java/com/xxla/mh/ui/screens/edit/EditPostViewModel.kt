package com.xxla.mh.ui.screens.edit

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.PostRepository
import com.xxla.mh.data.UploadRepository
import com.xxla.mh.network.PostDetail
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditPostUiState(
    val loading: Boolean = false,
    val saving: Boolean = false,
    val error: String? = null,
    val post: PostDetail? = null,
    val type: String = "article",
    val title: String = "",
    val content: String = "",
    val description: String = "",
    val tagsText: String = "",
    val isPublic: Boolean = true,
)

@HiltViewModel
class EditPostViewModel @Inject constructor(
    private val postRepository: PostRepository,
    private val uploadRepository: UploadRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(EditPostUiState())
    val uiState: StateFlow<EditPostUiState> = _uiState

    private val _editSuccess = MutableSharedFlow<Boolean>(replay = 0)
    val editSuccess = _editSuccess.asSharedFlow()

    private var currentPostId: String = ""

    fun load(postId: String) {
        currentPostId = postId
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(loading = true, error = null)
            val resp = postRepository.getPostDetail(postId)
            val detail = resp.body()?.data
            _uiState.value = if (detail != null) {
                _uiState.value.copy(
                    loading = false,
                    post = detail,
                    type = detail.type,
                    title = detail.title ?: "",
                    content = detail.content ?: "",
                    description = detail.description ?: "",
                    tagsText = detail.tags.joinToString(" "),
                    isPublic = _uiState.value.isPublic
                )
            } else {
                _uiState.value.copy(loading = false, error = "加载失败")
            }
        }
    }

    fun updateTitle(v: String) { _uiState.value = _uiState.value.copy(title = v) }
    fun updateContent(v: String) { _uiState.value = _uiState.value.copy(content = v) }
    fun updateDescription(v: String) { _uiState.value = _uiState.value.copy(description = v) }
    fun updateTagsText(v: String) { _uiState.value = _uiState.value.copy(tagsText = v) }
    fun updatePublic(v: Boolean) { _uiState.value = _uiState.value.copy(isPublic = v) }

    fun save(newImageUris: List<Uri>?, newAudioUri: Uri?, newCoverUri: Uri?) {
        val s = _uiState.value
        val type = s.type
        val title = s.title
        val content = s.content
        val description = s.description
        val tagsList = s.tagsText.split(" ").map { it.trim() }.filter { it.isNotEmpty() }
        val isPublic = s.isPublic

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(saving = true, error = null)
            val resultFlow = uploadRepository.updatePost(
                postId = currentPostId,
                type = type,
                newImageUris = newImageUris,
                newAudioUri = newAudioUri,
                newCoverUri = newCoverUri,
                title = title.takeIf { it.isNotBlank() },
                content = if (type == "article") content.takeIf { it.isNotBlank() } else null,
                description = if (type != "article") description.takeIf { it.isNotBlank() } else null,
                tags = tagsList.takeIf { it.isNotEmpty() },
                isPublic = isPublic,
                onProgress = { /* reserved for future progress UI */ }
            )
            try {
                resultFlow.collect { r ->
                    if (r.isSuccess) {
                        _uiState.value = _uiState.value.copy(saving = false)
                        _editSuccess.emit(true)
                    } else {
                        _uiState.value = _uiState.value.copy(saving = false, error = r.exceptionOrNull()?.message ?: "保存失败")
                    }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(saving = false, error = e.message ?: "保存失败")
            }
        }
    }
}

