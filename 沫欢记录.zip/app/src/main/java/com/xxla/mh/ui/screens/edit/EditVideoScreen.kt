package com.xxla.mh.ui.screens.edit

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditVideoScreen(
    navController: NavController,
    videoId: String,
    viewModel: EditVideoViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var newVideoUri by remember { mutableStateOf<Uri?>(null) }
    var newThumbUri by remember { mutableStateOf<Uri?>(null) }

    val pickVideoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        newVideoUri = uri
    }
    val pickImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        newThumbUri = uri
    }

    LaunchedEffect(videoId) {
        viewModel.load(videoId)
    }

    // 成功保存后，标记首页刷新并返回
    LaunchedEffect(Unit) {
        viewModel.editSuccess.collect {
            val homeEntry = try { navController.getBackStackEntry("home") } catch (e: Exception) { null }
            homeEntry?.savedStateHandle?.set("home_refresh", true)

            val myVideosEntry = try { navController.getBackStackEntry("my_videos") } catch (e: Exception) { null }
            myVideosEntry?.savedStateHandle?.set("my_videos_refresh", true)
            myVideosEntry?.savedStateHandle?.set("my_videos_edit_success", true)
            navController.popBackStack()
        }
    }

    LaunchedEffect(uiState.error) {
        uiState.error?.let { snackbarHostState.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("编辑视频") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.save(newVideoUri, newThumbUri) }, enabled = !uiState.saving) {
                        Icon(Icons.Default.Save, contentDescription = "保存")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (uiState.loading) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            Text(text = "基础信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = uiState.title,
                onValueChange = { viewModel.updateTitle(it) },
                label = { Text("标题") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = uiState.description,
                onValueChange = { viewModel.updateDescription(it) },
                label = { Text("描述") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                maxLines = 5
            )

            OutlinedTextField(
                value = uiState.tagsText,
                onValueChange = { viewModel.updateTagsText(it) },
                label = { Text("标签（空格分隔）") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AssistChip(onClick = { pickVideoLauncher.launch("video/*") }, label = { Text("替换视频文件") })
                AssistChip(onClick = { pickImageLauncher.launch("image/*") }, label = { Text("替换封面图") })
            }

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(text = "是否公开", modifier = Modifier.weight(1f))
                Switch(checked = uiState.isPublic, onCheckedChange = { viewModel.updatePublic(it) })
            }

            if (uiState.saving) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
