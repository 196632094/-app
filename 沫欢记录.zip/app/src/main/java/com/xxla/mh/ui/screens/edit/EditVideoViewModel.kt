package com.xxla.mh.ui.screens.edit

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.VideoRepository
import com.xxla.mh.network.VideoDetail
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class EditVideoUiState(
    val loading: Boolean = false,
    val saving: Boolean = false,
    val error: String? = null,
    val video: VideoDetail? = null,
    val title: String = "",
    val description: String = "",
    val tagsText: String = "",
    val isPublic: Boolean = true,
)

@HiltViewModel
class EditVideoViewModel @Inject constructor(
    private val repository: VideoRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(EditVideoUiState())
    val uiState: StateFlow<EditVideoUiState> = _uiState

    private val _editSuccess = MutableSharedFlow<Boolean>(replay = 0)
    val editSuccess = _editSuccess.asSharedFlow()

    private var currentVideoId: String = ""

    fun load(videoId: String) {
        currentVideoId = videoId
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(loading = true, error = null)
            val resp = repository.getVideoDetail(videoId)
            val detail = resp.body()?.data
            _uiState.value = if (detail != null) {
                _uiState.value.copy(
                    loading = false,
                    video = detail,
                    title = detail.title,
                    description = detail.description,
                    tagsText = detail.tags.joinToString(" "),
                    isPublic = _uiState.value.isPublic
                )
            } else {
                _uiState.value.copy(loading = false, error = "加载失败")
            }
        }
    }

    fun updateTitle(value: String) { _uiState.value = _uiState.value.copy(title = value) }
    fun updateDescription(value: String) { _uiState.value = _uiState.value.copy(description = value) }
    fun updateTagsText(value: String) { _uiState.value = _uiState.value.copy(tagsText = value) }
    fun updatePublic(value: Boolean) { _uiState.value = _uiState.value.copy(isPublic = value) }

    fun save(newVideoUri: Uri?, newThumbUri: Uri?) {
        val title = _uiState.value.title
        val desc = _uiState.value.description
        val tagsList = _uiState.value.tagsText.split(" ").map { it.trim() }.filter { it.isNotEmpty() }
        val isPublic = _uiState.value.isPublic

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(saving = true, error = null)
            val detail = repository.updateVideo(
                videoId = currentVideoId,
                title = if (title.isBlank()) null else title,
                description = if (desc.isBlank()) null else desc,
                tags = if (tagsList.isEmpty()) null else tagsList,
                isPublic = isPublic,
                newVideoUri = newVideoUri,
                newThumbnailUri = newThumbUri
            )
            if (detail != null) {
                _uiState.value = _uiState.value.copy(saving = false, video = detail)
                _editSuccess.emit(true)
            } else {
                _uiState.value = _uiState.value.copy(saving = false, error = "保存失败")
            }
        }
    }
}
