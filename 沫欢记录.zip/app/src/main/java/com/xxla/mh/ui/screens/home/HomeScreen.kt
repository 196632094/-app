package com.xxla.mh.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import java.time.Instant
import java.time.format.DateTimeParseException

// 统一首页内容条目类型，用于按发布时间排序展示
private sealed class FeedEntry(val publishTime: Long) {
    data class VideoEntry(val video: Video): FeedEntry(video.publishTime)
    data class PostEntry(val post: Post, val time: Long): FeedEntry(time)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var isGridMode by remember { mutableStateOf(false) }

    // 监听来自上传页的刷新与成功提示事件（通过当前 BackStackEntry 的 SavedStateHandle）
    val refreshKey = "home_refresh"
    val publishKey = "home_publish_success"

    // 进入页面时刷新，确保发布后新内容能展示（视频与帖子）
    LaunchedEffect(Unit) {
        viewModel.refreshVideos()
        viewModel.refreshPosts()
    }

    LaunchedEffect(navController) {
        snapshotFlow { navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>(refreshKey) ?: false }
            .collect { shouldRefresh ->
                if (shouldRefresh) {
                    viewModel.refreshVideos()
                    viewModel.refreshPosts()
                    navController.currentBackStackEntry?.savedStateHandle?.set(refreshKey, false)
                }
            }
    }

    LaunchedEffect(navController) {
        snapshotFlow { navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>(publishKey) ?: false }
            .collect { showSuccess ->
                if (showSuccess) {
                    snackbarHostState.showSnackbar("发布成功")
                    navController.currentBackStackEntry?.savedStateHandle?.set(publishKey, false)
                }
            }
    }
    // 统一收集 ViewModel 消息用于提示（点赞等）
    LaunchedEffect(viewModel) {
        viewModel.messages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "首页",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    TextButton(
                        onClick = {
                            navController.navigate(com.xxla.mh.navigation.Screen.AnimeSearch.route)
                        }
                    ) {
                        Text("看动漫")
                    }
                    IconButton(
                        onClick = {
                            navController.navigate("search")
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "搜索"
                        )
                    }
                    AssistChip(
                        onClick = { isGridMode = !isGridMode },
                        label = { Text(if (isGridMode) "网格" else "列表") }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .systemBarsPadding()
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // 合并视频与帖子为统一时间流（按发布时间倒序）
            val feedItems = remember(uiState.videos, uiState.posts) {
                val list = mutableListOf<FeedEntry>()
                uiState.videos.forEach { list.add(FeedEntry.VideoEntry(it)) }
                uiState.posts.forEach { p ->
                    val ts = try {
                        Instant.parse(p.createdAt ?: "").toEpochMilli()
                    } catch (_: DateTimeParseException) {
                        0L
                    }
                    list.add(FeedEntry.PostEntry(p, ts))
                }
                list.sortedByDescending { it.publishTime }
            }
            when {
                uiState.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                uiState.error != null -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "加载失败",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { viewModel.refreshVideos() }
                            ) {
                                Text("重试")
                            }
                        }
                    }
                }
                else -> {
                    val listState = rememberLazyListState()

                    LaunchedEffect(listState, uiState.hasMoreData, uiState.isLoadingMore, feedItems) {
                        snapshotFlow {
                            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                            val totalCount = listState.layoutInfo.totalItemsCount
                            lastVisible >= totalCount - 2
                        }.collect { nearEnd ->
                            if (nearEnd && uiState.hasMoreData && !uiState.isLoadingMore) {
                                viewModel.loadMore()
                            }
                        }
                    }
                    if (isGridMode) {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(200.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            contentPadding = PaddingValues(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(feedItems) { entry ->
                                when (entry) {
                                    is FeedEntry.VideoEntry -> {
                                        val video = entry.video
                                        VideoCard(
                                            video = video,
                                            onVideoClick = { videoId ->
                                                navController.navigate(
                                                    com.xxla.mh.navigation.Screen.VideoPlayer.createRoute(videoId, "home")
                                                )
                                            },
                                            onUserClick = { userId ->
                                                navController.navigate("user_profile/$userId")
                                            },
                                            onLikeClick = { vid ->
                                                viewModel.toggleLike(vid)
                                            },
                                            navController = navController,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    is FeedEntry.PostEntry -> {
                                        val post = entry.post
                                        PostCard(
                                            post = post,
                                            onClick = { postId ->
                                                navController.navigate(com.xxla.mh.navigation.Screen.PostDetail.createRoute(postId))
                                            },
                                            navController = navController,
                                            onLikeClick = { pid ->
                                                viewModel.togglePostLike(pid)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            contentPadding = PaddingValues(vertical = 16.dp),
                            modifier = Modifier.fillMaxWidth(),
                            state = listState
                        ) {
                            items(feedItems) { entry ->
                                when (entry) {
                                    is FeedEntry.VideoEntry -> {
                                        val video = entry.video
                                        VideoCard(
                                            video = video,
                                            onVideoClick = { videoId ->
                                                navController.navigate(
                                                    com.xxla.mh.navigation.Screen.VideoPlayer.createRoute(videoId, "home")
                                                )
                                            },
                                            onUserClick = { userId ->
                                                navController.navigate("user_profile/$userId")
                                            },
                                            onLikeClick = { vid ->
                                                viewModel.toggleLike(vid)
                                            },
                                            navController = navController
                                        )
                                    }
                                    is FeedEntry.PostEntry -> {
                                        val post = entry.post
                                        PostCard(
                                            post = post,
                                            onClick = { postId ->
                                                navController.navigate(com.xxla.mh.navigation.Screen.PostDetail.createRoute(postId))
                                            },
                                            navController = navController,
                                            onLikeClick = { pid ->
                                                viewModel.togglePostLike(pid)
                                            }
                                        )
                                    }
                                }
                            }

                            // 加载更多指示器
                            if (uiState.isLoadingMore) {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
