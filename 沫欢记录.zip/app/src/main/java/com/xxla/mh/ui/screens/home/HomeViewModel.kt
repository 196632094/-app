package com.xxla.mh.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.xxla.mh.data.VideoRepository
import com.xxla.mh.data.PostRepository
import com.xxla.mh.network.VideoItem
import com.xxla.mh.network.PostItem
import com.xxla.mh.util.UrlUtils
import java.time.Instant
import java.time.format.DateTimeParseException

data class Video(
    val id: String,
    val title: String,
    val description: String,
    val thumbnailUrl: String,
    val videoUrl: String,
    val authorId: String,
    val authorName: String,
    val authorAvatar: String,
    val viewCount: Long,
    val likeCount: Long,
    val commentCount: Long,
    val duration: Long,
    val publishTime: Long,
    val isLiked: Boolean = false,
    val isFavorited: Boolean = false
)

// 首页帖子 UI 模型（文章/图片/音乐统一）
data class Post(
    val id: String,
    val type: String,
    val title: String?,
    val content: String?,
    val description: String?,
    val images: List<String>?,
    val audioUrl: String?,
    val coverUrl: String?,
    val author: com.xxla.mh.network.UserBrief?,
    val createdAt: String?,
    val likeCount: Long = 0L,
    val commentCount: Long = 0L,
    val isLiked: Boolean = false
)

data class HomeUiState(
    val videos: List<Video> = emptyList(),
    val posts: List<Post> = emptyList(),
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val error: String? = null,
    val hasMoreData: Boolean = true
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val videoRepository: VideoRepository,
    private val postRepository: PostRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    // 一次性事件（例如 Snackbar 消息）
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private var currentPage = 1 // 视频当前页
    private val pageSize = 10

    // 帖子分页状态（与视频并行）
    private var postCurrentPage = 1
    private var postTotalPages = 1
    private var hasMoreVideos = true
    private var hasMorePosts = true
    private var isLoadingMoreVideos = false
    private var isLoadingMorePosts = false

    // 详情元数据缓存：用于列表补全点赞/评论数与点赞状态
    private data class PostMeta(val likeCount: Long, val commentCount: Long, val isLiked: Boolean)
    private val postMetaCache = mutableMapOf<String, PostMeta>()

    init {
        loadVideos()
        loadPosts()
    }

    fun loadVideos() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            
            try {
                currentPage = 1
                val response = videoRepository.getVideos(page = currentPage, size = pageSize, noRetry = true)
                if (!response.isSuccessful || response.body() == null) {
                    throw Exception(response.errorBody()?.string() ?: response.message())
                }
                val body = response.body()!!
                val videos = body.data.videos.map { it.toUiVideo() }
                val hasMore = body.data.currentPage < body.data.totalPages
                hasMoreVideos = hasMore
                _uiState.value = _uiState.value.copy(
                    videos = videos,
                    isLoading = false,
                    hasMoreData = hasMore || hasMorePosts,
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message ?: "加载失败"
                )
            }
        }
    }

    private fun loadPosts(page: Int = 1, size: Int = 10) {
        viewModelScope.launch {
            try {
                val response = postRepository.getPosts(page = page, size = size, noRetry = true)
                if (!response.isSuccessful || response.body() == null) return@launch
                val data = response.body()!!.data
                val posts = data.posts.map { it.toUiPost() }
                postCurrentPage = data.currentPage
                postTotalPages = data.totalPages
                hasMorePosts = postCurrentPage < postTotalPages
                _uiState.value = _uiState.value.copy(
                    posts = posts,
                    hasMoreData = hasMoreVideos || hasMorePosts,
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts
                )

                // 异步补全点赞/评论数与点赞状态
                enrichPostsCountsAsync(posts)
            } catch (_: Exception) { /* 忽略帖子加载错误，不阻塞视频流 */ }
        }
    }

    fun refreshVideos() {
        _uiState.value = _uiState.value.copy(videos = emptyList())
        loadVideos()
    }

    fun refreshPosts() {
        _uiState.value = _uiState.value.copy(posts = emptyList())
        loadPosts(page = 1, size = pageSize)
    }

    fun toggleLike(videoId: String) {
        val current = _uiState.value
        val idx = current.videos.indexOfFirst { it.id == videoId }
        if (idx == -1) return
        val target = current.videos[idx]
        val currentlyLiked = target.isLiked
        // 乐观更新
        val updated = target.copy(
            isLiked = !currentlyLiked,
            likeCount = target.likeCount + if (!currentlyLiked) 1 else -1
        )
        val newList = current.videos.toMutableList().also { it[idx] = updated }
        _uiState.value = current.copy(videos = newList)

        // 调用后端，失败则回滚
        viewModelScope.launch {
            val ok = try {
                if (currentlyLiked) videoRepository.unlikeVideo(videoId) else videoRepository.likeVideo(videoId)
            } catch (e: Exception) { false }
            if (!ok) {
                val rollback = updated.copy(
                    isLiked = currentlyLiked,
                    likeCount = target.likeCount
                )
                val rollbackList = _uiState.value.videos.toMutableList().also { it[idx] = rollback }
                _uiState.value = _uiState.value.copy(videos = rollbackList)
            }
        }
    }

    // 帖子点赞/取消点赞（文章/图片/音乐）
    fun togglePostLike(postId: String) {
        val current = _uiState.value
        val idx = current.posts.indexOfFirst { it.id == postId }
        if (idx == -1) return
        val target = current.posts[idx]
        val currentlyLiked = target.isLiked

        // 乐观更新
        val newLikeCount = (target.likeCount + if (!currentlyLiked) 1 else -1).coerceAtLeast(0)
        val updated = target.copy(isLiked = !currentlyLiked, likeCount = newLikeCount)
        val newPosts = current.posts.toMutableList().also { it[idx] = updated }
        _uiState.value = current.copy(posts = newPosts)

        // 同步本地缓存
        val prevMeta = postMetaCache[postId]
        postMetaCache[postId] = PostMeta(
            likeCount = newLikeCount,
            commentCount = prevMeta?.commentCount ?: target.commentCount,
            isLiked = !currentlyLiked
        )

        // 调用后端，失败则回滚
        viewModelScope.launch {
            val ok = try {
                val resp = if (currentlyLiked) postRepository.unlikePost(postId) else postRepository.likePost(postId)
                resp.isSuccessful && (resp.body()?.success == true)
            } catch (e: Exception) { false }
            if (!ok) {
                val rollbackPosts = _uiState.value.posts.toMutableList().also { it[idx] = target }
                _uiState.value = _uiState.value.copy(posts = rollbackPosts)

                // 回滚缓存
                if (prevMeta != null) {
                    postMetaCache[postId] = prevMeta
                } else {
                    postMetaCache.remove(postId)
                }
            } else {
                _messages.tryEmit(if (currentlyLiked) "已取消点赞" else "点赞成功")
            }
        }
    }

    fun loadMoreVideos() {
        if (isLoadingMoreVideos || !hasMoreVideos) return
        // 预先标记，避免并发情况下多次进入
        isLoadingMoreVideos = true
        _uiState.value = _uiState.value.copy(isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts)

        viewModelScope.launch {
            
            try {
                val nextPage = currentPage + 1
                val response = videoRepository.getVideos(page = nextPage, size = pageSize, noRetry = true)
                if (!response.isSuccessful || response.body() == null) {
                    throw Exception(response.errorBody()?.string() ?: response.message())
                }
                val body = response.body()!!
                val moreVideos = body.data.videos.map { it.toUiVideo() }
                currentPage = body.data.currentPage
                val hasMore = body.data.currentPage < body.data.totalPages
                hasMoreVideos = hasMore
                val mergedVideos = (_uiState.value.videos + moreVideos).distinctBy { it.id }
                _uiState.value = _uiState.value.copy(
                    videos = mergedVideos,
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts,
                    hasMoreData = hasMoreVideos || hasMorePosts
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts,
                    error = e.message ?: "加载更多失败"
                )
            } finally {
                isLoadingMoreVideos = false
                _uiState.value = _uiState.value.copy(
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts
                )
            }
        }
    }

    fun loadMorePosts() {
        if (isLoadingMorePosts || !hasMorePosts) return
        // 预先标记，避免并发情况下多次进入
        isLoadingMorePosts = true
        _uiState.value = _uiState.value.copy(isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts)

        viewModelScope.launch {

            try {
                val nextPage = postCurrentPage + 1
                val response = postRepository.getPosts(page = nextPage, size = pageSize, noRetry = true)
                if (!response.isSuccessful || response.body() == null) {
                    throw Exception(response.errorBody()?.string() ?: response.message())
                }
                val data = response.body()!!.data
                val morePosts = data.posts.map { it.toUiPost() }
                postCurrentPage = data.currentPage
                postTotalPages = data.totalPages
                hasMorePosts = postCurrentPage < postTotalPages
                val mergedPosts = (_uiState.value.posts + morePosts).distinctBy { it.id }
                _uiState.value = _uiState.value.copy(
                    posts = mergedPosts,
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts,
                    hasMoreData = hasMoreVideos || hasMorePosts
                )

                // 异步补全新增列表的点赞/评论数与点赞状态
                enrichPostsCountsAsync(morePosts)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts,
                    error = e.message ?: "加载更多失败"
                )
            } finally {
                isLoadingMorePosts = false
                _uiState.value = _uiState.value.copy(
                    isLoadingMore = isLoadingMoreVideos || isLoadingMorePosts
                )
            }
        }
    }

    // 合并流的加载更多入口：根据各自分页状态并行触发
    fun loadMore() {
        val canLoadVideos = hasMoreVideos && !isLoadingMoreVideos
        val canLoadPosts = hasMorePosts && !isLoadingMorePosts
        if (!canLoadVideos && !canLoadPosts) return
        if (canLoadVideos) loadMoreVideos()
        if (canLoadPosts) loadMorePosts()
    }

    fun deleteVideo(videoId: String) {
        val current = _uiState.value
        val idx = current.videos.indexOfFirst { it.id == videoId }
        if (idx == -1) return
        // 乐观移除
        val removed = current.videos[idx]
        val newList = current.videos.toMutableList().also { it.removeAt(idx) }
        _uiState.value = current.copy(videos = newList)

        viewModelScope.launch {
            val ok = try { videoRepository.deleteVideo(videoId) } catch (e: Exception) { false }
            if (!ok) {
                // 回滚
                val rollbackList = _uiState.value.videos.toMutableList().also { it.add(idx, removed) }
                _uiState.value = _uiState.value.copy(videos = rollbackList, error = "删除失败")
                _messages.emit("删除失败")
            } else {
                _messages.emit("删除成功")
            }
        }
    }

    fun deletePost(postId: String) {
        val current = _uiState.value
        val idx = current.posts.indexOfFirst { it.id == postId }
        if (idx == -1) return
        val removed = current.posts[idx]
        val newList = current.posts.toMutableList().also { it.removeAt(idx) }
        _uiState.value = current.copy(posts = newList)

        viewModelScope.launch {
            val ok = try { postRepository.deletePost(postId) } catch (e: Exception) { false }
            if (!ok) {
                val rollbackList = _uiState.value.posts.toMutableList().also { it.add(idx, removed) }
                _uiState.value = _uiState.value.copy(posts = rollbackList, error = "删除动态失败")
                _messages.emit("删除失败")
            } else {
                _messages.emit("删除成功")
            }
        }
    }

    private fun VideoItem.toUiVideo(): Video {
        // createdAt 是 ISO8601 字符串，转换为时间戳；失败则使用当前时间
        val publishTs = try {
            Instant.parse(createdAt).toEpochMilli()
        } catch (e: DateTimeParseException) {
            System.currentTimeMillis()
        }

        return Video(
            id = id,
            title = title,
            description = "",
            thumbnailUrl = UrlUtils.toAbsolute(coverUrl),
            videoUrl = UrlUtils.toAbsolute(videoUrl),
            authorId = author.id,
            authorName = author.nickname ?: author.username,
            authorAvatar = UrlUtils.toAbsolute(author.avatar ?: ""),
            viewCount = viewCount.toLong(),
            likeCount = likeCount.toLong(),
            commentCount = commentCount.toLong(),
            duration = duration.toLong(),
            publishTime = publishTs,
            isLiked = isLiked,
            isFavorited = false
        )
    }

    private fun PostItem.toUiPost(): Post {
        return Post(
            id = id,
            type = type,
            title = title,
            content = content,
            description = description,
            images = images,
            audioUrl = audioUrl,
            coverUrl = coverUrl,
            author = author,
            createdAt = createdAt,
            likeCount = (likeCount ?: 0).toLong(),
            commentCount = (commentCount ?: 0).toLong(),
            isLiked = isLiked ?: false
        )
    }

    // 异步补全帖子列表的真实点赞/评论数与点赞状态
    private fun enrichPostsCountsAsync(posts: List<Post>) {
        if (posts.isEmpty()) return
        viewModelScope.launch {
            posts.forEach { p ->
                // 如果已有缓存，直接使用
                val cached = postMetaCache[p.id]
                val meta = if (cached != null) {
                    cached
                } else {
                    try {
                        val resp = postRepository.getPostDetail(p.id)
                        if (resp.isSuccessful && resp.body()?.success == true) {
                            val d = resp.body()!!.data
                            PostMeta(d.likeCount.toLong(), d.commentCount.toLong(), d.isLiked)
                        } else null
                    } catch (_: Exception) {
                        null
                    }
                }

                if (meta != null) {
                    postMetaCache[p.id] = meta
                    // 更新 UI 中对应项
                    val current = _uiState.value
                    val idx = current.posts.indexOfFirst { it.id == p.id }
                    if (idx != -1) {
                        val updated = current.posts[idx].copy(
                            likeCount = meta.likeCount,
                            commentCount = meta.commentCount,
                            isLiked = meta.isLiked
                        )
                        val newPosts = current.posts.toMutableList().also { it[idx] = updated }
                        _uiState.value = current.copy(posts = newPosts)
                    }
                }
            }
        }
    }
}
