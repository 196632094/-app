package com.xxla.mh.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import kotlinx.coroutines.delay
import com.xxla.mh.util.UrlUtils
// 使用 HomeViewModel 定义的帖子 UI 模型

@Composable
fun PostCard(
    post: Post,
    onClick: (String) -> Unit = {},
    showManageActions: Boolean = false,
    onDeleteClick: ((String) -> Unit)? = null,
    onEditClick: ((String) -> Unit)? = null,
    navController: NavController? = null,
    onLikeClick: ((String) -> Unit)? = null
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick(post.id) },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // 作者与时间
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = UrlUtils.toAbsolute(post.author?.avatar),
                    contentDescription = "头像",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(MaterialTheme.shapes.small)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = post.author?.nickname ?: post.author?.username ?: "匿名用户",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        if (com.xxla.mh.ui.components.isLover(post.author?.id)) {
                            Spacer(modifier = Modifier.width(6.dp))
                            com.xxla.mh.ui.components.LoverTag(post.author?.id)
                        }
                    }
                    Text(
                        text = (post.createdAt ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // 管理操作（仅在管理场景展示）
                if (showManageActions) {
                    var menuExpanded = remember { mutableStateOf(false) }
                    Box {
                        IconButton(onClick = { menuExpanded.value = true }) {
                            Icon(imageVector = Icons.Filled.MoreVert, contentDescription = "更多")
                        }
                        DropdownMenu(expanded = menuExpanded.value, onDismissRequest = { menuExpanded.value = false }) {
                            DropdownMenuItem(text = { Text("编辑") }, onClick = {
                                menuExpanded.value = false
                                onEditClick?.invoke(post.id)
                            })
                            DropdownMenuItem(text = { Text("删除") }, onClick = {
                                menuExpanded.value = false
                                onDeleteClick?.invoke(post.id)
                            })
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 标题
            if (!post.title.isNullOrBlank()) {
                Text(
                    text = post.title ?: "",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // 正文/描述
            val desc = post.content ?: post.description
            if (!desc.isNullOrBlank()) {
                Text(
                    text = desc ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // 媒体展示：图片或音乐
            when (post.type.lowercase()) {
                "images" -> {
                    val imgs = post.images ?: emptyList()
                    if (imgs.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            imgs.take(3).forEach { url ->
                                AsyncImage(
                                    model = UrlUtils.toAbsolute(url),
                                    contentDescription = "图片",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                )
                            }
                        }
                    }
                }
                "music" -> {
                    val context = LocalContext.current
                    val exoPlayer = remember(post.audioUrl) { ExoPlayer.Builder(context).build() }
                    val isPlaying = remember { mutableStateOf(false) }
                    var playbackPosition = remember { mutableStateOf(0L) }
                    var durationMs = remember { mutableStateOf(0L) }

                    DisposableEffect(post.audioUrl) {
                        if (!post.audioUrl.isNullOrBlank()) {
                            exoPlayer.setMediaItem(MediaItem.fromUri(UrlUtils.toAbsolute(post.audioUrl)))
                            exoPlayer.prepare()
                        }
                        onDispose {
                            exoPlayer.release()
                        }
                    }

                    // 播放中更新进度与时长
                    LaunchedEffect(isPlaying.value) {
                        while (isPlaying.value) {
                            val d = exoPlayer.duration
                            durationMs.value = if (d > 0) d else durationMs.value
                            playbackPosition.value = exoPlayer.currentPosition
                            delay(500)
                        }
                    }

                    // 紧凑布局：左侧小封面 + 右侧信息与控制
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 小封面（点击播放/暂停）
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(enabled = !post.audioUrl.isNullOrBlank()) {
                                    if (!isPlaying.value) {
                                        exoPlayer.play()
                                    } else {
                                        exoPlayer.pause()
                                    }
                                    isPlaying.value = !isPlaying.value
                                }
                        ) {
                            val coverAbs = UrlUtils.toAbsolute(post.coverUrl)
                            if (coverAbs.isNotBlank()) {
                                AsyncImage(
                                    model = coverAbs,
                                    contentDescription = "音乐封面",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MusicNote,
                                        contentDescription = "音乐占位",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPlaying.value) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = if (isPlaying.value) "暂停" else "播放",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        // 右侧信息与进度控制
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.MusicNote,
                                    contentDescription = "音频",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = UrlUtils.toAbsolute(post.audioUrl),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }

                            if (!post.audioUrl.isNullOrBlank()) {
                                val durationFloat = durationMs.value.coerceAtLeast(0L).toFloat()
                                val positionFloat = playbackPosition.value.coerceIn(0L, durationMs.value).toFloat()
                                Slider(
                                    value = if (durationFloat > 0f) positionFloat else 0f,
                                    onValueChange = { newVal ->
                                        val newPos = newVal.toLong()
                                        exoPlayer.seekTo(newPos)
                                        playbackPosition.value = newPos
                                    },
                                    valueRange = 0f..durationFloat,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = formatTimeMs(playbackPosition.value),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = formatTimeMs(durationMs.value),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                else -> {
                    // 文章：已在上方展示标题和内容即可
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 互动按钮：点赞与评论
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 点赞按钮
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onLikeClick?.invoke(post.id) }
                ) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "点赞",
                        tint = if (post.isLiked) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formatCount(post.likeCount),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // 评论按钮
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        // 导航到帖子详情（包含评论）
                        navController?.navigate(com.xxla.mh.navigation.Screen.PostDetail.createRoute(post.id))
                    }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Comment,
                        contentDescription = "评论",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${formatCount(post.commentCount)} 评论",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun formatCount(count: Long): String {
    return when {
        count >= 100_000_000 -> String.format("%.1f亿", count / 100_000_000.0)
        count >= 10_000 -> String.format("%.1f万", count / 10_000.0)
        else -> count.toString()
    }
}

private fun formatTimeMs(ms: Long): String {
    if (ms <= 0) return "00:00"
    val totalSeconds = ms / 1000
    val minutes = (totalSeconds / 60).toInt()
    val seconds = (totalSeconds % 60).toInt()
    return String.format("%02d:%02d", minutes, seconds)
}
