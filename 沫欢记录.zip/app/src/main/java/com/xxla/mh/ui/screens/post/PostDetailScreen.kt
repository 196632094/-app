package com.xxla.mh.ui.screens.post

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.outlined.TagFaces
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.ModalBottomSheet
import androidx.activity.compose.BackHandler
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.network.PostDetail
import com.xxla.mh.network.Comment
import com.xxla.mh.ui.components.UserAvatar
import com.xxla.mh.ui.screens.comment.Reply
import com.xxla.mh.util.UrlUtils
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    navController: NavController,
    postId: String,
    viewModel: PostDetailViewModel = hiltViewModel()
) {
    val authViewModel: com.xxla.mh.ui.screens.auth.AuthViewModel = hiltViewModel()
    val authUiState by authViewModel.uiState.collectAsState()
    val currentUserId = authUiState.user?.id
    val detail by viewModel.detail.collectAsState()
    val loading by viewModel.loading.collectAsState()
    val error by viewModel.error.collectAsState()
    val comments by viewModel.comments.collectAsState()
    val commentText by viewModel.commentText.collectAsState()
    val isPosting by viewModel.isPosting.collectAsState()
    val loadingMore by viewModel.loadingMoreComments.collectAsState()
    val hasMore by viewModel.hasMoreComments.collectAsState()
    val replyingTo by viewModel.replyingTo.collectAsState()
    val showStickerPicker by viewModel.showStickerPicker.collectAsState()
    val loadingStickers by viewModel.loadingStickers.collectAsState()
    val stickers by viewModel.stickers.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(postId) { viewModel.load(postId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = detail?.title ?: "帖子详情") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    if (detail != null) {
                        IconButton(onClick = { viewModel.toggleLike() }) {
                            if (detail!!.isLiked) {
                                Icon(Icons.Filled.Favorite, contentDescription = "取消点赞", tint = MaterialTheme.colorScheme.primary)
                            } else {
                                Icon(Icons.Outlined.FavoriteBorder, contentDescription = "点赞")
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 3.dp,
                shadowElevation = 3.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    if (replyingTo != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "正在回复 @${replyingTo}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            TextButton(onClick = { viewModel.clearReply() }) {
                                Text("取消")
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledIconButton(
                            onClick = { viewModel.toggleStickerPicker() },
                            enabled = !isPosting
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.TagFaces,
                                contentDescription = "真寻表情"
                            )
                        }
                        OutlinedTextField(
                            value = commentText,
                            onValueChange = { viewModel.setCommentText(it) },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("说点什么...") },
                            enabled = !isPosting,
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = { viewModel.postComment() },
                            enabled = commentText.isNotBlank() && !isPosting
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "发送")
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        if (showStickerPicker) {
            ModalBottomSheet(onDismissRequest = { viewModel.toggleStickerPicker() }) {
                Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(text = "真寻表情", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    if (loadingStickers) {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(stickers) { url ->
                                Surface(shape = MaterialTheme.shapes.small, tonalElevation = 1.dp) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .combinedClickable(
                                                onClick = { viewModel.sendSticker(postId, url) },
                                                onLongClick = {}
                                            )
                                    ) {
                                        AsyncImage(
                                            model = UrlUtils.toAbsolute(url),
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when {
                loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                error != null -> {
                    Text(text = error ?: "加载失败", color = MaterialTheme.colorScheme.error)
                }
                detail != null -> {
                    PostDetailContent(detail = detail!!)

                    Divider()
                    Text(text = "评论", style = MaterialTheme.typography.titleMedium)

                    if (comments.isEmpty()) {
                        Text(
                            text = "还没有评论，来抢个沙发吧～",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        // 优先按 parentId 分组楼中楼；兼容旧数据使用 @别名 回退
                        val parentAndReplies = remember(comments) {
                            val parents = mutableListOf<Comment>()
                            val repliesMap = mutableMapOf<String, MutableList<Reply>>()
                            val aliasToParent = mutableMapOf<String, Comment>()

                            // 1) 先按 parentId 直接分组
                            comments.forEach { c ->
                                val pid = c.parentId
                                if (pid != null) {
                                    val reply = Reply(
                                        id = c.id,
                                        commentId = pid,
                                        userId = c.author.id,
                                        username = c.author.nickname ?: c.author.username,
                                        userAvatar = c.author.avatar ?: "",
                                        content = c.content,
                                        timestamp = System.currentTimeMillis()
                                    )
                                    repliesMap.getOrPut(pid) { mutableListOf() }.add(reply)
                                } else {
                                    parents.add(c)
                                    val alias = c.author.nickname ?: c.author.username
                                    if (!alias.isNullOrBlank()) aliasToParent[alias] = c
                                }
                            }

                            // 2) 回退：无 parentId 且以 @别名 开头的评论，尝试归入对应父评论
                            val toMove = mutableListOf<Comment>()
                            parents.forEach { c ->
                                val text = c.content
                                if (c.parentId == null && text.startsWith("@")) {
                                    val spaceIdx = text.indexOf(' ')
                                    if (spaceIdx > 1) {
                                        val mentioned = text.substring(1, spaceIdx)
                                        val parent = aliasToParent[mentioned]
                                        if (parent != null && parent.id != c.id) {
                                            val replyText = if (spaceIdx + 1 < text.length) text.substring(spaceIdx + 1) else text
                                            val reply = Reply(
                                                id = c.id,
                                                commentId = parent.id,
                                                userId = c.author.id,
                                                username = c.author.nickname ?: c.author.username,
                                                userAvatar = c.author.avatar ?: "",
                                                content = replyText,
                                                timestamp = System.currentTimeMillis()
                                            )
                                            repliesMap.getOrPut(parent.id) { mutableListOf() }.add(reply)
                                            toMove.add(c)
                                        }
                                    }
                                }
                            }
                            if (toMove.isNotEmpty()) parents.removeAll(toMove)
                            parents to repliesMap
                        }
                        val parentComments = parentAndReplies.first
                        val repliesMap = parentAndReplies.second

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            state = listState
                        ) {
                            items(parentComments) { c ->
                                PostCommentItem(
                                    comment = c,
                                    onLikeClick = { id -> viewModel.toggleCommentLike(id) },
                                    onReplyClick = { viewModel.startReplyTo(c) },
                                    replies = repliesMap[c.id] ?: emptyList(),
                                    currentUserId = currentUserId,
                                    onDeleteComment = { id -> viewModel.deleteComment(id) },
                                    onDeleteReply = { id -> viewModel.deleteReply(id) }
                                )
                            }
                        }
                        LaunchedEffect(listState, hasMore, loadingMore, comments) {
                            snapshotFlow {
                                val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                                val totalCount = listState.layoutInfo.totalItemsCount
                                lastVisible >= totalCount - 2
                            }.collect { nearEnd ->
                                if (nearEnd && hasMore && !loadingMore) {
                                    viewModel.loadMoreComments()
                                }
                            }
                        }
                        if (loadingMore) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
                else -> {
                    Text(text = "暂无数据")
                }
            }
        }
    }
}

@Composable
private fun PostDetailContent(detail: PostDetail) {
    var previewUrl by remember { mutableStateOf<String?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // 作者与时间
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            val authorName = detail.author.nickname ?: detail.author.username
            Text(text = authorName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(text = detail.createdAt, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // 统计
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(text = "${detail.likeCount} 点赞", style = MaterialTheme.typography.bodySmall)
            Text(text = "${detail.commentCount} 评论", style = MaterialTheme.typography.bodySmall)
        }

        // 正文展示：按类型区分
        when (detail.type) {
            "article" -> {
                Text(text = detail.content.orEmpty(), style = MaterialTheme.typography.bodyLarge)
            }
            "images" -> {
                val imgs = detail.images ?: emptyList()
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(imgs) { url ->
                        val absolute = UrlUtils.toAbsolute(url)
                        AsyncImage(
                            model = absolute,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clickable { previewUrl = absolute },
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
            "music" -> {
                // 封面
                detail.coverUrl?.let { c ->
                    val coverAbs = UrlUtils.toAbsolute(c)
                    AsyncImage(
                        model = coverAbs,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clickable { previewUrl = coverAbs },
                        contentScale = ContentScale.Crop
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = detail.description.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(4.dp))
                // 音频信息占位
                Text(
                    text = "音频：${detail.audioUrl ?: "无"}（${detail.duration ?: 0}s）",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            else -> {
                Text(text = detail.description.orEmpty())
            }
        }
        // 标签
        if (detail.tags.isNotEmpty()) {
            FlowRow(mainAxisSpacing = 8.dp, crossAxisSpacing = 8.dp) {
                detail.tags.forEach { t ->
                    AssistChip(onClick = { /* TODO: tag filter */ }, label = { Text(t) })
                }
            }
        }
    }

    // 全屏图片预览（支持返回退出、点击关闭与缩放）
    if (previewUrl != null) {
        FullscreenImageDialog(url = previewUrl!!, onDismiss = { previewUrl = null })
    }
}

// 简易 FlowRow（避免引入额外依赖）
@Composable
private fun FlowRow(
    modifier: Modifier = Modifier,
    mainAxisSpacing: Dp = 0.dp,
    crossAxisSpacing: Dp = 0.dp,
    content: @Composable () -> Unit
) {
    Column(modifier = modifier) { content() }
}

@Composable
private fun PostCommentItem(
    comment: Comment,
    onLikeClick: (String) -> Unit,
    onReplyClick: () -> Unit,
    replies: List<Reply>,
    currentUserId: String?,
    onDeleteComment: (String) -> Unit,
    onDeleteReply: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            UserAvatar(
                avatarUrl = comment.author.avatar ?: "",
                size = 40.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
            var menuExpanded by remember { mutableStateOf(false) }
            val isMine = currentUserId != null && currentUserId == comment.author.id

            Column(
                modifier = Modifier
                    .weight(1f)
                    .combinedClickable(
                        onClick = onReplyClick,
                        onLongClick = { menuExpanded = true }
                    )
            ) {
                Text(
                    text = comment.author.nickname ?: comment.author.username,
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                val isImage = remember(comment.content) {
                    val url = comment.content
                    val lower = url.lowercase(java.util.Locale.getDefault())
                    lower.startsWith("http") && (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".gif"))
                }
                var showImage by remember { mutableStateOf(false) }
                if (isImage) {
                    AsyncImage(
                        model = UrlUtils.toAbsolute(comment.content),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 120.dp)
                            .clickable { showImage = true }
                    )
                    if (showImage) {
                        FullscreenImageDialog(url = UrlUtils.toAbsolute(comment.content)) { showImage = false }
                    }
                } else {
                    Text(
                        text = comment.content,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    offset = androidx.compose.ui.unit.DpOffset(0.dp, (-24).dp)
                ) {
                    DropdownMenuItem(
                        text = { Text("复制内容") },
                        onClick = {
                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(comment.content))
                            menuExpanded = false
                        }
                    )
                    if (isMine) {
                        DropdownMenuItem(
                            text = { Text("删除") },
                            onClick = {
                                onDeleteComment(comment.id)
                                menuExpanded = false
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = comment.createdAt,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onReplyClick,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Reply,
                                contentDescription = "回复",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { onLikeClick(comment.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "点赞",
                                tint = if (comment.isLiked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (comment.likeCount > 0) {
                            Text(
                                text = comment.likeCount.toString(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 回复列表（楼中楼）
        if (replies.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 52.dp, top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                replies.forEach { reply ->
                    ReplyItem(
                        reply = reply,
                        currentUserId = currentUserId,
                        onDeleteReply = onDeleteReply
                    )
                }
            }
        }
    }
}

@Composable
private fun ReplyItem(
    reply: Reply,
    currentUserId: String?,
    onDeleteReply: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        UserAvatar(
            avatarUrl = reply.userAvatar,
            size = 32.dp
        )
        Spacer(modifier = Modifier.width(8.dp))
        val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
        var menuExpanded by remember { mutableStateOf(false) }
        val isMine = currentUserId != null && currentUserId == reply.userId

        Column(
            modifier = Modifier
                .weight(1f)
                .combinedClickable(
                    onClick = {},
                    onLongClick = { menuExpanded = true }
                )
        ) {
            Text(
                text = reply.username,
                style = MaterialTheme.typography.titleSmall
            )
            Spacer(modifier = Modifier.height(2.dp))
            val isImage = remember(reply.content) {
                val url = reply.content
                val lower = url.lowercase(java.util.Locale.getDefault())
                lower.startsWith("http") && (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".gif"))
            }
            var showImage by remember { mutableStateOf(false) }
            if (isImage) {
                AsyncImage(
                    model = UrlUtils.toAbsolute(reply.content),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp)
                        .clickable { showImage = true }
                )
                if (showImage) {
                    FullscreenImageDialog(url = UrlUtils.toAbsolute(reply.content)) { showImage = false }
                }
            } else {
                Text(
                    text = reply.content,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                offset = androidx.compose.ui.unit.DpOffset(0.dp, (-20).dp)
            ) {
                DropdownMenuItem(
                    text = { Text("复制内容") },
                    onClick = {
                        clipboard.setText(androidx.compose.ui.text.AnnotatedString(reply.content))
                        menuExpanded = false
                    }
                )
                if (isMine) {
                    DropdownMenuItem(
                        text = { Text("删除") },
                        onClick = {
                            onDeleteReply(reply.id)
                            menuExpanded = false
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = formatTime(reply.timestamp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun formatTime(ts: Long): String {
    val date = Date(ts)
    val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
    return fmt.format(date)
}

@Composable
private fun FullscreenImageDialog(url: String, onDismiss: () -> Unit) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    BackHandler(enabled = true) { onDismiss() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset += pan
                        }
                    }
            )
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "关闭", tint = Color.White)
            }
        }
    }
}
