package com.xxla.mh.ui.screens.post

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.StickerRepository
import com.xxla.mh.data.PostRepository
import com.xxla.mh.ui.screens.profile.PostHistoryRepository
import com.xxla.mh.network.PostDetail
import com.xxla.mh.network.Comment as NetComment
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class PostDetailViewModel @Inject constructor(
    private val repository: PostRepository,
    private val postHistoryRepository: PostHistoryRepository,
    private val stickerRepository: StickerRepository
) : ViewModel() {
    private val _detail = MutableStateFlow<PostDetail?>(null)
    val detail: StateFlow<PostDetail?> = _detail

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // 评论相关状态
    private val _comments = MutableStateFlow<List<NetComment>>(emptyList())
    val comments: StateFlow<List<NetComment>> = _comments

    private val _commentText = MutableStateFlow("")
    val commentText: StateFlow<String> = _commentText

    private val _isPosting = MutableStateFlow(false)
    val isPosting: StateFlow<Boolean> = _isPosting

    private var currentPostId: String? = null
    private var commentPage: Int = 1
    private var commentTotalPages: Int = 1
    private val _loadingMoreComments = MutableStateFlow(false)
    val loadingMoreComments: StateFlow<Boolean> = _loadingMoreComments
    private val _hasMoreComments = MutableStateFlow(false)
    val hasMoreComments: StateFlow<Boolean> = _hasMoreComments
    private val _replyingTo = MutableStateFlow<String?>(null)
    val replyingTo: StateFlow<String?> = _replyingTo
    private val _replyToCommentId = MutableStateFlow<String?>(null)
    val replyToCommentId: StateFlow<String?> = _replyToCommentId

    // 贴纸选择器相关状态
    private val _showStickerPicker = MutableStateFlow(false)
    val showStickerPicker: StateFlow<Boolean> = _showStickerPicker.asStateFlow()
    private val _loadingStickers = MutableStateFlow(false)
    val loadingStickers: StateFlow<Boolean> = _loadingStickers.asStateFlow()
    private val _stickers = MutableStateFlow<List<String>>(emptyList())
    val stickers: StateFlow<List<String>> = _stickers.asStateFlow()

    fun load(postId: String) {
        _loading.value = true
        _error.value = null
        currentPostId = postId
        viewModelScope.launch {
            try {
                val resp = repository.getPostDetail(postId)
                if (resp.isSuccessful && resp.body() != null && resp.body()!!.success) {
                    _detail.value = resp.body()!!.data
                    // 成功获取详情后记录帖子浏览历史（云端）
                    try {
                        postHistoryRepository.addOrUpdate(postId)
                    } catch (_: Exception) { /* 历史记录失败不影响详情显示 */ }
                    // 同步加载评论（重置）
                    loadComments(postId, reset = true)
                } else {
                    _error.value = resp.body()?.message ?: (resp.errorBody()?.string() ?: "获取详情失败")
                }
            } catch (e: Exception) {
                _error.value = e.message
            } finally {
                _loading.value = false
            }
        }
    }

    fun toggleLike() {
        val d = _detail.value ?: return
        viewModelScope.launch {
            try {
                if (d.isLiked) {
                    val resp = repository.unlikePost(d.id)
                    if (resp.isSuccessful && resp.body()?.success == true) {
                        _detail.value = d.copy(isLiked = false, likeCount = (d.likeCount - 1).coerceAtLeast(0))
                    }
                } else {
                    val resp = repository.likePost(d.id)
                    if (resp.isSuccessful && resp.body()?.success == true) {
                        _detail.value = d.copy(isLiked = true, likeCount = d.likeCount + 1)
                    }
                }
            } catch (_: Exception) {
                // 保持静默失败，避免打断体验
            }
        }
    }

    fun loadComments(postId: String, reset: Boolean = false) {
        viewModelScope.launch {
            try {
                val targetPage = if (reset) 1 else commentPage
                val resp = repository.getPostComments(postId, page = targetPage, size = 20)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val data = resp.body()!!.data
                    commentPage = data.currentPage
                    commentTotalPages = data.totalPages
                    _hasMoreComments.value = commentPage < commentTotalPages
                    _comments.value = if (reset) data.comments else _comments.value + data.comments
                }
            } catch (_: Exception) {
                // 忽略错误，页面仍可展示详情
            }
        }
    }

    fun loadMoreComments() {
        val postId = currentPostId ?: return
        if (_loadingMoreComments.value || commentPage >= commentTotalPages) return
        _loadingMoreComments.value = true
        viewModelScope.launch {
            try {
                val nextPage = commentPage + 1
                val resp = repository.getPostComments(postId, page = nextPage, size = 20)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val data = resp.body()!!.data
                    commentPage = data.currentPage
                    commentTotalPages = data.totalPages
                    _hasMoreComments.value = commentPage < commentTotalPages
                    _comments.value = _comments.value + data.comments
                }
            } catch (_: Exception) {
                // 忽略错误
            } finally {
                _loadingMoreComments.value = false
            }
        }
    }

    fun setCommentText(text: String) {
        _commentText.value = text
    }

    fun postComment() {
        val postId = currentPostId ?: return
        val content = _commentText.value.trim()
        if (content.isEmpty()) return
        _isPosting.value = true
        viewModelScope.launch {
            try {
                val parentId = _replyToCommentId.value
                val resp = repository.postComment(postId, content, parentId)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val newComment = resp.body()!!.data
                    _comments.value = listOf(newComment) + _comments.value
                    _commentText.value = ""
                    _replyingTo.value = null
                    _replyToCommentId.value = null
                    _detail.value?.let { d -> _detail.value = d.copy(commentCount = d.commentCount + 1) }
                }
            } catch (_: Exception) {
                // 静默失败
            } finally {
                _isPosting.value = false
            }
        }
    }

    fun toggleCommentLike(commentId: String) {
        val postId = currentPostId ?: return
        val list = _comments.value.toMutableList()
        val idx = list.indexOfFirst { it.id == commentId }
        if (idx < 0) return
        val target = list[idx]
        viewModelScope.launch {
            try {
                if (target.isLiked) {
                    val resp = repository.unlikeComment(postId, commentId)
                    if (resp.isSuccessful && resp.body()?.success == true) {
                        list[idx] = target.copy(isLiked = false, likeCount = (target.likeCount - 1).coerceAtLeast(0))
                        _comments.value = list
                    }
                } else {
                    val resp = repository.likeComment(postId, commentId)
                    if (resp.isSuccessful && resp.body()?.success == true) {
                        list[idx] = target.copy(isLiked = true, likeCount = target.likeCount + 1)
                        _comments.value = list
                    }
                }
            } catch (_: Exception) {
                // 忽略错误
            }
        }
    }

    fun startReplyTo(comment: NetComment) {
        val alias = comment.author.nickname ?: comment.author.username
        _replyingTo.value = alias
        _replyToCommentId.value = comment.id
        val prefix = "@${alias} "
        if (_commentText.value.isBlank()) {
            _commentText.value = prefix
        } else if (!_commentText.value.startsWith(prefix)) {
            _commentText.value = "$prefix${_commentText.value}"
        }
    }

    fun clearReply() { _replyingTo.value = null; _replyToCommentId.value = null }

    // 删除顶层评论（调用后端，成功后移除其子回复）
    fun deleteComment(commentId: String) {
        val postId = currentPostId ?: return
        viewModelScope.launch {
            try {
                val ok = repository.deleteComment(postId, commentId)
                if (ok) {
                    val list = _comments.value
                    if (list.isNotEmpty()) {
                        val removedCount = list.count { it.id == commentId || it.parentId == commentId }
                        if (removedCount > 0) {
                            _comments.value = list.filterNot { it.id == commentId || it.parentId == commentId }
                            _detail.value?.let { d ->
                                val newCount = (d.commentCount - removedCount).coerceAtLeast(0)
                                _detail.value = d.copy(commentCount = newCount)
                            }
                        }
                    }
                } else {
                    _error.value = "删除评论失败"
                }
            } catch (e: Exception) {
                _error.value = "删除评论异常: ${e.message}"
            }
        }
    }

    // 删除单条回复（调用后端）
    fun deleteReply(replyId: String) {
        val postId = currentPostId ?: return
        viewModelScope.launch {
            try {
                val ok = repository.deleteComment(postId, replyId)
                if (ok) {
                    val list = _comments.value
                    if (list.isNotEmpty()) {
                        val removed = list.any { it.id == replyId }
                        if (removed) {
                            _comments.value = list.filterNot { it.id == replyId }
                            _detail.value?.let { d ->
                                val newCount = (d.commentCount - 1).coerceAtLeast(0)
                                _detail.value = d.copy(commentCount = newCount)
                            }
                        }
                    }
                } else {
                    _error.value = "删除回复失败"
                }
            } catch (e: Exception) {
                _error.value = "删除回复异常: ${e.message}"
            }
        }
    }

    // 贴纸：打开/关闭选择器（首次打开时加载）
    fun toggleStickerPicker() {
        val next = !_showStickerPicker.value
        _showStickerPicker.value = next
        if (next && _stickers.value.isEmpty()) {
            loadStickers()
        }
    }

    // 加载贴纸资源
    private fun loadStickers() {
        _loadingStickers.value = true
        viewModelScope.launch {
            try {
                val list = stickerRepository.getStickers()
                _stickers.value = list
            } catch (_: Exception) {
                // 忽略加载失败
            } finally {
                _loadingStickers.value = false
            }
        }
    }

    // 发送贴纸（作为图片评论）
    fun sendSticker(postId: String, url: String) {
        if (_isPosting.value) return
        _isPosting.value = true
        viewModelScope.launch {
            try {
                val parentId = _replyToCommentId.value
                val resp = repository.postComment(postId, url, parentId)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    val newComment = resp.body()!!.data
                    _comments.value = listOf(newComment) + _comments.value
                    _commentText.value = ""
                    _replyingTo.value = null
                    _replyToCommentId.value = null
                    _detail.value?.let { d -> _detail.value = d.copy(commentCount = d.commentCount + 1) }
                }
            } catch (_: Exception) {
                // 静默失败
            } finally {
                _isPosting.value = false
                _showStickerPicker.value = false
            }
        }
    }
}
