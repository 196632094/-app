package com.xxla.mh.ui.screens.profile

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.xxla.mh.util.UrlUtils
import com.xxla.mh.ui.theme.AppBackground

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FollowersScreen(
    userId: String,
    onBackClick: () -> Unit,
    onUserClick: (String) -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val followers by viewModel.followers.collectAsState()

    LaunchedEffect(userId) {
        viewModel.loadFollowers(userId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "粉丝") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .background(AppBackground)
        ) {
            if (followers.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "暂无粉丝", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    items(followers) { user ->
                        UserRowItem(
                            avatarUrl = user.avatar,
                            displayName = user.nickname ?: user.username,
                            userId = user.id,
                            lover = com.xxla.mh.ui.components.isLover(user.id),
                            isFollowing = user.isFollowing == true,
                            onClick = { onUserClick(user.id) },
                            onToggleFollow = { viewModel.toggleFollowInFollowersList(user.id, user.isFollowing == true) }
                        )
                    }
            }
        }
    }
}
}

@Composable
private fun UserRowItem(
    avatarUrl: String?,
    displayName: String,
    userId: String,
    lover: Boolean = false,
    isFollowing: Boolean = false,
    onClick: () -> Unit,
    onToggleFollow: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = UrlUtils.toAbsolute(avatarUrl ?: ""),
                contentDescription = "头像",
                modifier = Modifier
                    .size(40.dp)
                    .clip(MaterialTheme.shapes.small)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    if (lover) {
                        Spacer(modifier = Modifier.width(6.dp))
                        com.xxla.mh.ui.components.LoverTag(userId)
                    }
                }
            }

            // 右侧：关注状态操作
            Spacer(modifier = Modifier.width(8.dp))
            if (!isFollowing) {
                Button(onClick = onToggleFollow) {
                    Text("回关")
                }
            } else {
                OutlinedButton(onClick = onToggleFollow) {
                    Text("已关注")
                }
            }
        }
    }
}
