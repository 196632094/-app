package com.xxla.mh.ui.screens.profile

import com.xxla.mh.network.AddHistoryRequest
import com.xxla.mh.network.HistoryApiService
import com.xxla.mh.util.UrlUtils
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton
import java.text.SimpleDateFormat
import java.util.*

/**
 * 历史记录数据仓库（云端存储）
 */
@Singleton
class HistoryRepository @Inject constructor(
    private val historyApiService: HistoryApiService
) {

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault())
    private val displayFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    /**
     * 获取历史记录列表（从云端）
     */
    suspend fun getHistoryItems(): List<HistoryItem> {
        val resp = historyApiService.getHistory()
        val body = resp.body()
        if (resp.isSuccessful && body != null && body.success) {
            return body.data.history.map { remote ->
                HistoryItem(
                    id = remote.id,
                    videoId = remote.videoId,
                    title = remote.title,
                    thumbnailUrl = UrlUtils.toAbsolute(remote.thumbnailUrl),
                    authorName = remote.authorName ?: "未知作者",
                    watchTime = formatDisplayTime(remote.watchTime),
                    watchedDuration = (remote.watchedDuration ?: 0),
                    totalDuration = (remote.totalDuration ?: 0)
                )
            }
        } else {
            throw RuntimeException(body?.message ?: "获取历史记录失败")
        }
    }

    /**
     * 删除单个历史记录（云端）
     */
    suspend fun removeHistoryItem(id: String) {
        val resp = historyApiService.delete(id)
        if (!resp.isSuccessful || resp.body()?.success != true) {
            throw RuntimeException(resp.body()?.message ?: "删除失败")
        }
    }

    /**
     * 清空所有历史记录（云端）
     */
    suspend fun clearAllHistory() {
        val resp = historyApiService.clearAll()
        if (!resp.isSuccessful || resp.body()?.success != true) {
            throw RuntimeException(resp.body()?.message ?: "清空失败")
        }
    }

    /**
     * 添加或更新历史记录（云端）
     */
    suspend fun addHistoryItem(historyItem: HistoryItem) {
        val req = AddHistoryRequest(
            videoId = historyItem.videoId,
            watchedDuration = historyItem.watchedDuration,
            totalDuration = historyItem.totalDuration
        )
        val resp = historyApiService.addOrUpdate(req)
        if (!resp.isSuccessful || resp.body()?.success != true) {
            throw RuntimeException(resp.body()?.message ?: "记录历史失败")
        }
        // 轻微延迟以等待后端写入（本地UI已先行更新）
        delay(50)
    }

    private fun formatDisplayTime(iso: String?): String {
        if (iso.isNullOrBlank()) return displayFormat.format(Date())
        val patterns = listOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
            "yyyy-MM-dd'T'HH:mm:ssXXX"
        )
        for (p in patterns) {
            try {
                val sdf = SimpleDateFormat(p, Locale.getDefault())
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val d = sdf.parse(iso)
                if (d != null) return displayFormat.format(d)
            } catch (_: Exception) {}
        }
        return displayFormat.format(Date())
    }
}
