package com.xxla.mh.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

/**
 * 历史记录界面的ViewModel
 */
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val historyRepository: HistoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        loadHistory()
    }

    /**
     * 加载历史记录
     */
    fun loadHistory() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            try {
                val historyItems = historyRepository.getHistoryItems()
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        historyItems = historyItems
                    )
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = "加载历史记录失败: ${e.message}"
                    )
                }
            }
        }
    }

    /**
     * 删除单个历史记录
     */
    fun removeHistoryItem(id: String) {
        viewModelScope.launch {
            try {
                historyRepository.removeHistoryItem(id)
                // 更新UI状态，移除已删除的项目
                _uiState.update { currentState ->
                    currentState.copy(
                        historyItems = currentState.historyItems.filter { it.id != id }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "删除历史记录失败: ${e.message}") }
            }
        }
    }

    /**
     * 清空所有历史记录
     */
    fun clearHistory() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            try {
                historyRepository.clearAllHistory()
                _uiState.update { it.copy(isLoading = false, historyItems = emptyList()) }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = "清空历史记录失败: ${e.message}"
                    )
                }
            }
        }
    }

    /**
     * 添加或更新单条历史记录
     */
    fun addHistoryItem(item: HistoryItem) {
        viewModelScope.launch {
            try {
                historyRepository.addHistoryItem(item)
                // 从云端重新拉取，确保ID等与服务端一致
                val latest = historyRepository.getHistoryItems()
                _uiState.update { current -> current.copy(historyItems = latest) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "添加历史记录失败: ${e.message}") }
            }
        }
    }
}

/**
 * 历史记录界面的UI状态
 */
data class HistoryUiState(
    val isLoading: Boolean = false,
    val historyItems: List<HistoryItem> = emptyList(),
    val error: String? = null
)
