package com.xxla.mh.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.ui.components.LoadingIndicator
import com.xxla.mh.ui.components.ErrorView
import com.xxla.mh.ui.theme.ResponsiveUtils

/**
 * 消息中心界面
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageCenterScreen(
    navController: NavController,
    viewModel: MessageViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val horizontalPadding = ResponsiveUtils.getHorizontalPadding()
    
    var showClearDialog by remember { mutableStateOf(false) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("消息中心") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { showClearDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "清空消息")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (uiState.isLoading) {
                LoadingIndicator()
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = horizontalPadding)
                ) {
                    // 消息类型选项卡
                    TabRow(
                        selectedTabIndex = uiState.selectedTabIndex,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        MessageType.values().forEachIndexed { index, type ->
                            Tab(
                                selected = uiState.selectedTabIndex == index,
                                onClick = { viewModel.selectTab(index) },
                                text = { Text(type.title) }
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // 消息列表
                    if (uiState.messages.isEmpty()) {
                        // 空状态
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "暂无消息",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(vertical = 16.dp)
                        ) {
                            items(uiState.messages) { message ->
                                MessageItem(
                                    message = message,
                                    onClick = { 
                                        // 标记为已读
                                        viewModel.markAsRead(message.id)
                                        
                                        // 根据消息类型导航到相应页面
                                        when (message.type) {
                                            MessageType.LIKE, MessageType.COMMENT -> {
                                                // 点赞/评论应进入原帖详情，而不是视频播放
                                                navController.navigate(
                                                    com.xxla.mh.navigation.Screen.PostDetail.createRoute(message.relatedId)
                                                )
                                            }
                                            MessageType.FOLLOW -> {
                                                navController.navigate("user_profile/${message.senderId}")
                                            }
                                            MessageType.SYSTEM -> {
                                                // 系统消息可能不需要导航
                                            }
                                        }
                                    },
                                    onDelete = { viewModel.deleteMessage(message.id) }
                                )
                            }
                        }
                    }
                }
            }
            
            // 错误提示
            if (uiState.error != null) {
                ErrorView(
                    message = uiState.error!!,
                    onRetry = { viewModel.loadMessages() }
                )
            }
        }
    }
    
    // 清空消息确认对话框
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("清空消息") },
            text = { Text("确定要清空所有消息吗？此操作不可恢复。") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllMessages()
                        showClearDialog = false
                    }
                ) {
                    Text("确定")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showClearDialog = false }
                ) {
                    Text("取消")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageItem(
    message: Message,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 发送者头像
            AsyncImage(
                model = com.xxla.mh.util.UrlUtils.toAbsolute(message.senderAvatar),
                contentDescription = null,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
            
            Spacer(modifier = Modifier.width(12.dp))
            
            // 消息内容
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = message.senderName,
                        style = MaterialTheme.typography.titleSmall
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    // 消息类型标签
                    Box(
                        modifier = Modifier
                            .background(
                                color = when (message.type) {
                                    MessageType.LIKE -> Color(0xFFE91E63)
                                    MessageType.COMMENT -> Color(0xFF2196F3)
                                    MessageType.FOLLOW -> Color(0xFF4CAF50)
                                    MessageType.SYSTEM -> Color(0xFFFF9800)
                                },
                                shape = MaterialTheme.shapes.small
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = message.type.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    // 未读标记
                    if (!message.isRead) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color.Red, CircleShape)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = message.time,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            // 删除按钮
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "删除",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

/**
 * 消息类型枚举
 */
enum class MessageType(val title: String) {
    LIKE("点赞"),
    COMMENT("评论"),
    FOLLOW("关注"),
    SYSTEM("系统")
}

/**
 * 消息数据类
 */
data class Message(
    val id: String,
    val type: MessageType,
    val senderId: String,
    val senderName: String,
    val senderAvatar: String,
    val content: String,
    val time: String,
    val isRead: Boolean,
    val relatedId: String // 相关内容ID，如视频ID
)
