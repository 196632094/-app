package com.xxla.mh.ui.screens.profile

import com.xxla.mh.network.MessageApiService
import com.xxla.mh.network.MessageItem
import javax.inject.Inject
import javax.inject.Singleton

/**
 * 消息中心数据仓库（接入真实后端API）
 */
@Singleton
class MessageRepository @Inject constructor(
    private val messageApiService: MessageApiService
) {

    /**
     * 获取指定类型的消息
     */
    suspend fun getMessages(type: MessageType): List<Message> {
        val typeParam = when (type) {
            MessageType.LIKE -> "like"
            MessageType.COMMENT -> "comment"
            MessageType.FOLLOW -> "follow"
            MessageType.SYSTEM -> "system"
        }
        val resp = messageApiService.getMessages(typeParam)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception("获取消息失败: ${resp.errorBody()?.string() ?: resp.message()}")
        }
        val list = resp.body()!!.data.messages
        return list.map { it.toUiMessage() }
    }

    /**
     * 标记消息为已读
     */
    suspend fun markAsRead(messageId: String) {
        val resp = messageApiService.markAsRead(messageId)
        if (!resp.isSuccessful) {
            throw Exception("标记已读失败: ${resp.errorBody()?.string() ?: resp.message()}")
        }
    }

    /**
     * 删除单条消息
     */
    suspend fun deleteMessage(messageId: String) {
        val resp = messageApiService.deleteMessage(messageId)
        if (!resp.isSuccessful) {
            throw Exception("删除消息失败: ${resp.errorBody()?.string() ?: resp.message()}")
        }
    }

    /**
     * 清空所有消息
     */
    suspend fun clearAllMessages() {
        val resp = messageApiService.clearAllMessages()
        if (!resp.isSuccessful) {
            throw Exception("清空消息失败: ${resp.errorBody()?.string() ?: resp.message()}")
        }
    }

    /**
     * 获取未读消息数量
     */
    suspend fun getUnreadCount(): Int {
        val resp = messageApiService.getUnreadCount()
        if (!resp.isSuccessful || resp.body() == null) return 0
        return resp.body()!!.data.count
    }

    private fun MessageItem.toUiMessage(): Message {
        val typeEnum = when (type.lowercase()) {
            "like" -> MessageType.LIKE
            "comment" -> MessageType.COMMENT
            "follow" -> MessageType.FOLLOW
            "system" -> MessageType.SYSTEM
            else -> MessageType.SYSTEM
        }
        return Message(
            id = id,
            type = typeEnum,
            senderId = senderId ?: "",
            senderName = senderName ?: "",
            senderAvatar = senderAvatar ?: "",
            content = content ?: "",
            time = time ?: formatTimestamp(timestamp),
            isRead = false, // 后端可返回isRead，当前模型无则默认false
            relatedId = relatedId ?: ""
        )
    }

    private fun formatTimestamp(ts: Long?): String {
        if (ts == null) return ""
        return try {
            val diff = System.currentTimeMillis() - ts
            val minute = 60_000L
            val hour = 60 * minute
            val day = 24 * hour
            when {
                diff < minute -> "刚刚"
                diff < hour -> "${diff / minute}分钟前"
                diff < day -> "${diff / hour}小时前"
                else -> "${diff / day}天前"
            }
        } catch (e: Exception) {
            ""
        }
    }
}
