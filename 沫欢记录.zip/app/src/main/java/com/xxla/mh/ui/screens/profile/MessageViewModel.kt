package com.xxla.mh.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 消息中心的ViewModel
 */
@HiltViewModel
class MessageViewModel @Inject constructor(
    private val messageRepository: MessageRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(MessageUiState())
    val uiState: StateFlow<MessageUiState> = _uiState.asStateFlow()

    init {
        loadMessages()
    }

    /**
     * 加载消息
     */
    fun loadMessages() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            try {
                val messages = messageRepository.getMessages(MessageType.values()[_uiState.value.selectedTabIndex])
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        messages = messages
                    )
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = "加载消息失败: ${e.message}"
                    )
                }
            }
        }
    }

    /**
     * 选择消息类型标签
     */
    fun selectTab(index: Int) {
        if (_uiState.value.selectedTabIndex != index) {
            _uiState.update { it.copy(selectedTabIndex = index) }
            loadMessages()
        }
    }

    /**
     * 标记消息为已读
     */
    fun markAsRead(messageId: String) {
        viewModelScope.launch {
            try {
                messageRepository.markAsRead(messageId)
                // 更新UI状态
                _uiState.update { currentState ->
                    val updatedMessages = currentState.messages.map { message ->
                        if (message.id == messageId) message.copy(isRead = true) else message
                    }
                    currentState.copy(messages = updatedMessages)
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "标记消息已读失败: ${e.message}") }
            }
        }
    }

    /**
     * 删除单条消息
     */
    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            try {
                messageRepository.deleteMessage(messageId)
                // 更新UI状态，移除已删除的消息
                _uiState.update { currentState ->
                    currentState.copy(
                        messages = currentState.messages.filter { it.id != messageId }
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "删除消息失败: ${e.message}") }
            }
        }
    }

    /**
     * 清空所有消息
     */
    fun clearAllMessages() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            try {
                messageRepository.clearAllMessages()
                _uiState.update { it.copy(isLoading = false, messages = emptyList()) }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isLoading = false,
                        error = "清空消息失败: ${e.message}"
                    )
                }
            }
        }
    }
}

/**
 * 消息中心UI状态
 */
data class MessageUiState(
    val isLoading: Boolean = false,
    val selectedTabIndex: Int = 0, // 默认选中第一个标签
    val messages: List<Message> = emptyList(),
    val error: String? = null
)