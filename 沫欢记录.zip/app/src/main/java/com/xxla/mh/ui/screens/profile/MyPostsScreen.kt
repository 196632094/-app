package com.xxla.mh.ui.screens.profile

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import com.xxla.mh.navigation.Screen
import com.xxla.mh.ui.screens.auth.AuthViewModel
import com.xxla.mh.ui.screens.home.HomeViewModel
import com.xxla.mh.ui.screens.home.PostCard
import com.xxla.mh.ui.screens.home.VideoCard
import java.time.Instant
import java.time.format.DateTimeParseException

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyPostsScreen(
    navController: NavController,
    homeViewModel: HomeViewModel = hiltViewModel(),
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val uiState by homeViewModel.uiState.collectAsState()
    val authState by authViewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var pendingDeletePostId by remember { mutableStateOf<String?>(null) }
    var pendingDeleteVideoId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        // 刷新帖子与视频，确保“我的动态”包含我发布的全部内容
        homeViewModel.refreshPosts()
        homeViewModel.refreshVideos()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("我的动态") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        val uid = authState.user?.id
        // 合并“我的视频 + 我的帖子”，按发布时间倒序
        val myFeed = remember(uiState.videos, uiState.posts, uid) {
            val entries = mutableListOf<Pair<Long, Any>>()
            if (uid != null) {
                uiState.videos.filter { it.authorId == uid }.forEach { v ->
                    entries.add(v.publishTime to v)
                }
                uiState.posts.filter { it.author?.id == uid }.forEach { p ->
                    val ts = try { Instant.parse(p.createdAt ?: "").toEpochMilli() } catch (_: DateTimeParseException) { 0L }
                    entries.add(ts to p)
                }
            }
            entries.sortedByDescending { it.first }
        }

        if (myFeed.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                Text(
                    text = "还没有发布过作品",
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                items(myFeed) { (ts, item) ->
                    when (item) {
                        is com.xxla.mh.ui.screens.home.Video -> {
                            VideoCard(
                                video = item,
                                onVideoClick = { videoId ->
                                    navController.navigate(Screen.VideoPlayer.createRoute(videoId))
                                },
                                onUserClick = { userId ->
                                    navController.navigate("user_profile/$userId")
                                },
                                onLikeClick = { vid ->
                                    homeViewModel.toggleLike(vid)
                                },
                                navController = navController,
                                showManageActions = true,
                                onDeleteClick = { vid -> pendingDeleteVideoId = vid }
                            )
                        }
                        is com.xxla.mh.ui.screens.home.Post -> {
                            PostCard(
                                post = item,
                                onClick = { postId ->
                                    navController.navigate(Screen.PostDetail.createRoute(postId))
                                },
                                navController = navController,
                                onLikeClick = { pid ->
                                    homeViewModel.togglePostLike(pid)
                                },
                                showManageActions = true,
                                onDeleteClick = { postId -> pendingDeletePostId = postId },
                                onEditClick = { postId ->
                                    navController.navigate(Screen.EditPost.createRoute(postId))
                                }
                            )
                        }
                    }
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.padding(top = 16.dp))
                }
            }
        }
    }
    // 删除视频确认
    if (pendingDeleteVideoId != null) {
        AlertDialog(
            onDismissRequest = { pendingDeleteVideoId = null },
            title = { Text("确认删除") },
            text = { Text("删除后无法恢复，确定删除此内容吗？") },
            confirmButton = {
                TextButton(onClick = {
                    val id = pendingDeleteVideoId
                    if (id != null) {
                        homeViewModel.deleteVideo(id)
                    }
                    pendingDeleteVideoId = null
                }) { Text("删除") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteVideoId = null }) { Text("取消") }
            }
        )
    }
    // 删除帖子确认
    if (pendingDeletePostId != null) {
        AlertDialog(
            onDismissRequest = { pendingDeletePostId = null },
            title = { Text("确认删除") },
            text = { Text("删除后无法恢复，确定删除此内容吗？") },
            confirmButton = {
                TextButton(onClick = {
                    val id = pendingDeletePostId
                    if (id != null) {
                        homeViewModel.deletePost(id)
                    }
                    pendingDeletePostId = null
                }) { Text("删除") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeletePostId = null }) { Text("取消") }
            }
        )
    }
    // 监听从编辑返回的刷新和提示
    LaunchedEffect(navController) {
        snapshotFlow { navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>("my_posts_refresh") ?: false }
            .collect { refresh ->
                if (refresh) {
                    homeViewModel.refreshPosts()
                    navController.currentBackStackEntry?.savedStateHandle?.set("my_posts_refresh", false)
                }
            }
    }
    LaunchedEffect(navController) {
        snapshotFlow { navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>("my_posts_edit_success") ?: false }
            .collect { show ->
                if (show) {
                    scope.launch { snackbarHostState.showSnackbar("已更新") }
                    navController.currentBackStackEntry?.savedStateHandle?.set("my_posts_edit_success", false)
                }
            }
    }
    // 监听删除成功/失败消息
    LaunchedEffect(homeViewModel) {
        homeViewModel.messages.collect { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg) }
        }
    }
}
