package com.xxla.mh.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.xxla.mh.navigation.Screen
import com.xxla.mh.ui.screens.home.VideoCard
import com.xxla.mh.ui.screens.home.HomeViewModel
import com.xxla.mh.ui.screens.home.Video
import com.xxla.mh.ui.screens.auth.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyVideosScreen(
    navController: NavController,
    homeViewModel: HomeViewModel = hiltViewModel(),
    authViewModel: AuthViewModel = hiltViewModel()
) {
    val uiState by homeViewModel.uiState.collectAsState()
    // 观察登录状态，确保用户信息变化时页面能正确刷新过滤
    val authState by authViewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    var pendingDeleteVideoId by remember { mutableStateOf<String?>(null) }

    // 进入页面时刷新，确保展示最新作品
    LaunchedEffect(Unit) {
        homeViewModel.refreshVideos()
    }
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("我的视频") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        val myVideos: List<Video> = authState.user?.id?.let { uid ->
            uiState.videos.filter { it.authorId == uid }
        } ?: emptyList()

        if (myVideos.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "暂无作品",
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            androidx.compose.foundation.lazy.LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(16.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                items(myVideos.size) { index ->
                    val video = myVideos[index]
                    VideoCard(
                        video = video,
                        onVideoClick = { videoId ->
                            navController.navigate(Screen.VideoPlayer.createRoute(videoId))
                        },
                        onUserClick = { userId ->
                            navController.navigate("user_profile/$userId")
                        },
                        onLikeClick = { vid ->
                            homeViewModel.toggleLike(vid)
                        },
                        navController = navController,
                        showManageActions = true,
                        onDeleteClick = { vid ->
                            pendingDeleteVideoId = vid
                        }
                    )
                }
            }
        }
    }

    // 删除视频确认弹窗
    if (pendingDeleteVideoId != null) {
        AlertDialog(
            onDismissRequest = { pendingDeleteVideoId = null },
            title = { Text("确认删除") },
            text = { Text("删除后无法恢复，确定删除此内容吗？") },
            confirmButton = {
                TextButton(onClick = {
                    val id = pendingDeleteVideoId
                    if (id != null) {
                        homeViewModel.deleteVideo(id)
                    }
                    pendingDeleteVideoId = null
                }) { Text("删除") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteVideoId = null }) { Text("取消") }
            }
        )
    }

    // 监听从编辑返回的刷新和提示
    LaunchedEffect(navController) {
        snapshotFlow { navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>("my_videos_refresh") ?: false }
            .collect { refresh ->
                if (refresh) {
                    homeViewModel.refreshVideos()
                    navController.currentBackStackEntry?.savedStateHandle?.set("my_videos_refresh", false)
                }
            }
    }
    LaunchedEffect(navController) {
        snapshotFlow { navController.currentBackStackEntry?.savedStateHandle?.get<Boolean>("my_videos_edit_success") ?: false }
            .collect { show ->
                if (show) {
                    snackbarHostState.showSnackbar("已更新")
                    navController.currentBackStackEntry?.savedStateHandle?.set("my_videos_edit_success", false)
                }
            }
    }
}
