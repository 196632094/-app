package com.xxla.mh.ui.screens.profile

import com.xxla.mh.network.AddPostHistoryRequest
import com.xxla.mh.network.PostHistoryApiService
import com.xxla.mh.util.UrlUtils
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

/**
 * 帖子浏览历史数据仓库（云端存储）
 */
@Singleton
class PostHistoryRepository @Inject constructor(
    private val postHistoryApi: PostHistoryApiService
) {

    suspend fun addOrUpdate(postId: String) {
        val resp = postHistoryApi.addOrUpdate(AddPostHistoryRequest(postId))
        if (!resp.isSuccessful || resp.body()?.success != true) {
            throw RuntimeException(resp.body()?.message ?: "记录帖子历史失败")
        }
        // 轻微延迟以等待后端写入（与视频历史保持一致）
        delay(50)
    }

    suspend fun getPostHistory(): List<PostHistoryItem> {
        val resp = postHistoryApi.getPostHistory()
        val body = resp.body()
        if (resp.isSuccessful && body != null && body.success) {
            return body.data.history.map { remote ->
                PostHistoryItem(
                    id = remote.id,
                    postId = remote.postId,
                    title = remote.title,
                    coverUrl = UrlUtils.toAbsolute(remote.coverUrl),
                    authorName = remote.authorName ?: "未知作者",
                    readTime = remote.readTime ?: ""
                )
            }
        } else {
            throw RuntimeException(body?.message ?: "获取帖子历史失败")
        }
    }

    suspend fun delete(id: String) {
        val resp = postHistoryApi.delete(id)
        if (!resp.isSuccessful || resp.body()?.success != true) {
            throw RuntimeException(resp.body()?.message ?: "删除帖子历史失败")
        }
    }

    suspend fun clearAll() {
        val resp = postHistoryApi.clearAll()
        if (!resp.isSuccessful || resp.body()?.success != true) {
            throw RuntimeException(resp.body()?.message ?: "清空帖子历史失败")
        }
    }
}

data class PostHistoryItem(
    val id: String,
    val postId: String,
    val title: String,
    val coverUrl: String?,
    val authorName: String,
    val readTime: String
)
