package com.xxla.mh.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PostHistoryViewModel @Inject constructor(
    private val repository: PostHistoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PostHistoryUiState())
    val uiState: StateFlow<PostHistoryUiState> = _uiState.asStateFlow()

    init {
        loadHistory()
    }

    fun loadHistory() {
        _uiState.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            try {
                val items = repository.getPostHistory()
                _uiState.update { it.copy(isLoading = false, historyItems = items, error = null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "加载失败") }
            }
        }
    }

    fun deleteItem(id: String) {
        viewModelScope.launch {
            try {
                repository.delete(id)
                _uiState.update { state -> state.copy(historyItems = state.historyItems.filterNot { it.id == id }) }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "删除失败") }
            }
        }
    }

    fun clearAll() {
        _uiState.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            try {
                repository.clearAll()
                _uiState.update { it.copy(isLoading = false, historyItems = emptyList(), error = null) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message ?: "清空失败") }
            }
        }
    }
}

data class PostHistoryUiState(
    val isLoading: Boolean = false,
    val historyItems: List<PostHistoryItem> = emptyList(),
    val error: String? = null
)

