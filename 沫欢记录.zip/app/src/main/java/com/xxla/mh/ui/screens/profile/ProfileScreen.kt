package com.xxla.mh.ui.screens.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.R
import com.xxla.mh.data.User
import com.xxla.mh.ui.screens.auth.AuthViewModel
import com.xxla.mh.ui.components.UserAvatar
import com.xxla.mh.ui.theme.ThemeMode
import com.xxla.mh.ui.theme.ThemeViewModel

@Composable
private fun GuestCard(
    onLogin: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        // 未登录状态
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "未登录",
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "登录后享受更多功能",
                style = MaterialTheme.typography.titleMedium
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Button(
                onClick = onLogin,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("立即登录")
            }
        }
    }
}

@Composable
fun ProfileScreen(
    navController: NavController,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val authState by viewModel.authState.collectAsState()
    val authViewModel: AuthViewModel = hiltViewModel()
    val themeViewModel: ThemeViewModel = hiltViewModel()
    val themeMode by themeViewModel.themeMode.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showEditDialog by remember { mutableStateOf(false) }
    var newNickname by remember { mutableStateOf("") }

    LaunchedEffect(authState.user?.nickname, authState.user?.username) {
        val displayName = authState.user?.nickname?.takeIf { !it.isNullOrBlank() } ?: authState.user?.username ?: ""
        newNickname = displayName
    }

    // 加载用户统计（总获赞与作品数）
    LaunchedEffect(authState.user?.id) {
        val uid = authState.user?.id
        if (!uid.isNullOrEmpty()) {
            viewModel.loadUserStats(uid)
        }
    }

    // 选择图片并上传头像
    val pickImageLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { authViewModel.uploadAvatar(it) }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                // 用户信息卡片
                if (authState.isLoggedIn && authState.user != null) {
                    UserInfoCard(
                        user = authState.user!!,
                        onEditProfile = { showEditDialog = true },
                        onAvatarClick = { pickImageLauncher.launch("image/*") }
                    )
                } else {
                    GuestCard(
                        onLogin = { navController.navigate("login") }
                    )
                }
            }

            if (authState.isLoggedIn && authState.user != null) {
                item {
                    // 统计信息卡片
                    StatsCard(
                        followingCount = uiState.followingCount,
                        followersCount = uiState.followersCount,
                        likesCount = uiState.likesCount,
                        videosCount = uiState.videosCount,
                        onFollowingClick = {
                            val userId = authState.user!!.id
                            navController.navigate(com.xxla.mh.navigation.Screen.FollowingList.createRoute(userId))
                        },
                        onFollowersClick = {
                            val userId = authState.user!!.id
                            navController.navigate(com.xxla.mh.navigation.Screen.FollowersList.createRoute(userId))
                        }
                    )
                }
            }

            // 功能菜单
            item {
                MenuSection(
                    title = "我的内容",
                    items = listOf(
                        MenuItem("我的动态", Icons.Default.PlayArrow) {
                            navController.navigate("my_posts")
                        },
                        MenuItem("帖子历史", Icons.Default.History) {
                            navController.navigate("post_history_screen")
                        }
                    )
                )
            }

            item {
                MenuSection(
                    title = "互动消息",
                    items = listOf(
                        MenuItem("消息中心", Icons.Default.Notifications) {
                            navController.navigate("message_center_screen")
                        },
                        MenuItem("一起看", Icons.Default.PlayArrow) {
                            navController.navigate(com.xxla.mh.navigation.Screen.WatchTogether.route)
                        }
                    )
                )
            }

            // 主题选择
            item {
                ThemeSelectionCard(
                    currentMode = themeMode,
                    onSelectDefault = { themeViewModel.setTheme(ThemeMode.DEFAULT) },
                    onSelectDark = { themeViewModel.setTheme(ThemeMode.DARK) }
                )
            }

            item {
                MenuSection(
                    title = "设置",
                    items = listOf(
                        MenuItem("关于我们", Icons.Default.Info) {
                            navController.navigate("about")
                        }
                    )
                )
            }
            
            // 退出登录按钮
            if (authState.isLoggedIn) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.logout() }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = "退出登录",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "退出登录",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // 顶层覆盖层弹窗，避免 LazyColumn 虚拟化导致不显示
        if (showEditDialog) {
            AlertDialog(
                onDismissRequest = { showEditDialog = false },
                title = { Text("编辑资料") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = newNickname,
                            onValueChange = { newNickname = it },
                            singleLine = true,
                            label = { Text("昵称") },
                            placeholder = { Text("输入新的昵称") }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = { pickImageLauncher.launch("image/*") }) {
                                Icon(imageVector = Icons.Default.Image, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("更换头像")
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val nickname = newNickname.trim()
                        authViewModel.updateProfile(nickname.ifEmpty { null })
                        showEditDialog = false
                    }) {
                        Text("保存")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditDialog = false }) { Text("取消") }
                }
            )
        }
    }
}

@Composable
private fun ThemeSelectionCard(
    currentMode: ThemeMode,
    onSelectDefault: () -> Unit,
    onSelectDark: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "主题选择",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilterChip(
                    selected = currentMode == ThemeMode.DEFAULT,
                    onClick = onSelectDefault,
                    label = { Text("默认") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.LightMode,
                            contentDescription = null
                        )
                    }
                )
                FilterChip(
                    selected = currentMode == ThemeMode.DARK,
                    onClick = onSelectDark,
                    label = { Text("深色") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Outlined.DarkMode,
                            contentDescription = null
                        )
                    }
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "仅提供默认与深色两种主题",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun UserInfoCard(
    user: User,
    onEditProfile: () -> Unit,
    onAvatarClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        // 已登录状态
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 头像（支持相对路径与占位图）
                UserAvatar(
                    avatarUrl = user.avatar ?: "",
                    size = 64.dp,
                    onClick = onAvatarClick
                )
                
                Spacer(modifier = Modifier.width(16.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    val displayName = if (user.nickname.isNullOrBlank()) user.username else user.nickname
                    Text(
                        text = displayName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    
                    if (!user.signature.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = user.signature,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // 等级信息
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colorScheme.primary,
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "LV${user.level}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Text(
                            text = "UID: ${user.uid}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                // 编辑按钮
                IconButton(onClick = onEditProfile) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "编辑资料"
                    )
                }
            }
        }
    }
}

@Composable
private fun StatsCard(
    followingCount: Long,
    followersCount: Long,
    likesCount: Long,
    videosCount: Long,
    onFollowingClick: (() -> Unit)? = null,
    onFollowersClick: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            StatItem("关注", followingCount, onClick = onFollowingClick)
            StatItem("粉丝", followersCount, onClick = onFollowersClick)
            StatItem("获赞", likesCount)
            StatItem("作品", videosCount)
        }
    }
}

@Composable
private fun StatItem(
    label: String,
    count: Long,
    onClick: (() -> Unit)? = null
) {
    Column(
        modifier = if (onClick != null) Modifier.clickable { onClick() } else Modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = formatCount(count),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun MenuSection(
    title: String,
    items: List<MenuItem>
) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp, 16.dp, 16.dp, 8.dp)
            )
            
            items.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { item.onClick() }
                        .padding(16.dp, 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.weight(1f)
                    )
                    
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowRight,
                        contentDescription = "进入",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

data class MenuItem(
    val title: String,
    val icon: ImageVector,
    val onClick: () -> Unit
)

private fun formatCount(count: Long): String {
    return when {
        count >= 10000 -> "${count / 10000}万"
        count >= 1000 -> "${count / 1000}k"
        else -> count.toString()
    }
}
