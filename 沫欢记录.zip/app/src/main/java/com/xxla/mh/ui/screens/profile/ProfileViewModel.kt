package com.xxla.mh.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.User
import com.xxla.mh.data.UserPreferencesRepository
import com.xxla.mh.repository.AuthRepository
import com.xxla.mh.ui.screens.auth.AuthUiState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.xxla.mh.network.UserBriefWithRelation

data class ProfileUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val likesCount: Long = 0,
    val videosCount: Long = 0,
    val followersCount: Long = 0,
    val followingCount: Long = 0,
    val isFollowing: Boolean = false
)

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository,
    private val userPreferencesRepository: UserPreferencesRepository,
    private val profileRepository: com.xxla.mh.repository.ProfileRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    // 粉丝/关注列表状态
    private val _followers = MutableStateFlow<List<UserBriefWithRelation>>(emptyList())
    val followers: StateFlow<List<UserBriefWithRelation>> = _followers.asStateFlow()

    private val _following = MutableStateFlow<List<UserBriefWithRelation>>(emptyList())
    val following: StateFlow<List<UserBriefWithRelation>> = _following.asStateFlow()

    // 从 DataStore 派生鉴权状态，避免直接注入 ViewModel
    val authState = userPreferencesRepository.userPreferencesFlow
        .map { prefs ->
            AuthUiState(
                isLoading = false,
                isLoggedIn = prefs.isLoggedIn,
                user = if (prefs.isLoggedIn) User(
                    id = prefs.userId,
                    username = prefs.username,
                    email = prefs.email,
                    avatar = prefs.avatar,
                    nickname = prefs.nickname,
                    signature = prefs.signature,
                    level = prefs.level,
                    uid = prefs.uid,
                    followingCount = prefs.followingCount,
                    followersCount = prefs.followersCount,
                    likesCount = prefs.likesCount,
                    videosCount = prefs.videosCount
                ) else null,
                errorMessage = null
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AuthUiState()
        )

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
        }
    }

    fun loadUserStats(userId: String) {
        viewModelScope.launch {
            val result = profileRepository.getUserStats(userId)
            result.onSuccess { stats ->
                _uiState.value = _uiState.value.copy(
                    likesCount = stats.likesCount.toLong(),
                    videosCount = stats.videosCount.toLong(),
                    followersCount = stats.followersCount.toLong(),
                    followingCount = stats.followingCount.toLong(),
                    isFollowing = stats.isFollowing,
                    errorMessage = null
                )
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun toggleFollow(targetUserId: String) {
        viewModelScope.launch {
            val currentlyFollowing = _uiState.value.isFollowing
            val op = if (currentlyFollowing) profileRepository.unfollow(targetUserId) else profileRepository.follow(targetUserId)
            op.onSuccess {
                // 成功后刷新统计与状态
                loadUserStats(targetUserId)
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    // 在粉丝列表中直接切换关注状态（支持“回关”）
    fun toggleFollowInFollowersList(targetUserId: String, isFollowing: Boolean) {
        viewModelScope.launch {
            val op = if (isFollowing) profileRepository.unfollow(targetUserId) else profileRepository.follow(targetUserId)
            op.onSuccess {
                _followers.value = _followers.value.map { u ->
                    if (u.id == targetUserId) u.copy(isFollowing = !(u.isFollowing == true)) else u
                }
                _uiState.value = _uiState.value.copy(errorMessage = null)
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun loadFollowers(userId: String) {
        viewModelScope.launch {
            val result = profileRepository.getFollowers(userId)
            result.onSuccess { list ->
                _followers.value = list
                _uiState.value = _uiState.value.copy(errorMessage = null)
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }

    fun loadFollowing(userId: String) {
        viewModelScope.launch {
            val result = profileRepository.getFollowing(userId)
            result.onSuccess { list ->
                _following.value = list
                _uiState.value = _uiState.value.copy(errorMessage = null)
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(errorMessage = e.message)
            }
        }
    }
}
