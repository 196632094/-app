package com.xxla.mh.ui.screens.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.xxla.mh.ui.screens.home.HomeViewModel
import com.xxla.mh.ui.screens.home.Video
import com.xxla.mh.ui.screens.home.VideoCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    navController: NavController,
    userId: String,
    homeViewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by homeViewModel.uiState.collectAsState()

    // 进入页面时尝试刷新，确保列表最新
    LaunchedEffect(userId) {
        if (uiState.videos.isEmpty()) {
            homeViewModel.refreshVideos()
        }
    }

    TopLevelScaffold(
        navController = navController,
        content = {
            when {
                uiState.isLoading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                uiState.error != null -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "加载失败", style = MaterialTheme.typography.bodyLarge)
                            androidx.compose.material3.Button(onClick = { homeViewModel.refreshVideos() }) {
                                Text("重试")
                            }
                        }
                    }
                }
                else -> {
                    val userVideos: List<Video> = uiState.videos.filter { it.authorId == userId }
                    if (userVideos.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "该用户暂无作品", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "稍后再看看或返回",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            contentPadding = PaddingValues(vertical = 16.dp, horizontal = 16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(userVideos) { video ->
                                VideoCard(
                                    video = video,
                                    onVideoClick = { videoId ->
                                        navController.navigate(
                                            com.xxla.mh.navigation.Screen.VideoPlayer.createRoute(videoId)
                                        )
                                    },
                                    onUserClick = { /* 已在用户主页，无需再次跳转 */ },
                                    onLikeClick = { vid ->
                                        homeViewModel.toggleLike(vid)
                                    },
                                    navController = navController
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopLevelScaffold(
    navController: NavController,
    content: @Composable () -> Unit
) {
    androidx.compose.material3.Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("用户主页") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            content()
        }
    }
}
