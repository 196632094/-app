package com.xxla.mh.ui.screens.search

import com.xxla.mh.network.SearchApiService
import com.xxla.mh.network.UserApiService
import com.xxla.mh.util.UrlUtils
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SearchRepository @Inject constructor(
    private val searchApiService: SearchApiService,
    private val userApiService: UserApiService
) {
    // 简单的内存搜索历史（后续可接入本地存储）
    private val searchHistory = mutableListOf<String>()

    suspend fun searchVideos(query: String): List<VideoSearchResult> {
        val response = searchApiService.searchVideos(query = query)
        if (!response.isSuccessful || response.body() == null) {
            throw Exception("视频搜索失败: ${response.errorBody()?.string() ?: response.message()}")
        }
        val videos = response.body()!!.data.videos
        return videos.map { item ->
            VideoSearchResult(
                id = item.id,
                title = item.title,
                coverUrl = UrlUtils.toAbsolute(item.coverUrl ?: ""),
                videoUrl = UrlUtils.toAbsolute(item.videoUrl ?: ""),
                author = item.author?.username ?: (item.author?.nickname ?: "未知作者"),
                viewCount = formatCount(item.viewCount),
                duration = formatDuration(item.duration)
            )
        }
    }

    suspend fun searchUsers(query: String): List<UserSearchResult> {
        val response = searchApiService.searchUsers(query = query)
        if (!response.isSuccessful || response.body() == null) {
            throw Exception("用户搜索失败: ${response.errorBody()?.string() ?: response.message()}")
        }
        val users = response.body()!!.data.users
        return users.map { item ->
            UserSearchResult(
                id = item.id,
                username = item.username,
                avatarUrl = UrlUtils.toAbsolute(item.avatar ?: ""),
                followersCount = formatCount(item.followersCount),
                videosCount = (item.videosCount ?: 0).toString(),
                isFollowing = item.isFollowing ?: false
            )
        }
    }

    // 关注/取消关注（用于搜索结果列表）
    suspend fun follow(userId: String): Boolean {
        val resp = userApiService.follow(userId)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.success
    }

    suspend fun unfollow(userId: String): Boolean {
        val resp = userApiService.unfollow(userId)
        if (!resp.isSuccessful || resp.body() == null) {
            throw Exception(resp.errorBody()?.string() ?: resp.message())
        }
        return resp.body()!!.success
    }

    suspend fun getSearchHistory(): List<String> {
        return searchHistory.toList()
    }

    suspend fun saveSearchQuery(query: String) {
        if (searchHistory.contains(query)) {
            searchHistory.remove(query)
        }
        searchHistory.add(0, query)
        if (searchHistory.size > 10) {
            searchHistory.removeAt(searchHistory.size - 1)
        }
    }

    suspend fun clearSearchHistory() {
        searchHistory.clear()
    }

    private fun formatCount(count: Int?): String {
        val c = count ?: 0
        return when {
            c >= 10000 -> String.format("%.1f万", c / 10000.0)
            else -> c.toString()
        }
    }

    private fun formatDuration(seconds: Int?): String {
        val s = seconds ?: 0
        val m = s / 60
        val sec = s % 60
        return String.format("%d:%02d", m, sec)
    }
}
