package com.xxla.mh.ui.screens.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.MeasureScope
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.ui.components.ErrorView
import com.xxla.mh.ui.components.LoadingView
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import com.xxla.mh.ui.theme.ResponsiveUtils
import androidx.compose.ui.platform.LocalDensity
import com.xxla.mh.ui.theme.spacing

@OptIn(ExperimentalComposeUiApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    navController: NavController,
    viewModel: SearchViewModel = hiltViewModel()
) {
    val searchState by viewModel.searchState.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val keyboardController = LocalSoftwareKeyboardController.current
    val horizontalPadding = ResponsiveUtils.getHorizontalPadding()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("搜索") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = horizontalPadding)
        ) {
            // 搜索框
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                placeholder = { Text("搜索视频或用户") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "搜索") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.clearSearch() }) {
                            Icon(Icons.Default.Clear, contentDescription = "清除")
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        viewModel.search()
                        keyboardController?.hide()
                    }
                )
            )

            // 搜索类型选项卡
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { viewModel.updateSelectedTab(0) },
                    text = { Text("视频") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { viewModel.updateSelectedTab(1) },
                    text = { Text("用户") }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 搜索结果
            when (searchState) {
                is SearchState.Initial -> {
                    if (searchQuery.isEmpty()) {
                        SearchHistorySection(
                            history = viewModel.searchHistory,
                            onHistoryItemClick = { viewModel.searchWithHistoryItem(it) },
                            onClearHistory = { viewModel.clearSearchHistory() }
                        )
                    }
                }
                is SearchState.Loading -> {
                    LoadingView()
                }
                is SearchState.Success -> {
                    if (selectedTab == 0) {
                        // 视频搜索结果
                        val videos = (searchState as SearchState.Success).videos
                        if (videos.isEmpty()) {
                            EmptyResultView("没有找到相关视频")
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 160.dp),
                                contentPadding = PaddingValues(MaterialTheme.spacing.small),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(videos) { video ->
                                    VideoSearchResultItem(
                                        video = video,
                                        onClick = { navController.navigate("video_player/${video.id}") }
                                    )
                                }
                            }
                        }
                    } else {
                        // 用户搜索结果
                        val users = (searchState as SearchState.Success).users
                        if (users.isEmpty()) {
                            EmptyResultView("没有找到相关用户")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(users) { user ->
                                    UserSearchResultItem(
                                        user = user,
                                        onClick = { navController.navigate("user_profile/${user.id}") },
                                        onToggleFollow = { viewModel.toggleFollow(user.id, user.isFollowing) }
                                    )
                                }
                            }
                        }
                    }
                }
                is SearchState.Error -> {
                    ErrorView(
                        message = (searchState as SearchState.Error).message,
                        onRetry = { viewModel.search() }
                    )
                }
            }
        }
    }
}

@Composable
fun SearchHistorySection(
    history: List<String>,
    onHistoryItemClick: (String) -> Unit,
    onClearHistory: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        if (history.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "搜索历史",
                    style = MaterialTheme.typography.titleMedium
                )
                TextButton(onClick = onClearHistory) {
                    Text("清除")
                }
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                history.forEach { item ->
                    SuggestionChip(
                        onClick = { onHistoryItemClick(item) },
                        label = { Text(item) }
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "暂无搜索历史",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun FlowRow(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    content: @Composable () -> Unit
) {
    val density = LocalDensity.current
    
    Layout(
        content = content,
        modifier = modifier
    ) { measurables, constraints ->
        val rowConstraints = constraints.copy(minHeight = 0)
        val placeables = measurables.map { it.measure(rowConstraints) }
        
        val width = constraints.maxWidth
        val spacing = with(density) { 8.dp.toPx().toInt() }
        
        var totalHeight = 0
        var yPosition = 0
        var xPosition = 0
        var rowHeight = 0
        
        placeables.forEach { placeable: androidx.compose.ui.layout.Placeable ->
            if (xPosition + placeable.width > width) {
                xPosition = 0
                yPosition += rowHeight
                rowHeight = 0
            }
            xPosition += placeable.width + spacing
            rowHeight = kotlin.math.max(rowHeight, placeable.height)
            totalHeight = kotlin.math.max(totalHeight, yPosition + rowHeight)
        }
        
        layout(width, totalHeight) {
            var currentY = 0
            var currentX = 0
            var currentRowHeight = 0
            
            placeables.forEach { placeable: androidx.compose.ui.layout.Placeable ->
                if (currentX + placeable.width > width) {
                    currentX = 0
                    currentY += currentRowHeight
                    currentRowHeight = 0
                }
                
                placeable.place(currentX, currentY)
                // Split arithmetic to avoid any ambiguous operator resolution
                val pw: Int = placeable.width
                val ph: Int = placeable.height
                currentX = currentX + pw
                currentX = currentX + spacing
                currentRowHeight = kotlin.math.max(currentRowHeight, ph)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoSearchResultItem(
    video: VideoSearchResult,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = if (video.coverUrl.isNotBlank()) video.coverUrl else video.videoUrl,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            
            // 视频信息覆盖层
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter),
                color = Color.Black.copy(alpha = 0.6f)
            ) {
                Column(
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text(
                        text = video.title,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${video.author} · ${video.viewCount}次观看",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
fun UserSearchResultItem(
    user: UserSearchResult,
    onClick: () -> Unit,
    onToggleFollow: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = user.avatarUrl,
                contentDescription = user.username,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = user.username,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    if (com.xxla.mh.ui.components.isLover(user.id)) {
                        Spacer(modifier = Modifier.width(6.dp))
                        com.xxla.mh.ui.components.LoverTag(user.id)
                    }
                }
                Text(
                    text = "${user.followersCount}粉丝 · ${user.videosCount}作品",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            if (user.isFollowing) {
                OutlinedButton(onClick = onToggleFollow) {
                    Text("已关注")
                }
            } else {
                Button(onClick = onToggleFollow) {
                    Text("关注")
                }
            }
        }
    }
}

@Composable
fun EmptyResultView(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
