package com.xxla.mh.ui.screens.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val searchRepository: SearchRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedTab = MutableStateFlow(0) // 0: 视频, 1: 用户
    val selectedTab: StateFlow<Int> = _selectedTab

    private val _searchState = MutableStateFlow<SearchState>(SearchState.Initial)
    val searchState: StateFlow<SearchState> = _searchState

    private val _searchHistory = MutableStateFlow<List<String>>(emptyList())
    val searchHistory: List<String> get() = _searchHistory.value

    init {
        loadSearchHistory()
    }

    private fun loadSearchHistory() {
        viewModelScope.launch {
            _searchHistory.value = searchRepository.getSearchHistory()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSelectedTab(tab: Int) {
        if (_selectedTab.value != tab) {
            _selectedTab.value = tab
            if (_searchQuery.value.isNotEmpty()) {
                search()
            }
        }
    }

    fun search() {
        val query = _searchQuery.value.trim()
        if (query.isEmpty()) return

        viewModelScope.launch {
            _searchState.value = SearchState.Loading
            try {
                val result = if (_selectedTab.value == 0) {
                    // 搜索视频
                    val videos = searchRepository.searchVideos(query)
                    SearchState.Success(videos = videos, users = emptyList())
                } else {
                    // 搜索用户
                    val users = searchRepository.searchUsers(query)
                    SearchState.Success(videos = emptyList(), users = users)
                }
                _searchState.value = result
                
                // 保存搜索历史
                searchRepository.saveSearchQuery(query)
                loadSearchHistory()
            } catch (e: Exception) {
                _searchState.value = SearchState.Error("搜索失败: ${e.message}")
            }
        }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _searchState.value = SearchState.Initial
    }

    fun searchWithHistoryItem(query: String) {
        _searchQuery.value = query
        search()
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            searchRepository.clearSearchHistory()
            _searchHistory.value = emptyList()
        }
    }

    // 关注/取消关注（用于用户搜索结果）
    fun toggleFollow(userId: String, isFollowing: Boolean) {
        viewModelScope.launch {
            try {
                val ok = if (isFollowing) searchRepository.unfollow(userId) else searchRepository.follow(userId)
                if (ok) {
                    val current = _searchState.value
                    if (current is SearchState.Success) {
                        val updatedUsers = current.users.map { u ->
                            if (u.id == userId) u.copy(isFollowing = !isFollowing) else u
                        }
                        _searchState.value = current.copy(users = updatedUsers)
                    }
                }
            } catch (_: Exception) {
                // 保持当前界面状态，不打断搜索结果显示
            }
        }
    }
}

sealed class SearchState {
    object Initial : SearchState()
    object Loading : SearchState()
    data class Success(
        val videos: List<VideoSearchResult> = emptyList(),
        val users: List<UserSearchResult> = emptyList()
    ) : SearchState()
    data class Error(val message: String) : SearchState()
}

data class VideoSearchResult(
    val id: String,
    val title: String,
    val coverUrl: String,
    val videoUrl: String,
    val author: String,
    val viewCount: String,
    val duration: String
)

data class UserSearchResult(
    val id: String,
    val username: String,
    val avatarUrl: String,
    val followersCount: String,
    val videosCount: String,
    val isFollowing: Boolean
)
