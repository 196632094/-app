package com.xxla.mh.ui.screens.upload

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Article
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.xxla.mh.navigation.Screen
import com.xxla.mh.ui.screens.auth.AuthViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen(
    navController: NavController,
    viewModel: UploadViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val authViewModel: AuthViewModel = hiltViewModel()
    val authState by authViewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    
    // 监听上传成功事件：标记首页刷新与成功提示，并导航回首页
    LaunchedEffect(Unit) {
        viewModel.uploadSuccess.collect { _ ->
            val homeEntry = try {
                navController.getBackStackEntry(Screen.Home.route)
            } catch (e: Exception) { null }

            homeEntry?.savedStateHandle?.set("home_refresh", true)
            homeEntry?.savedStateHandle?.set("home_publish_success", true)

            navController.navigate(Screen.Home.route) {
                popUpTo(Screen.Home.route) { inclusive = false }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    // 监听错误并弹出提示
    LaunchedEffect(uiState.error) {
        uiState.error?.let { snackbarHostState.showSnackbar(it) }
    }
    
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    val titleText = when (uiState.publishType) {
                        PublishType.Video -> "发布视频"
                        PublishType.Article -> "发布文章"
                        PublishType.Images -> "发布图片"
                        PublishType.Music -> "发布音乐"
                    }
                    Text(titleText)
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            if (authState.isLoggedIn) {
                                viewModel.publish()
                            } else {
                                // 未登录引导到登录页，并提示
                                snackbarHostState.currentSnackbarData?.dismiss()
                                navController.navigate(Screen.Login.route)
                                // 在当前页也给个即时提示
                                scope.launch {
                                    snackbarHostState.showSnackbar("请先登录后再发布")
                                }
                            }
                        },
                        enabled = uiState.canPublish
                    ) {
                        Text("发布")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 发布类型选择
            PublishTypeSelector(
                current = uiState.publishType,
                onTypeChange = { viewModel.setPublishType(it) }
            )

            when (uiState.publishType) {
                PublishType.Video -> {
                    VideoSelectionCard(
                        selectedVideoUri = uiState.selectedVideoUri,
                        onVideoSelect = { viewModel.selectVideo(it) }
                    )
                    if (uiState.selectedVideoUri != null) {
                        VideoInfoEditor(
                            title = uiState.title,
                            description = uiState.description,
                            tags = uiState.tags,
                            onTitleChange = { viewModel.updateTitle(it) },
                            onDescriptionChange = { viewModel.updateDescription(it) },
                            onTagsChange = { viewModel.updateTags(it) }
                        )
                        CoverSelector(
                            coverUrl = uiState.coverUrl,
                            onCoverSelect = { viewModel.selectCover(it) }
                        )
                        PublishSettings(
                            isPublic = uiState.isPublic,
                            allowComments = uiState.allowComments,
                            onPublicChange = { viewModel.updatePublicSetting(it) },
                            onCommentsChange = { viewModel.updateCommentsSetting(it) }
                        )
                    }
                }
                PublishType.Article -> {
                    ArticleInfoEditor(
                        title = uiState.title,
                        content = uiState.content,
                        tags = uiState.tags,
                        onTitleChange = { viewModel.updateTitle(it) },
                        onContentChange = { viewModel.updateContent(it) },
                        onTagsChange = { viewModel.updateTags(it) }
                    )
                    ImageSelectionCard(
                        selectedImageUris = uiState.selectedImageUris,
                        onImagesSelect = { viewModel.selectImages(it) }
                    )
                    CoverSelector(
                        coverUrl = uiState.coverUrl,
                        onCoverSelect = { viewModel.selectCover(it) }
                    )
                    PublishSettings(
                        isPublic = uiState.isPublic,
                        allowComments = uiState.allowComments,
                        onPublicChange = { viewModel.updatePublicSetting(it) },
                        onCommentsChange = { viewModel.updateCommentsSetting(it) }
                    )
                }
                PublishType.Images -> {
                    ImageSelectionCard(
                        selectedImageUris = uiState.selectedImageUris,
                        onImagesSelect = { viewModel.selectImages(it) }
                    )
                    ImagesInfoEditor(
                        title = uiState.title,
                        description = uiState.description,
                        tags = uiState.tags,
                        onTitleChange = { viewModel.updateTitle(it) },
                        onDescriptionChange = { viewModel.updateDescription(it) },
                        onTagsChange = { viewModel.updateTags(it) }
                    )
                    CoverSelector(
                        coverUrl = uiState.coverUrl,
                        onCoverSelect = { viewModel.selectCover(it) }
                    )
                    PublishSettings(
                        isPublic = uiState.isPublic,
                        allowComments = uiState.allowComments,
                        onPublicChange = { viewModel.updatePublicSetting(it) },
                        onCommentsChange = { viewModel.updateCommentsSetting(it) }
                    )
                }
                PublishType.Music -> {
                    AudioSelectionCard(
                        selectedAudioUri = uiState.selectedAudioUri,
                        onAudioSelect = { viewModel.selectAudio(it) }
                    )
                    MusicInfoEditor(
                        title = uiState.title,
                        description = uiState.description,
                        tags = uiState.tags,
                        onTitleChange = { viewModel.updateTitle(it) },
                        onDescriptionChange = { viewModel.updateDescription(it) },
                        onTagsChange = { viewModel.updateTags(it) }
                    )
                    CoverSelector(
                        coverUrl = uiState.coverUrl,
                        onCoverSelect = { viewModel.selectCover(it) }
                    )
                    PublishSettings(
                        isPublic = uiState.isPublic,
                        allowComments = uiState.allowComments,
                        onPublicChange = { viewModel.updatePublicSetting(it) },
                        onCommentsChange = { viewModel.updateCommentsSetting(it) }
                    )
                }
            }
        }
    }
    
    // 加载状态
    if (uiState.isUploading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.padding(32.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(16.dp))
                    val uploadingText = when (uiState.publishType) {
                        PublishType.Video -> "正在上传视频..."
                        PublishType.Article -> "正在发布文章..."
                        PublishType.Images -> "正在上传图片..."
                        PublishType.Music -> "正在上传音乐..."
                    }
                    Text(uploadingText)
                    if (uiState.uploadProgress > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = uiState.uploadProgress / 100f,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("${uiState.uploadProgress}%")
                    }
                }
            }
        }
    }
}

@Composable
private fun PublishTypeSelector(
    current: PublishType,
    onTypeChange: (PublishType) -> Unit
) {
    Card {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "发布类型",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                FilterChip(
                    selected = current == PublishType.Video,
                    onClick = { onTypeChange(PublishType.Video) },
                    label = { Text("视频") }
                )
                FilterChip(
                    selected = current == PublishType.Article,
                    onClick = { onTypeChange(PublishType.Article) },
                    label = { Text("文章") }
                )
                FilterChip(
                    selected = current == PublishType.Images,
                    onClick = { onTypeChange(PublishType.Images) },
                    label = { Text("图片") }
                )
                FilterChip(
                    selected = current == PublishType.Music,
                    onClick = { onTypeChange(PublishType.Music) },
                    label = { Text("音乐") }
                )
            }
        }
    }
}

@Composable
private fun ImageSelectionCard(
    selectedImageUris: List<String>,
    onImagesSelect: (List<String>) -> Unit
) {
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        onImagesSelect(uris.filterNotNull().map { it.toString() })
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clickable { imagePicker.launch("image/*") },
        shape = RoundedCornerShape(12.dp)
    ) {
        if (selectedImageUris.isNotEmpty()) {
            Row(modifier = Modifier.fillMaxSize().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                selectedImageUris.take(3).forEach { uri ->
                    AsyncImage(
                        model = uri,
                        contentDescription = "选中图片",
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomEnd) {
                Text(
                    text = "已选择 ${selectedImageUris.size} 张",
                    modifier = Modifier
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.4f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    color = Color.White
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = "添加图片", modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("点击选择图片", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("支持JPG、PNG等格式", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun AudioSelectionCard(
    selectedAudioUri: String?,
    onAudioSelect: (String?) -> Unit
) {
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        onAudioSelect(uri?.toString())
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clickable { audioPicker.launch("audio/*") },
        shape = RoundedCornerShape(12.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
            Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(imageVector = Icons.Default.MusicNote, contentDescription = "音频", tint = MaterialTheme.colorScheme.primary)
                Text(
                    text = selectedAudioUri?.let { Uri.parse(it).lastPathSegment ?: "已选择音频" } ?: "点击选择音频文件",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
private fun ArticleInfoEditor(
    title: String,
    content: String,
    tags: List<String>,
    onTitleChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onTagsChange: (List<String>) -> Unit
) {
    Card {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(text = "文章内容", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = title,
                onValueChange = onTitleChange,
                label = { Text("文章标题") },
                placeholder = { Text("请输入文章标题") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )
            OutlinedTextField(
                value = content,
                onValueChange = onContentChange,
                label = { Text("文章正文") },
                placeholder = { Text("请输入正文，支持较长内容") },
                modifier = Modifier.fillMaxWidth().height(180.dp),
                maxLines = 10
            )
            OutlinedTextField(
                value = tags.joinToString(" "),
                onValueChange = { onTagsChange(it.split(" ").filter { t -> t.isNotBlank() }) },
                label = { Text("标签") },
                placeholder = { Text("请输入标签，用空格分隔") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ImagesInfoEditor(
    title: String,
    description: String,
    tags: List<String>,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onTagsChange: (List<String>) -> Unit
) {
    Card {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(text = "图片信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = title,
                onValueChange = onTitleChange,
                label = { Text("标题") },
                placeholder = { Text("请输入标题") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )
            OutlinedTextField(
                value = description,
                onValueChange = onDescriptionChange,
                label = { Text("描述") },
                placeholder = { Text("请输入描述") },
                modifier = Modifier.fillMaxWidth().height(120.dp),
                maxLines = 5
            )
            OutlinedTextField(
                value = tags.joinToString(" "),
                onValueChange = { onTagsChange(it.split(" ").filter { t -> t.isNotBlank() }) },
                label = { Text("标签") },
                placeholder = { Text("请输入标签，用空格分隔") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun MusicInfoEditor(
    title: String,
    description: String,
    tags: List<String>,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onTagsChange: (List<String>) -> Unit
) {
    Card {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(text = "音乐信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = title,
                onValueChange = onTitleChange,
                label = { Text("音乐标题") },
                placeholder = { Text("请输入音乐标题") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )
            OutlinedTextField(
                value = description,
                onValueChange = onDescriptionChange,
                label = { Text("音乐描述") },
                placeholder = { Text("介绍或歌词片段") },
                modifier = Modifier.fillMaxWidth().height(120.dp),
                maxLines = 5
            )
            OutlinedTextField(
                value = tags.joinToString(" "),
                onValueChange = { onTagsChange(it.split(" ").filter { t -> t.isNotBlank() }) },
                label = { Text("标签") },
                placeholder = { Text("请输入标签，用空格分隔") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun VideoSelectionCard(
    selectedVideoUri: String?,
    onVideoSelect: (String) -> Unit
) {
    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { onVideoSelect(it.toString()) }
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clickable { videoPicker.launch("video/*") },
        shape = RoundedCornerShape(12.dp)
    ) {
        if (selectedVideoUri != null) {
            // 显示选中的视频缩略图
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                AsyncImage(
                    model = selectedVideoUri,
                    contentDescription = "选中的视频",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // 播放按钮覆盖层
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "视频",
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
            }
        } else {
            // 视频选择提示
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(
                        2.dp,
                        MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "添加视频",
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "点击选择视频",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "支持MP4、AVI等格式",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoInfoEditor(
    title: String,
    description: String,
    tags: List<String>,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onTagsChange: (List<String>) -> Unit
) {
    Card {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "视频信息",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            // 标题输入
            OutlinedTextField(
                value = title,
                onValueChange = onTitleChange,
                label = { Text("视频标题") },
                placeholder = { Text("请输入视频标题") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 2
            )
            
            // 描述输入
            OutlinedTextField(
                value = description,
                onValueChange = onDescriptionChange,
                label = { Text("视频描述") },
                placeholder = { Text("请输入视频描述") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                maxLines = 5
            )
            
            // 标签输入
            OutlinedTextField(
                value = tags.joinToString(" "),
                onValueChange = { onTagsChange(it.split(" ").filter { tag -> tag.isNotBlank() }) },
                label = { Text("标签") },
                placeholder = { Text("请输入标签，用空格分隔") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun CoverSelector(
    coverUrl: String?,
    onCoverSelect: (String) -> Unit
) {
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { onCoverSelect(it.toString()) }
    }
    Card {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "封面设置",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 当前封面
                Box(
                    modifier = Modifier
                        .size(120.dp, 80.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { imagePicker.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    if (coverUrl != null) {
                        AsyncImage(
                            model = coverUrl,
                            contentDescription = "封面",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "添加封面"
                            )
                            Text(
                                text = "选择封面",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
                
                Column {
                    Text(
                        text = "建议尺寸：16:9",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "支持JPG、PNG格式",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun PublishSettings(
    isPublic: Boolean,
    allowComments: Boolean,
    onPublicChange: (Boolean) -> Unit,
    onCommentsChange: (Boolean) -> Unit
) {
    Card {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "发布设置",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            
            // 公开设置
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("公开视频")
                    Text(
                        text = "所有人都可以观看",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = isPublic,
                    onCheckedChange = onPublicChange
                )
            }
            
            // 评论设置
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("允许评论")
                    Text(
                        text = "观众可以发表评论",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = allowComments,
                    onCheckedChange = onCommentsChange
                )
            }
        }
    }
}
