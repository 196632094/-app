package com.xxla.mh.ui.screens.upload

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import com.xxla.mh.data.UploadRepository
import android.net.Uri

enum class PublishType { Video, Article, Images, Music }

data class UploadUiState(
    val selectedVideoUri: String? = null,
    val selectedImageUris: List<String> = emptyList(),
    val selectedAudioUri: String? = null,
    val publishType: PublishType = PublishType.Video,
    val title: String = "",
    val description: String = "",
    val content: String = "",
    val tags: List<String> = emptyList(),
    val coverUrl: String? = null,
    val isPublic: Boolean = true,
    val allowComments: Boolean = true,
    val isUploading: Boolean = false,
    val uploadProgress: Int = 0,
    val error: String? = null
) {
    val canPublish: Boolean
        get() = when (publishType) {
            PublishType.Video -> selectedVideoUri != null && title.isNotBlank() && !isUploading
            PublishType.Article -> (title.isNotBlank() || content.isNotBlank()) && !isUploading
            PublishType.Images -> selectedImageUris.isNotEmpty() && !isUploading
            PublishType.Music -> (selectedAudioUri != null && title.isNotBlank()) && !isUploading
        }
}

@HiltViewModel
class UploadViewModel @Inject constructor(
    private val uploadRepository: UploadRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(UploadUiState())
    val uiState: StateFlow<UploadUiState> = _uiState.asStateFlow()

    // 上传成功后的单次事件（携带新视频ID）
    private val _uploadSuccess = MutableSharedFlow<String>(replay = 0)
    val uploadSuccess: SharedFlow<String> = _uploadSuccess
    
    fun selectVideo(uri: String) {
        _uiState.value = _uiState.value.copy(
            selectedVideoUri = uri,
            error = null
        )
    }

    fun setPublishType(type: PublishType) {
        _uiState.value = _uiState.value.copy(publishType = type)
    }
    fun selectImages(uris: List<String>) {
        _uiState.value = _uiState.value.copy(selectedImageUris = uris, error = null)
    }
    fun selectAudio(uri: String?) {
        _uiState.value = _uiState.value.copy(selectedAudioUri = uri, error = null)
    }
    
    fun updateTitle(title: String) {
        _uiState.value = _uiState.value.copy(title = title)
    }
    
    fun updateDescription(description: String) {
        _uiState.value = _uiState.value.copy(description = description)
    }

    fun updateContent(content: String) {
        _uiState.value = _uiState.value.copy(content = content)
    }
    
    fun updateTags(tags: List<String>) {
        _uiState.value = _uiState.value.copy(tags = tags)
    }
    
    fun selectCover(coverUrl: String) {
        _uiState.value = _uiState.value.copy(coverUrl = coverUrl)
    }
    
    fun updatePublicSetting(isPublic: Boolean) {
        _uiState.value = _uiState.value.copy(isPublic = isPublic)
    }
    
    fun updateCommentsSetting(allowComments: Boolean) {
        _uiState.value = _uiState.value.copy(allowComments = allowComments)
    }

    fun publish() {
        val current = _uiState.value
        if (!current.canPublish) return
        when (current.publishType) {
            PublishType.Video -> publishVideo()
            PublishType.Article -> publishArticle()
            PublishType.Images -> publishImages()
            PublishType.Music -> publishMusic()
        }
    }

    private fun publishArticle() {
        val s = _uiState.value
        viewModelScope.launch {
            try {
                _uiState.value = s.copy(isUploading = true, uploadProgress = 0, error = null)
                val images = s.selectedImageUris.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }
                val cover = s.coverUrl?.let { runCatching { Uri.parse(it) }.getOrNull() }
                val flow = uploadRepository.uploadArticleWithImages(
                    title = s.title,
                    content = s.content,
                    tags = s.tags,
                    imageUris = images,
                    coverUri = cover,
                    isPublic = s.isPublic,
                    onProgress = { p -> _uiState.value = _uiState.value.copy(uploadProgress = (p * 100).toInt().coerceIn(0, 100)) }
                )
                flow.collect { result ->
                    result.onSuccess { id ->
                        _uiState.value = _uiState.value.copy(isUploading = false, uploadProgress = 100)
                        _uploadSuccess.emit(id)
                        resetUploadState()
                    }.onFailure { e -> throw e }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isUploading = false, error = e.message ?: "发布失败")
            }
        }
    }

    private fun publishImages() {
        val s = _uiState.value
        viewModelScope.launch {
            try {
                _uiState.value = s.copy(isUploading = true, uploadProgress = 0, error = null)
                val images = s.selectedImageUris.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }
                val cover = s.coverUrl?.let { runCatching { Uri.parse(it) }.getOrNull() }
                val flow = uploadRepository.uploadImagesOnly(
                    title = s.title,
                    description = s.description,
                    tags = s.tags,
                    imageUris = images,
                    coverUri = cover,
                    isPublic = s.isPublic,
                    onProgress = { p -> _uiState.value = _uiState.value.copy(uploadProgress = (p * 100).toInt().coerceIn(0, 100)) }
                )
                flow.collect { result ->
                    result.onSuccess { id ->
                        _uiState.value = _uiState.value.copy(isUploading = false, uploadProgress = 100)
                        _uploadSuccess.emit(id)
                        resetUploadState()
                    }.onFailure { e -> throw e }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isUploading = false, error = e.message ?: "发布失败")
            }
        }
    }

    private fun publishMusic() {
        val s = _uiState.value
        val audio = s.selectedAudioUri ?: return
        viewModelScope.launch {
            try {
                _uiState.value = s.copy(isUploading = true, uploadProgress = 0, error = null)
                val cover = s.coverUrl?.let { runCatching { Uri.parse(it) }.getOrNull() }
                val flow = uploadRepository.uploadMusic(
                    audioUri = Uri.parse(audio),
                    coverUri = cover,
                    title = s.title,
                    description = s.description,
                    tags = s.tags,
                    isPublic = s.isPublic,
                    onProgress = { p -> _uiState.value = _uiState.value.copy(uploadProgress = (p * 100).toInt().coerceIn(0, 100)) }
                )
                flow.collect { result ->
                    result.onSuccess { id ->
                        _uiState.value = _uiState.value.copy(isUploading = false, uploadProgress = 100)
                        _uploadSuccess.emit(id)
                        resetUploadState()
                    }.onFailure { e -> throw e }
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isUploading = false, error = e.message ?: "发布失败")
            }
        }
    }

    fun publishVideo() {
        val currentState = _uiState.value
        if (!currentState.canPublish) return
        
        viewModelScope.launch {
            try {
                _uiState.value = currentState.copy(
                    isUploading = true,
                    uploadProgress = 0,
                    error = null
                )
                
                val selectedUri = currentState.selectedVideoUri ?: throw Exception("请选择视频文件")
                val thumbnailUri = currentState.coverUrl?.let { runCatching { Uri.parse(it) }.getOrNull() }
                val resultFlow = uploadRepository.uploadVideo(
                    videoUri = Uri.parse(selectedUri),
                    thumbnailUri = thumbnailUri,
                    title = currentState.title,
                    description = currentState.description,
                    tags = currentState.tags,
                    isPublic = currentState.isPublic,
                    onProgress = { progress ->
                        val percent = (progress * 100).toInt().coerceIn(0, 100)
                        _uiState.value = _uiState.value.copy(uploadProgress = percent)
                    }
                )
                resultFlow.collect { result ->
                    result.onSuccess { videoId ->
                        _uiState.value = _uiState.value.copy(
                            isUploading = false,
                            uploadProgress = 100
                        )
                        // 发出上传成功事件供界面导航
                        _uploadSuccess.emit(videoId)
                        resetUploadState()
                    }.onFailure { e ->
                        throw e
                    }
                }
                
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isUploading = false,
                    error = e.message ?: "上传失败"
                )
            }
        }
    }
    
    private fun resetUploadState() {
        _uiState.value = UploadUiState()
    }
}
