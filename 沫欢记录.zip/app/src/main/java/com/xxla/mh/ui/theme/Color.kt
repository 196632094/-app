package com.xxla.mh.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6366F1) // 更新为与登录页面一致的主色调
val PurpleGrey40 = Color(0xFF8B5CF6) // 更新为与登录页面一致的辅助色
val Pink40 = Color(0xFF7D5260)

// 应用主题色
val AppPrimary = Color(0xFF6366F1)
val AppSecondary = Color(0xFF8B5CF6)
val AppBackground = Color(0xFFF5F5F5)