package com.xxla.mh.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * 响应式工具类，用于处理不同分辨率的适配
 */
object ResponsiveUtils {
    
    /**
     * 屏幕尺寸类型
     */
    enum class ScreenSizeType {
        COMPACT,    // 小屏幕 (手机竖屏)
        MEDIUM,     // 中等屏幕 (手机横屏或小平板)
        EXPANDED    // 大屏幕 (大平板或桌面)
    }
    
    /**
     * 获取当前屏幕尺寸类型
     */
    @Composable
    fun getScreenSizeType(): ScreenSizeType {
        val configuration = LocalConfiguration.current
        val screenWidthDp = configuration.screenWidthDp
        
        return when {
            screenWidthDp < 600 -> ScreenSizeType.COMPACT
            screenWidthDp < 840 -> ScreenSizeType.MEDIUM
            else -> ScreenSizeType.EXPANDED
        }
    }
    
    /**
     * 根据屏幕尺寸类型返回对应的值
     */
    @Composable
    fun <T> adaptiveValue(
        compactValue: T,
        mediumValue: T = compactValue,
        expandedValue: T = mediumValue
    ): T {
        return when (getScreenSizeType()) {
            ScreenSizeType.COMPACT -> compactValue
            ScreenSizeType.MEDIUM -> mediumValue
            ScreenSizeType.EXPANDED -> expandedValue
        }
    }
    
    /**
     * 根据屏幕尺寸类型返回对应的Dp值
     */
    @Composable
    fun adaptiveDp(
        compactDp: Dp,
        mediumDp: Dp = compactDp,
        expandedDp: Dp = mediumDp
    ): Dp {
        return adaptiveValue(compactDp, mediumDp, expandedDp)
    }
    
    /**
     * 获取适配的水平内边距
     */
    @Composable
    fun getHorizontalPadding(): Dp {
        return adaptiveDp(
            compactDp = 16.dp,
            mediumDp = 24.dp,
            expandedDp = 32.dp
        )
    }
    
    /**
     * 获取适配的垂直内边距
     */
    @Composable
    fun getVerticalPadding(): Dp {
        return adaptiveDp(
            compactDp = 12.dp,
            mediumDp = 16.dp,
            expandedDp = 20.dp
        )
    }
    
    /**
     * 获取瀑布流列数
     */
    @Composable
    fun getStaggeredGridColumns(): Int {
        return adaptiveValue(
            compactValue = 2,
            mediumValue = 3,
            expandedValue = 4
        )
    }
    
    /**
     * 获取列表项间距
     */
    @Composable
    fun getItemSpacing(): Dp {
        return adaptiveDp(
            compactDp = 8.dp,
            mediumDp = 12.dp,
            expandedDp = 16.dp
        )
    }

    /**
     * 是否为宽布局（非 COMPACT 视为宽屏）
     */
    @Composable
    fun isWideLayout(): Boolean {
        return getScreenSizeType() != ScreenSizeType.COMPACT
    }
}
