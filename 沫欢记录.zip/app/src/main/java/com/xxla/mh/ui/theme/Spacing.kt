package com.xxla.mh.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * 简单的间距扩展，提供 MaterialTheme.spacing 访问常用间距
 */
data class Spacing(
    val extraSmall: Dp = 4.dp,
    val small: Dp = 8.dp,
    val medium: Dp = 12.dp,
    val large: Dp = 16.dp,
    val extraLarge: Dp = 24.dp
)

/**
 * 为 MaterialTheme 提供 spacing 扩展属性
 */
val MaterialTheme.spacing: Spacing
    get() = Spacing()

