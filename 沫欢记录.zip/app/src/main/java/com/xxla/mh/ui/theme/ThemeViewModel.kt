package com.xxla.mh.ui.theme

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.UserPreferencesRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ThemeMode { DEFAULT, DARK }

@HiltViewModel
class ThemeViewModel @Inject constructor(
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {
    private val _themeMode: MutableStateFlow<ThemeMode> = MutableStateFlow(ThemeMode.DEFAULT)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    init {
        viewModelScope.launch {
            userPreferencesRepository.themeModeFlow.collect { mode ->
                _themeMode.value = if (mode == "dark") ThemeMode.DARK else ThemeMode.DEFAULT
            }
        }
    }

    fun setTheme(mode: ThemeMode) {
        viewModelScope.launch {
            val value = if (mode == ThemeMode.DARK) "dark" else "default"
            userPreferencesRepository.setThemeMode(value)
        }
    }
}

