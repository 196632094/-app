package com.xxla.mh.ui.update

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.xxla.mh.data.UpdateRepository
// 使用仓库提供的本地版本号，避免直接依赖 BuildConfig
import android.app.DownloadManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import javax.inject.Inject

data class UpdateUiState(
    val enabled: Boolean = false,
    val builtin: Boolean = false,
    val downloadUrl: String? = null,
    val showDialog: Boolean = false,
    val downloading: Boolean = false,
    val progress: Int = 0,
    val notes: String? = null,
    val error: String? = null,
    val canInstall: Boolean = false
)

@HiltViewModel
class UpdateViewModel @Inject constructor(
    private val updateRepository: UpdateRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(UpdateUiState())
    val uiState: StateFlow<UpdateUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val cfg = updateRepository.fetchUpdateConfig()
            if (cfg != null && cfg.enabled) {
                val serverVersion = cfg.version
                val localVersion = updateRepository.getLocalVersionName()
                val needUpdate = if (!serverVersion.isNullOrBlank()) {
                    isLocalVersionLess(localVersion, serverVersion)
                } else {
                    // 若后端未提供版本号，沿用“开启更新”作为兜底
                    true
                }
                if (needUpdate) {
                    _uiState.value = _uiState.value.copy(
                        enabled = true,
                        builtin = cfg.builtin,
                        downloadUrl = cfg.url,
                        notes = cfg.notes,
                        showDialog = true
                    )
                }
            }
        }
    }

    fun startUpdate() {
        val url = _uiState.value.downloadUrl ?: return
        viewModelScope.launch {
            try {
                // 已在下载中直接忽略，避免重复触发
                if (_uiState.value.downloading) return@launch
                // 已下载完成则触发安装而非重复下载
                if (_uiState.value.canInstall) {
                    updateRepository.installLastDownloadedApkIfAvailable()
                    return@launch
                }
                if (_uiState.value.builtin) {
                    _uiState.value = _uiState.value.copy(downloading = true, error = null, progress = 0)
                    var retries = 0
                    var id = updateRepository.startDownloadWithDownloadManager(url)
                    while (true) {
                        val info = updateRepository.queryDownloadProgress(id)
                        // 同步进度；若 DownloadManager 处于暂停或失败，展示友好原因提示
                        _uiState.value = _uiState.value.copy(
                            progress = info.percent,
                            error = when (info.status) {
                                DownloadManager.STATUS_PAUSED -> info.reason
                                else -> null
                            }
                        )
                        when (info.status) {
                            DownloadManager.STATUS_SUCCESSFUL -> {
                                // 下载完成后标记可安装，避免再次点击触发重复下载
                                _uiState.value = _uiState.value.copy(downloading = false, canInstall = true)
                                // 尝试直接调用安装，若系统权限或设置限制，用户仍可点击“立即安装”按钮
                                updateRepository.installLastDownloadedApkIfAvailable()
                                break
                            }
                            DownloadManager.STATUS_FAILED -> {
                                if (retries < 3) {
                                    retries += 1
                                    id = updateRepository.startDownloadWithDownloadManager(url)
                                } else {
                                    // DownloadManager 多次失败，切换到手动下载兜底
                                    _uiState.value = _uiState.value.copy(error = null, downloading = true, progress = 0)
                                    try {
                                        val file = updateRepository.downloadApk(url) { pct ->
                                            _uiState.value = _uiState.value.copy(progress = pct)
                                        }
                                        // 手动下载成功，尝试安装
                                        _uiState.value = _uiState.value.copy(downloading = false, canInstall = true)
                                        updateRepository.installLastDownloadedApkIfAvailable()
                                    } catch (e: Exception) {
                                        val msg = info.reason ?: (e.message ?: "下载失败，请稍后重试")
                                        _uiState.value = _uiState.value.copy(error = msg, downloading = false)
                                    }
                                    break
                                }
                            }
                            else -> {
                                // 运行中/暂停中，继续轮询
                                delay(500)
                            }
                        }
                    }
                } else {
                    updateRepository.openUrlInBrowser(url)
                    _uiState.value = _uiState.value.copy(error = null, downloading = false, progress = 0)
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(error = e.message ?: "无法打开浏览器", downloading = false)
            }
        }
    }

    fun installNow() {
        viewModelScope.launch {
            try {
                updateRepository.installLastDownloadedApkIfAvailable()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(error = e.message ?: "无法触发安装")
            }
        }
    }

    private fun isLocalVersionLess(local: String, remote: String): Boolean {
        fun parse(v: String): List<Int> = v.split('.', '_', '-').map { it.toIntOrNull() ?: 0 }
        val l = parse(local)
        val r = parse(remote)
        val max = maxOf(l.size, r.size)
        for (i in 0 until max) {
            val li = if (i < l.size) l[i] else 0
            val ri = if (i < r.size) r[i] else 0
            if (li < ri) return true
            if (li > ri) return false
        }
        return false
    }
}
