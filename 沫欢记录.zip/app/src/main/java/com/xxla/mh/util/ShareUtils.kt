package com.xxla.mh.util

import java.util.Locale

object ShareUtils {
    fun formatTimeLabel(positionMs: Long, locale: Locale = Locale.getDefault()): String {
        val totalSeconds = (positionMs / 1000).coerceAtLeast(0)
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) String.format(locale, "%02d:%02d:%02d", h, m, s)
        else String.format(locale, "%02d:%02d", m, s)
    }

    /**
     * 构造统一的分享文案。
     * 示例：邀请一起看《标题》｜进度：mm:ss｜链接：mh://...
     * 若 bilingual=true，将附加英文文案在下一行。
     */
    fun buildShareText(
        title: String,
        deepLink: String,
        positionMs: Long,
        locale: Locale = Locale.getDefault(),
        bilingual: Boolean = false
    ): String {
        val timeLabel = formatTimeLabel(positionMs, locale)
        val zhText = "邀请一起看《$title》｜进度：$timeLabel｜链接：$deepLink"
        if (!bilingual) return zhText
        val enText = "Watch together \"$title\" | Progress: $timeLabel | Link: $deepLink"
        return "$zhText\n$enText"
    }
}

