package com.xxla.mh.util

import com.xxla.mh.network.ApiConfig

object UrlUtils {
    /**
     * 将可能为相对路径的 URL 转为绝对地址。
     * - 已是 http/https 的直接返回
     * - 以 / 开头的拼接为 BASE + url
     * - 其他相对路径拼接为 BASE + "/" + url
     * - 空/空白字符串返回空字符串
     */
    fun toAbsolute(url: String?): String {
        val trimmed = url?.trim() ?: ""
        if (trimmed.isEmpty()) return trimmed
        val base = ApiConfig.API_BASE.trimEnd('/')
        return when {
            // 绝对地址：统一同域名的协议/端口差异，或内网/本地地址
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> {
                runCatching {
                    val uri = java.net.URI(trimmed)
                    val host = (uri.host ?: "").lowercase()
                    val scheme = (uri.scheme ?: "http").lowercase()
                    val apiUri = java.net.URI(base)
                    val apiHost = (apiUri.host ?: "").lowercase()
                    val apiScheme = (apiUri.scheme ?: "https").lowercase()
                    val path = (uri.rawPath ?: "") + (if (uri.rawQuery != null) "?${uri.rawQuery}" else "") + (if (uri.rawFragment != null) "#${uri.rawFragment}" else "")

                    val isPrivate = host == "localhost" || host == "127.0.0.1" || host.startsWith("10.") || host.startsWith("192.168.")
                    val isSameDomain = host == apiHost
                    val hasPort = (uri.port != -1)
                    val schemeDiffers = scheme != apiScheme

                    if (isPrivate || (isSameDomain && (schemeDiffers || hasPort))) {
                        base + (if (path.startsWith("/")) "" else "/") + path
                    } else {
                        trimmed
                    }
                }.getOrElse { trimmed }
            }
            // 相对路径：拼到统一 BASE
            trimmed.startsWith("/") -> base + trimmed
            else -> base + "/" + trimmed
        }
    }

    /**
     * 将 URL 的主域名规范化为后端统一的 `ApiConfig.API_BASE` 主域名，仅保留原始路径/查询/片段。
     * 用于内置更新下载等必须走同一主域的场景，避免后端误配跨域导致下载失败。
     * - 若传入为空，返回空字符串
     * - 若是绝对地址且主域与 BASE 不同，则替换为 BASE 主域，保留路径、查询、片段
     * - 其他情况（相对路径或同域），先转绝对再返回
     */
    fun toApiHost(url: String?): String {
        val abs = toAbsolute(url)
        if (abs.isEmpty()) return abs
        return runCatching {
            val uri = java.net.URI(abs)
            val base = java.net.URI(ApiConfig.API_BASE)
            val host = (uri.host ?: "").lowercase()
            val baseHost = (base.host ?: "").lowercase()
            val scheme = (base.scheme ?: "https").lowercase()
            val path = (uri.rawPath ?: "")
            val query = uri.rawQuery
            val fragment = uri.rawFragment

            if (host.isNotEmpty() && baseHost.isNotEmpty() && host != baseHost) {
                val sb = StringBuilder()
                sb.append(scheme).append("://").append(baseHost)
                if (path.isNotEmpty()) {
                    sb.append(if (path.startsWith("/")) "" else "/").append(path)
                }
                if (query != null) sb.append("?").append(query)
                if (fragment != null) sb.append("#").append(fragment)
                sb.toString()
            } else {
                abs
            }
        }.getOrElse { abs }
    }
}

