const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const app = express();
// 在反向代理后正确获取协议与客户端 IP
app.set('trust proxy', true);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const argvPortArg = (process && process.argv || []).find((a) => /^--port=\d+$/i.test(a));
const argvPort = argvPortArg ? Number(argvPortArg.split('=')[1]) : null;
const PORT = (argvPort && Number.isFinite(argvPort)) ? argvPort : (process.env.PORT ? Number(process.env.PORT) : 6687);
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';

// --- Storage setup ---
const DATA_DIR = path.join(__dirname, 'data');
const STORAGE_DIR = path.join(__dirname, 'storage');
const VIDEOS_DIR = path.join(STORAGE_DIR, 'videos');
const THUMBS_DIR = path.join(STORAGE_DIR, 'thumbnails');
const AVATARS_DIR = path.join(STORAGE_DIR, 'avatars');
// 新增图片与音乐存储目录
const IMAGES_DIR = path.join(STORAGE_DIR, 'images');
const MUSIC_DIR = path.join(STORAGE_DIR, 'music');
const ENJOY_DIR = path.join(STORAGE_DIR, 'enjoy');
[DATA_DIR, STORAGE_DIR, VIDEOS_DIR, THUMBS_DIR, AVATARS_DIR, IMAGES_DIR, MUSIC_DIR, ENJOY_DIR].forEach((d) => {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});
app.use('/storage', express.static(STORAGE_DIR));

// --- Preview static route ---
// Serve repository-level preview page for feature notes and verification steps
const PREVIEW_DIR = path.join(__dirname, '..', 'preview');
if (fs.existsSync(PREVIEW_DIR)) {
  app.use('/preview', express.static(PREVIEW_DIR));
}

// --- JSON DB setup (persistent, no native build) ---
const DB_FILE = path.join(DATA_DIR, 'db.json');
function loadDb() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = {
      users: [],
      videos: [],
      posts: [],
      likes: [],
      comments: [],
      commentLikes: [],
      views: [],
      danmaku: [],
      messages: [],
      follows: [],
      privateMessages: [],
    };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
  }
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    // Backfill missing arrays for older db.json files
    parsed.commentLikes = Array.isArray(parsed.commentLikes) ? parsed.commentLikes : [];
    parsed.views = Array.isArray(parsed.views) ? parsed.views : [];
    return parsed;
  } catch (e) {
    console.error('Failed to load DB:', e);
    return { users: [], videos: [], posts: [], likes: [], comments: [], commentLikes: [], views: [], danmaku: [], messages: [], follows: [], privateMessages: [] };
  }
}
function saveDb(db) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  } catch (e) {
    console.error('Failed to save DB:', e);
  }
}
let db = loadDb();
// Ensure required arrays exist
db.commentLikes = Array.isArray(db.commentLikes) ? db.commentLikes : [];
db.views = Array.isArray(db.views) ? db.views : [];
db.follows = Array.isArray(db.follows) ? db.follows : [];
db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
db.posts = Array.isArray(db.posts) ? db.posts : [];
db.likes = Array.isArray(db.likes) ? db.likes : [];
db.comments = Array.isArray(db.comments) ? db.comments : [];
// 系统消息（通知）
db.messages = Array.isArray(db.messages) ? db.messages : [];
// 观看历史（每用户记录最近观看进度）
 db.history = Array.isArray(db.history) ? db.history : [];
 // 帖子浏览历史（独立于视频观看历史）
 db.postHistory = Array.isArray(db.postHistory) ? db.postHistory : [];
// 在线状态心跳（数组：{ userId, lastOnlineAt }）
  db.presence = Array.isArray(db.presence) ? db.presence : [];

// --- Multer (disk storage) ---
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      if (file.fieldname === 'video') cb(null, VIDEOS_DIR);
      else if (file.fieldname === 'thumbnail') cb(null, THUMBS_DIR);
      else if (file.fieldname === 'avatar') cb(null, AVATARS_DIR);
      else if (file.fieldname === 'images') cb(null, IMAGES_DIR);
      else if (file.fieldname === 'audio') cb(null, MUSIC_DIR);
      else if (file.fieldname === 'cover') cb(null, THUMBS_DIR);
      else cb(null, THUMBS_DIR);
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      const name = Date.now() + '-' + Math.random().toString(36).slice(2) + ext;
      cb(null, name);
    },
  }),
});

// --- Helpers ---
function toUserBrief(user, req) {
  return {
    id: user.id,
    username: user.username,
    nickname: user.nickname || null,
    avatar: user.avatar ? (user.avatar.startsWith('http') ? user.avatar : absoluteUrl(req, user.avatar)) : null,
  };
}

function absoluteUrl(req, relativePath) {
  const configured = (process.env.PUBLIC_BASE_URL || '').replace(/\/+$/, '');
  // 优先使用外部配置的公共域名
  if (configured) {
    return `${configured}${relativePath.startsWith('/') ? '' : '/'}${relativePath}`;
  }
  // 其次尊重代理头中的协议
  const forwarded = (req.get('x-forwarded-proto') || '').split(',')[0].trim();
  const proto = forwarded || req.protocol;
  const base = `${proto}://${req.headers.host}`;
  return `${base}${relativePath.startsWith('/') ? '' : '/'}${relativePath}`;
}

function optionalAuth(req, res, next) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) {
    const token = auth.slice('Bearer '.length);
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      req.user = payload;
    } catch (e) {
      // ignore invalid token
    }
  }
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  next();
}

// 推送系统消息（通知）
function pushMessage(req, { toUserId, type, title, content, data }) {
  try {
    if (!toUserId || (req.user && toUserId === req.user.id)) return;
    const fromUser = db.users.find(u => u.id === (req.user ? req.user.id : null)) || { id: req.user?.id, username: 'unknown', nickname: null, avatar: null };
    const msg = {
      id: uuidv4(),
      userId: toUserId,
      type: String(type || 'system'),
      title: String(title || ''),
      content: String(content || ''),
      data: data || null,
      from: toUserBrief(fromUser, req),
      timestamp: Date.now(),
      read: 0,
    };
    db.messages.push(msg);
    saveDb(db);
  } catch (_) {
    // ignore push errors
  }
}

app.use(optionalAuth);

// --- Update Config APIs ---
// Reads backend/data/gx.txt and exposes forced update configuration
// gx.txt example:
//   开启更新: 是
//   url: /storage/app-release.apk
// or:
//   enabled: true
//   url: http://your-host/app-release.apk
const UPDATE_GX_FILE = path.join(DATA_DIR, 'gx.txt');
const APP_DIR = path.join(STORAGE_DIR, 'app');
if (!fs.existsSync(APP_DIR)) fs.mkdirSync(APP_DIR, { recursive: true });

function readUpdateConfigTxt() {
  let enabled = false;
  let url = null;
  let builtin = false;
  let notes = '';
  let version = null;
  try {
    if (fs.existsSync(UPDATE_GX_FILE)) {
      const content = fs.readFileSync(UPDATE_GX_FILE, 'utf-8');
      const rawLines = content.split(/\r?\n/);
      let currentKey = null;
      for (let i = 0; i < rawLines.length; i++) {
        const raw = rawLines[i];
        const line = (raw || '').trim();
        if (!line) {
          if (currentKey === 'notes') notes += '\n';
          continue;
        }
        if (line.startsWith('#')) {
          // skip comments
          continue;
        }
        const idx = line.indexOf(':');
        if (idx !== -1) {
          const key = line.slice(0, idx).trim().toLowerCase();
          const value = line.slice(idx + 1).trim();
          currentKey = null;
          if (key === '开启更新' || key === 'enabled') {
            const v = (value || '').toLowerCase();
            enabled = ['是', 'true', '1', 'y', 'yes', 'on'].includes(v);
          } else if (key === 'url') {
            url = value || null;
          } else if (key === '内置更新' || key === 'builtin') {
            const v = (value || '').toLowerCase();
            builtin = ['是', 'true', '1', 'y', 'yes', 'on'].includes(v);
          } else if (key === '版本号' || key === 'version') {
            version = value || null;
          } else if (key === '更新内容' || key === 'notes') {
            if (value) {
              notes = value;
            } else {
              // capture subsequent non-key lines as notes
              currentKey = 'notes';
            }
          }
        } else if (currentKey === 'notes') {
          notes += (notes ? '\n' : '') + line;
        }
      }
    }
  } catch (e) {
    console.error('[update-config] read error:', e);
  }
  return { enabled, url, builtin, notes, version };
}

app.get('/api/update-config', (req, res) => {
  const cfg = readUpdateConfigTxt();
  let finalUrl = cfg.url;
  if (!finalUrl && cfg.builtin) {
    finalUrl = '/api/app/download';
  }
  finalUrl = finalUrl
    ? (/^https?:\/\//i.test(finalUrl) ? finalUrl : absoluteUrl(req, finalUrl))
    : null;
  return res.json({ success: true, message: 'OK', data: { enabled: !!cfg.enabled, builtin: !!cfg.builtin, url: finalUrl, notes: cfg.notes || '', version: cfg.version || null } });
});

// APK download route (supports builtin update)
app.get('/api/app/download', (req, res) => {
  const apkPath = path.join(APP_DIR, '沫欢记录.apk');
  if (!fs.existsSync(apkPath)) {
    return res.status(404).json({ success: false, message: 'APK not found' });
  }
  res.download(apkPath, '沫欢记录.apk');
});

// --- Enjoy stickers listing ---
// Lists files under storage/enjoy (png/jpg/jpeg/gif/webp) as absolute URLs
app.get('/api/enjoy', (req, res) => {
  try {
    const files = fs.readdirSync(ENJOY_DIR);
    const imageRegex = /\.(png|jpg|jpeg|gif|webp)$/i;
    const items = files
      .filter(f => imageRegex.test(f))
      .sort((a, b) => a.localeCompare(b))
      .map(f => ({
        name: f,
        url: absoluteUrl(req, `/storage/enjoy/${encodeURIComponent(f)}`),
      }));
    res.json({ success: true, message: 'OK', data: { items, count: items.length } });
  } catch (e) {
    console.error('[enjoy] list error:', e);
    res.status(500).json({ success: false, message: '读取贴纸失败' });
  }
});

// --- Auth APIs ---
app.post('/api/auth/register', (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ success: false, message: '用户名与密码必填' });
  }
  const exists = db.users.find(u => u.username === username);
  if (exists) {
    return res.status(409).json({ success: false, message: '用户名已存在' });
  }
  const id = 'u-' + uuidv4();
  const passwordHash = bcrypt.hashSync(password, 10);
  const user = {
    id,
    username,
    email: email || '',
    passwordHash,
    avatar: '',
    nickname: '',
    signature: '',
    level: 1,
    uid: 'UID' + Date.now(),
    followingCount: 0,
    followersCount: 0,
    likesCount: 0,
    videosCount: 0,
    createdAt: new Date().toISOString(),
  };
  db.users.push(user);
  saveDb(db);
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
  const responseUser = { ...user };
  delete responseUser.passwordHash;
  responseUser.avatar = responseUser.avatar ? absoluteUrl(req, responseUser.avatar) : '';
  res.json({ success: true, message: '注册成功', data: { user: responseUser, token, isNewUser: true } });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ success: false, message: '用户不存在' });
  }
  const ok = bcrypt.compareSync(password || '', user.passwordHash);
  if (!ok) {
    return res.status(401).json({ success: false, message: '密码错误' });
  }
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
  const responseUser = { ...user };
  delete responseUser.passwordHash;
  responseUser.avatar = responseUser.avatar ? absoluteUrl(req, responseUser.avatar) : '';
  res.json({ success: true, message: '登录成功', data: { user: responseUser, token, isNewUser: false } });
});

// Unified login or register (用户名+密码，一体化)
app.post('/api/auth/loginOrRegister', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ success: false, message: '用户名与密码必填' });
  }
  let user = db.users.find(u => u.username === username);
  let isNewUser = false;
  if (!user) {
    // Auto-register
    const id = 'u-' + uuidv4();
    const passwordHash = bcrypt.hashSync(password, 10);
    user = {
      id,
      username,
      email: '',
      passwordHash,
      avatar: '',
      nickname: '',
      signature: '',
      level: 1,
      uid: 'UID' + Date.now(),
      followingCount: 0,
      followersCount: 0,
      likesCount: 0,
      videosCount: 0,
      createdAt: new Date().toISOString(),
    };
    db.users.push(user);
    saveDb(db);
    isNewUser = true;
  } else {
    // Validate password
    const ok = bcrypt.compareSync(password || '', user.passwordHash);
    if (!ok) {
      return res.status(401).json({ success: false, message: '密码错误' });
    }
  }
  const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' });
  const responseUser = { ...user };
  delete responseUser.passwordHash;
  responseUser.avatar = responseUser.avatar ? absoluteUrl(req, responseUser.avatar) : '';
  res.json({ success: true, message: 'OK', data: { user: responseUser, token, isNewUser } });
});

// --- Video APIs ---
app.get('/api/videos', async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const size = Math.max(1, Number(req.query.size) || 10);
  const sorted = [...db.videos].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  const start = (page - 1) * size;
  const rows = sorted.slice(start, start + size);
  // 回填缺失的时长（历史数据）
  await Promise.all(rows.map(async (v) => {
    if (!v.duration || Number(v.duration) <= 0) {
      try {
        const fileName = path.basename(v.videoUrl || '');
        const filePath = path.join(__dirname, 'storage', 'videos', fileName);
        const dur = await getDurationSec(filePath);
        if (dur > 0) { v.duration = dur; saveDb(db); }
      } catch (_) {}
    }
  }));
  const videos = rows.map(v => {
    const author = db.users.find(u => u.id === v.authorId) || { id: v.authorId, username: 'unknown', nickname: null, avatar: null };
    const likeCount = db.likes.filter(l => l.videoId === v.id).length;
    const commentCount = db.comments.filter(c => c.videoId === v.id).length;
    const isLiked = req.user ? !!db.likes.find(l => l.userId === req.user.id && l.videoId === v.id) : false;
    const viewCount = db.views.filter(vw => vw.videoId === v.id).length;
    return {
      id: v.id,
      title: v.title,
      videoUrl: absoluteUrl(req, v.videoUrl),
      coverUrl: v.coverUrl ? absoluteUrl(req, v.coverUrl) : '',
      duration: Number(v.duration) || 0,
      viewCount,
      likeCount,
      commentCount,
      author: toUserBrief(author, req),
      createdAt: v.createdAt,
      isLiked,
    };
  });
  const totalPages = Math.max(1, Math.ceil(db.videos.length / size));
  res.json({ success: true, message: 'OK', data: { videos, totalPages, currentPage: page } });
});

app.get('/api/videos/:videoId', async (req, res) => {
  const vid = req.params.videoId;
  const v = db.videos.find(vv => vv.id === vid);
  if (!v) return res.status(404).json({ success: false, message: '视频不存在' });
  if (!v.duration || Number(v.duration) <= 0) {
    try {
      const fileName = path.basename(v.videoUrl || '');
      const filePath = path.join(__dirname, 'storage', 'videos', fileName);
      const dur = await getDurationSec(filePath);
      if (dur > 0) { v.duration = dur; saveDb(db); }
    } catch (_) {}
  }
  const author = db.users.find(u => u.id === v.authorId) || { id: v.authorId, username: 'unknown', nickname: null, avatar: null };
  const isLiked = req.user ? !!db.likes.find(l => l.userId === req.user.id && l.videoId === vid) : false;
  const viewCount = db.views.filter(vw => vw.videoId === v.id).length;
  const detail = {
    id: v.id,
    title: v.title,
    description: v.description || '',
    videoUrl: absoluteUrl(req, v.videoUrl),
    coverUrl: v.coverUrl ? absoluteUrl(req, v.coverUrl) : '',
    duration: Number(v.duration) || 0,
    viewCount,
    likeCount: db.likes.filter(l => l.videoId === v.id).length,
    commentCount: db.comments.filter(c => c.videoId === v.id).length,
    author: toUserBrief(author, req),
    tags: Array.isArray(v.tags) ? v.tags : [],
    isLiked,
    createdAt: v.createdAt,
  };
  res.json({ success: true, message: 'OK', data: detail });
});

// --- Watch History APIs ---
// 获取我的观看历史
app.get('/api/history', requireAuth, (req, res) => {
  try {
    db.history = Array.isArray(db.history) ? db.history : [];
    const rows = db.history
      .filter(h => h.userId === req.user.id)
      .sort((a, b) => (b.watchedAt || '').localeCompare(a.watchedAt || ''));
    const items = rows.map(h => {
      const v = db.videos.find(vv => vv.id === h.videoId) || {};
      const author = db.users.find(u => u.id === v.authorId);
      return {
        id: h.id,
        videoId: h.videoId,
        title: v.title || '未知视频',
        thumbnailUrl: v.coverUrl ? absoluteUrl(req, v.coverUrl) : '',
        authorName: (author && (author.nickname || author.username)) || '未知作者',
        // 向前端提供已格式化的时间字符串，避免端上复杂处理
        watchTime: new Date(h.watchedAt || Date.now()).toISOString(),
        watchedDuration: Number(h.watchedDuration) || 0,
        totalDuration: Number(h.totalDuration) || Number(v.duration) || 0,
      };
    });
    res.json({ success: true, message: 'OK', data: { history: items } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '加载历史失败' });
  }
});

// 添加或更新我的观看历史（同一视频仅保留一条，按最近观看覆盖）
app.post('/api/history', requireAuth, (req, res) => {
  try {
    const { videoId, watchedDuration, totalDuration } = req.body || {};
    if (!videoId) return res.status(400).json({ success: false, message: '缺少videoId' });
    const v = db.videos.find(vv => vv.id === videoId);
    if (!v) return res.status(404).json({ success: false, message: '视频不存在' });
    db.history = Array.isArray(db.history) ? db.history : [];
    const now = new Date().toISOString();
    const idx = db.history.findIndex(h => h.userId === req.user.id && h.videoId === videoId);
    if (idx >= 0) {
      db.history[idx] = {
        ...db.history[idx],
        watchedDuration: Number(watchedDuration) || 0,
        totalDuration: Number(totalDuration) || Number(v.duration) || 0,
        watchedAt: now,
      };
    } else {
      db.history.push({
        id: uuidv4(),
        userId: req.user.id,
        videoId,
        watchedDuration: Number(watchedDuration) || 0,
        totalDuration: Number(totalDuration) || Number(v.duration) || 0,
        watchedAt: now,
      });
    }
    saveDb(db);
    res.json({ success: true, message: '已记录历史' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '记录历史失败' });
  }
});

// 删除单条历史记录
app.delete('/api/history/:id', requireAuth, (req, res) => {
  try {
    const id = req.params.id;
    db.history = Array.isArray(db.history) ? db.history : [];
    const before = db.history.length;
    db.history = db.history.filter(h => !(h.id === id && h.userId === req.user.id));
    if (db.history.length !== before) saveDb(db);
    res.json({ success: true, message: '已删除' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '删除失败' });
  }
});

// 清空我的所有历史
app.delete('/api/history', requireAuth, (req, res) => {
  try {
    db.history = Array.isArray(db.history) ? db.history : [];
    const before = db.history.length;
    db.history = db.history.filter(h => h.userId !== req.user.id);
    if (db.history.length !== before) saveDb(db);
    res.json({ success: true, message: '已清空' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '清空失败' });
  }
});

async function getDurationSec(filePath) {
  try {
    const music = await import('music-metadata');
    const metadata = await music.parseFile(filePath);
    const dur = metadata?.format?.duration || 0;
    return Math.round(dur);
  } catch (e) {
    return 0;
  }
}

app.post('/api/videos/upload', requireAuth, upload.fields([{ name: 'video', maxCount: 1 }, { name: 'thumbnail', maxCount: 1 }]), async (req, res) => {
  try {
    const title = req.body.title || '';
    const description = req.body.description || '';
    const tagsStr = req.body.tags || '';
    const isPublic = String(req.body.isPublic || 'true').toLowerCase() === 'true';
    const videoFile = (req.files && req.files.video && req.files.video[0]) ? req.files.video[0] : null;
    const thumbFile = (req.files && req.files.thumbnail && req.files.thumbnail[0]) ? req.files.thumbnail[0] : null;
    if (!videoFile) return res.status(400).json({ success: false, message: '缺少视频文件' });
    const id = 'v-' + uuidv4();
    const videoRelative = `/storage/videos/${videoFile.filename}`;
    const coverRelative = thumbFile ? `/storage/thumbnails/${thumbFile.filename}` : '';
    const createdAt = new Date().toISOString();
    const tags = tagsStr ? tagsStr.split(',').map(s => s.trim()).filter(Boolean) : [];
    // 尝试解析并保存视频时长（秒）
    const duration = await getDurationSec(videoFile.path);
    db.videos.push({ id, title, description, videoUrl: videoRelative, coverUrl: coverRelative, duration, viewCount: 0, authorId: req.user.id, tags, isPublic, createdAt });
    const user = db.users.find(u => u.id === req.user.id);
    if (user) user.videosCount = (user.videosCount || 0) + 1;
    saveDb(db);
    res.json({ success: true, message: '上传成功', data: { videoId: id, videoUrl: absoluteUrl(req, videoRelative), coverUrl: coverRelative ? absoluteUrl(req, coverRelative) : '' } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '上传失败' });
  }
});

// 更新视频（编辑元信息，或可选替换视频文件/封面）
app.put('/api/videos/:videoId', requireAuth, upload.fields([{ name: 'video', maxCount: 1 }, { name: 'thumbnail', maxCount: 1 }]), async (req, res) => {
  try {
    const vid = req.params.videoId;
    const v = db.videos.find(vv => vv.id === vid);
    if (!v) return res.status(404).json({ success: false, message: '视频不存在' });
    if (v.authorId !== req.user.id) return res.status(403).json({ success: false, message: '无权限编辑该视频' });

    const title = req.body.title;
    const description = req.body.description;
    const tagsStr = req.body.tags;
    const isPublic = req.body.isPublic;

    if (title !== undefined) v.title = String(title);
    if (description !== undefined) v.description = String(description);
    if (tagsStr !== undefined) {
      if (Array.isArray(tagsStr)) {
        v.tags = tagsStr;
      } else {
        v.tags = String(tagsStr).split(',').map(s => s.trim()).filter(Boolean);
      }
    }
    if (isPublic !== undefined) v.isPublic = String(isPublic).toLowerCase() === 'true';

    const videoFile = (req.files && req.files.video && req.files.video[0]) ? req.files.video[0] : null;
    const thumbFile = (req.files && req.files.thumbnail && req.files.thumbnail[0]) ? req.files.thumbnail[0] : null;

    // 替换视频文件
    if (videoFile) {
      try {
        const oldName = path.basename(v.videoUrl || '');
        const oldPath = path.join(__dirname, 'storage', 'videos', oldName);
        if (oldName && fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      } catch (_) {}
      const videoRelative = `/storage/videos/${videoFile.filename}`;
      v.videoUrl = videoRelative;
      // 解析新视频时长
      try {
        const duration = await getDurationSec(videoFile.path);
        if (duration > 0) v.duration = duration;
      } catch (_) {}
    }

    // 替换封面文件
    if (thumbFile) {
      try {
        const oldName = path.basename(v.coverUrl || '');
        const oldPath = path.join(__dirname, 'storage', 'thumbnails', oldName);
        if (oldName && fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      } catch (_) {}
      const coverRelative = `/storage/thumbnails/${thumbFile.filename}`;
      v.coverUrl = coverRelative;
    }

    saveDb(db);

    const author = db.users.find(u => u.id === v.authorId) || { id: v.authorId, username: 'unknown', nickname: null, avatar: null };
    const detail = {
      id: v.id,
      title: v.title,
      description: v.description || '',
      videoUrl: absoluteUrl(req, v.videoUrl),
      coverUrl: v.coverUrl ? absoluteUrl(req, v.coverUrl) : '',
      duration: Number(v.duration) || 0,
      viewCount: Number(v.viewCount) || 0,
      likeCount: db.likes.filter(l => l.videoId === v.id).length,
      commentCount: db.comments.filter(c => c.videoId === v.id).length,
      author: toUserBrief(author, req),
      tags: Array.isArray(v.tags) ? v.tags : [],
      isLiked: false,
      createdAt: v.createdAt,
    };
    res.json({ success: true, message: '视频已更新', data: detail });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '更新失败' });
  }
});

// 删除视频
app.delete('/api/videos/:videoId', requireAuth, (req, res) => {
  try {
    const vid = req.params.videoId;
    const idx = db.videos.findIndex(vv => vv.id === vid);
    if (idx === -1) return res.status(404).json({ success: false, message: '视频不存在' });
    const v = db.videos[idx];
    if (v.authorId !== req.user.id) return res.status(403).json({ success: false, message: '无权限删除该视频' });

    // 删除文件
    try {
      const vName = path.basename(v.videoUrl || '');
      const vPath = path.join(__dirname, 'storage', 'videos', vName);
      if (vName && fs.existsSync(vPath)) fs.unlinkSync(vPath);
      const cName = path.basename(v.coverUrl || '');
      const cPath = path.join(__dirname, 'storage', 'thumbnails', cName);
      if (cName && fs.existsSync(cPath)) fs.unlinkSync(cPath);
    } catch (_) {}

    // 清理关联数据
    db.likes = db.likes.filter(l => l.videoId !== vid);
    db.comments = db.comments.filter(c => c.videoId !== vid);
    db.commentLikes = Array.isArray(db.commentLikes) ? db.commentLikes.filter(cl => cl.videoId !== vid) : [];
    db.danmaku = Array.isArray(db.danmaku) ? db.danmaku.filter(d => d.videoId !== vid) : [];

    // 更新作者统计
    const user = db.users.find(u => u.id === v.authorId);
    if (user) user.videosCount = Math.max(0, (user.videosCount || 1) - 1);

    // 移除视频记录
    db.videos.splice(idx, 1);
    saveDb(db);
    res.json({ success: true, message: '视频已删除' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '删除失败' });
  }
});

app.post('/api/videos/:videoId/like', requireAuth, (req, res) => {
  const vid = req.params.videoId;
  try {
    const exists = db.likes.find(l => l.userId === req.user.id && l.videoId === vid);
    if (!exists) db.likes.push({ userId: req.user.id, videoId: vid });
    saveDb(db);
    // 发送点赞通知给视频作者
    try {
      const video = db.videos.find(vv => vv.id === vid);
      if (video && video.authorId && video.authorId !== req.user.id) {
        const title = '你的视频获赞';
        const content = `${(req.user && req.user.username) || '有人'}点赞了你的视频：${video.title || ''}`;
        pushMessage(req, {
          toUserId: video.authorId,
          type: 'video_like',
          title,
          content,
          data: { videoId: video.id, title: video.title || '' }
        });
      }
    } catch (_) {}
    res.json({ success: true, message: '已点赞' });
  } catch (e) {
    res.status(500).json({ success: false, message: '点赞失败' });
  }
});

app.delete('/api/videos/:videoId/like', requireAuth, (req, res) => {
  const vid = req.params.videoId;
  try {
    db.likes = db.likes.filter(l => !(l.userId === req.user.id && l.videoId === vid));
    saveDb(db);
    res.json({ success: true, message: '已取消点赞' });
  } catch (e) {
    res.status(500).json({ success: false, message: '取消点赞失败' });
  }
});

app.get('/api/videos/:videoId/comments', (req, res) => {
  const vid = req.params.videoId;
  const page = Math.max(1, Number(req.query.page) || 1);
  const size = Math.max(1, Number(req.query.size) || 10);
  const sorted = db.comments.filter(c => c.videoId === vid).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  const start = (page - 1) * size;
  const rows = sorted.slice(start, start + size);
  const comments = rows.map(c => {
    const author = db.users.find(u => u.id === c.authorId) || { id: c.authorId, username: 'unknown', nickname: null, avatar: null };
    const likeCount = db.commentLikes.filter(l => l.commentId === c.id).length;
    const isLiked = req.user ? !!db.commentLikes.find(l => l.userId === req.user.id && l.commentId === c.id) : false;
    return { id: c.id, content: c.content, author: toUserBrief(author, req), createdAt: c.createdAt, likeCount, isLiked, parentId: c.parentId || null };
  });
  const totalPages = Math.max(1, Math.ceil(sorted.length / size));
  res.json({ success: true, message: 'OK', data: { comments, totalPages, currentPage: page } });
});

app.post('/api/videos/:videoId/comments', requireAuth, (req, res) => {
  const vid = req.params.videoId;
  const content = (req.body && req.body.content) ? String(req.body.content) : '';
  const parentId = (req.body && req.body.parentId) ? String(req.body.parentId) : null;
  if (!content.trim()) return res.status(400).json({ success: false, message: '评论内容不能为空' });
  if (parentId) {
    const parent = db.comments.find(c => c.id === parentId && c.videoId === vid);
    if (!parent) return res.status(400).json({ success: false, message: '父评论不存在或不属于该视频' });
  }
  const id = 'c-' + uuidv4();
  const createdAt = new Date().toISOString();
  db.comments.push({ id, videoId: vid, content, authorId: req.user.id, createdAt, likeCount: 0, parentId });
  saveDb(db);
  const author = db.users.find(u => u.id === req.user.id);
  const comment = { id, content, author: toUserBrief(author), createdAt, likeCount: 0, parentId };
  // 发送评论通知：给视频作者和父评论作者（若存在）
  try {
    const video = db.videos.find(vv => vv.id === vid);
    if (video && video.authorId && video.authorId !== req.user.id) {
      pushMessage(req, {
        toUserId: video.authorId,
        type: 'video_comment',
        title: '你的视频收到评论',
        content: `${(req.user && req.user.username) || '有人'}评论了你的视频：${content.slice(0, 80)}`,
        data: { videoId: vid, commentId: id }
      });
    }
    if (parentId) {
      const parent = db.comments.find(c => c.id === parentId && c.videoId === vid);
      if (parent && parent.authorId && parent.authorId !== req.user.id) {
        pushMessage(req, {
          toUserId: parent.authorId,
          type: 'comment_reply',
          title: '你的评论有了新回复',
          content: `${(req.user && req.user.username) || '有人'}回复了你的评论：${content.slice(0, 80)}`,
          data: { videoId: vid, commentId: id, parentId }
        });
      }
    }
  } catch (_) {}
  res.json({ success: true, message: '评论成功', data: comment });
});

// 评论点赞
app.post('/api/videos/:videoId/comments/:commentId/like', requireAuth, (req, res) => {
  const vid = req.params.videoId;
  const cid = req.params.commentId;
  const existsComment = db.comments.find(c => c.id === cid && c.videoId === vid);
  if (!existsComment) return res.status(404).json({ success: false, message: '评论不存在' });
  const exists = db.commentLikes.find(l => l.userId === req.user.id && l.commentId === cid);
  if (!exists) db.commentLikes.push({ userId: req.user.id, commentId: cid, videoId: vid });
  saveDb(db);
  // 发送评论获赞通知给评论作者（排除自己赞自己的情况）
  try {
    const comment = db.comments.find(c => c.id === cid && c.videoId === vid);
    if (comment && comment.authorId && comment.authorId !== req.user.id) {
      const title = '你的评论获赞';
      const content = `${(req.user && req.user.username) || '有人'}点赞了你在视频中的评论：${(comment.content || '').slice(0, 80)}`;
      pushMessage(req, {
        toUserId: comment.authorId,
        type: 'comment_like',
        title,
        content,
        data: { videoId: vid, commentId: cid }
      });
    }
  } catch (_) {}
  res.json({ success: true, message: '已点赞' });
});

app.delete('/api/videos/:videoId/comments/:commentId/like', requireAuth, (req, res) => {
  const vid = req.params.videoId;
  const cid = req.params.commentId;
  const existsComment = db.comments.find(c => c.id === cid && c.videoId === vid);
  if (!existsComment) return res.status(404).json({ success: false, message: '评论不存在' });
  db.commentLikes = db.commentLikes.filter(l => !(l.userId === req.user.id && l.commentId === cid));
  saveDb(db);
  res.json({ success: true, message: '已取消点赞' });
});

app.get('/api/videos/:videoId/danmaku', (req, res) => {
  const vid = req.params.videoId;
  const rows = db.danmaku.filter(d => d.videoId === vid).sort((a, b) => (a.time || 0) - (b.time || 0));
  const list = rows.map(d => ({ id: d.id, content: d.content, time: Number(d.time), color: d.color, type: Number(d.type), userId: d.userId }));
  res.json({ success: true, message: 'OK', data: list });
});

app.post('/api/videos/:videoId/danmaku', requireAuth, (req, res) => {
  const vid = req.params.videoId;
  const { content, time, color, type } = req.body || {};
  if (!content || time === undefined) return res.status(400).json({ success: false, message: '弹幕参数不完整' });
  const id = 'd-' + uuidv4();
  const createdAt = new Date().toISOString();
  db.danmaku.push({ id, videoId: vid, content: String(content), time: Number(time) || 0, color: String(color || '#FFFFFF'), type: Number(type) || 1, userId: req.user.id, createdAt });
  saveDb(db);
  res.json({ success: true, message: '弹幕已发送' });
});

// --- Message APIs (require auth) ---
app.get('/api/messages', requireAuth, (req, res) => {
  const type = (req.query.type || 'all').toString().toLowerCase();

  // 将前端的聚合类型映射为后端实际存储的细分类型
  const TYPE_GROUPS = {
    like: ['like', 'video_like', 'post_like', 'comment_like'],
    comment: ['comment', 'video_comment', 'post_comment', 'comment_reply'],
    follow: ['follow'],
    system: ['system']
  };

  const wantedTypes = type === 'all' ? null : (TYPE_GROUPS[type] || [type]);

  // 过滤并按时间倒序
  const rows = db.messages
    .filter(m => m.userId === req.user.id && (!wantedTypes || wantedTypes.includes(m.type)))
    .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  // 规范化为前端期望的字段结构
  const normalized = rows.map(m => {
    const from = m.from || {};
    const senderId = from.id || '';
    const senderName = (from.nickname && String(from.nickname)) || (from.username && String(from.username)) || '';
    const senderAvatar = from.avatar || '';
    const data = m.data || {};
    const relatedId = data.videoId || data.postId || data.commentId || data.followerId || '';

    // 将细分类型归一化为 like/comment/follow/system，便于前端展示与通知标题
    const uiType = TYPE_GROUPS.like.includes(m.type)
      ? 'like'
      : TYPE_GROUPS.comment.includes(m.type)
        ? 'comment'
        : TYPE_GROUPS.follow.includes(m.type)
          ? 'follow'
          : TYPE_GROUPS.system.includes(m.type)
            ? 'system'
            : (m.type || 'system');

    return {
      id: m.id,
      type: uiType,
      senderId,
      senderName,
      senderAvatar,
      content: m.content || '',
      time: null, // 前端会基于 timestamp 自行格式化
      timestamp: m.timestamp || 0,
      relatedId
    };
  });

  res.json({ success: true, message: 'OK', data: { messages: normalized } });
});

app.post('/api/messages/:id/read', requireAuth, (req, res) => {
  const msg = db.messages.find(m => m.id === req.params.id && m.userId === req.user.id);
  if (msg) msg.read = 1;
  saveDb(db);
  res.json({ success: true, message: '消息已读' });
});

app.delete('/api/messages/:id', requireAuth, (req, res) => {
  db.messages = db.messages.filter(m => !(m.id === req.params.id && m.userId === req.user.id));
  saveDb(db);
  res.json({ success: true, message: '消息已删除' });
});

app.delete('/api/messages', requireAuth, (req, res) => {
  db.messages = db.messages.filter(m => m.userId !== req.user.id);
  saveDb(db);
  res.json({ success: true, message: '已清空所有消息' });
});

app.get('/api/messages/unreadCount', requireAuth, (req, res) => {
  const count = db.messages.filter(m => m.userId === req.user.id && (m.read || 0) === 0).length;
  res.json({ success: true, message: 'OK', data: { count } });
});

// 通用内容发布：文章/图片/音乐
// 支持字段：type=article|images|music；title、content/description、tags、isPublic
// 文件：images[]（多张）、audio（单个音乐文件）、cover（音乐封面或文章/图片封面，可选）
app.post('/api/posts/upload', requireAuth, upload.fields([
  { name: 'images', maxCount: 12 },
  { name: 'audio', maxCount: 1 },
  { name: 'cover', maxCount: 1 }
]), async (req, res) => {
  try {
    const type = String(req.body.type || '').toLowerCase();
    const title = String(req.body.title || '');
    const content = String(req.body.content || '');
    const description = String(req.body.description || '');
    const tagsStr = String(req.body.tags || '');
    const isPublic = String(req.body.isPublic || 'true').toLowerCase() === 'true';
    const tags = tagsStr ? tagsStr.split(',').map(s => s.trim()).filter(Boolean) : [];

    const images = (req.files && req.files.images) ? req.files.images : [];
    const audio = (req.files && req.files.audio && req.files.audio[0]) ? req.files.audio[0] : null;
    const cover = (req.files && req.files.cover && req.files.cover[0]) ? req.files.cover[0] : null;

    if (!['article', 'images', 'music'].includes(type)) {
      return res.status(400).json({ success: false, message: '不支持的类型' });
    }

    const id = 'p-' + uuidv4();
    const createdAt = new Date().toISOString();
    const imageUrls = images.map(f => `/storage/images/${f.filename}`);
    const audioUrl = audio ? `/storage/music/${audio.filename}` : '';
    const coverUrl = cover ? `/storage/thumbnails/${cover.filename}` : '';

    if (type === 'article') {
      if (!content.trim() && !title.trim()) {
        return res.status(400).json({ success: false, message: '文章需标题或正文' });
      }
      db.posts.push({ id, type, title, content, images: imageUrls, coverUrl, authorId: req.user.id, tags, isPublic, createdAt });
    } else if (type === 'images') {
      if (!imageUrls.length) {
        return res.status(400).json({ success: false, message: '请至少选择一张图片' });
      }
      db.posts.push({ id, type, title, description, images: imageUrls, coverUrl, authorId: req.user.id, tags, isPublic, createdAt });
    } else if (type === 'music') {
      if (!audioUrl) {
        return res.status(400).json({ success: false, message: '缺少音乐文件' });
      }
      // 解析音乐时长
      let duration = 0;
      try {
        duration = await getDurationSec(audio.path);
      } catch (_) {}
      db.posts.push({ id, type, title, description, audioUrl, coverUrl, duration, authorId: req.user.id, tags, isPublic, createdAt });
    }

    saveDb(db);

    res.json({ success: true, message: '发布成功', data: { postId: id, type, urls: imageUrls.map(u => absoluteUrl(req, u)), audioUrl: audioUrl ? absoluteUrl(req, audioUrl) : '', coverUrl: coverUrl ? absoluteUrl(req, coverUrl) : '' } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '发布失败' });
  }
});

// 更新帖子（文章/图片/音乐）
// 可编辑字段：title、content/description、tags、isPublic
// 可选文件替换：images[]（覆盖旧图片集）、audio（替换音乐）、cover（替换封面）
app.put('/api/posts/:postId', requireAuth, upload.fields([
  { name: 'images', maxCount: 12 },
  { name: 'audio', maxCount: 1 },
  { name: 'cover', maxCount: 1 }
]), async (req, res) => {
  try {
    const pid = req.params.postId;
    db.posts = Array.isArray(db.posts) ? db.posts : [];
    const p = db.posts.find(pp => pp.id === pid);
    if (!p) return res.status(404).json({ success: false, message: '帖子不存在' });
    if (p.authorId !== req.user.id) return res.status(403).json({ success: false, message: '无权限编辑该帖子' });

    const type = String(req.body.type || p.type || '').toLowerCase();
    if (!['article', 'images', 'music'].includes(type)) {
      return res.status(400).json({ success: false, message: '不支持的类型' });
    }

    const title = req.body.title != null ? String(req.body.title) : p.title || '';
    const content = req.body.content != null ? String(req.body.content) : p.content || '';
    const description = req.body.description != null ? String(req.body.description) : p.description || '';
    const tagsStr = req.body.tags != null ? String(req.body.tags) : (Array.isArray(p.tags) ? p.tags.join(',') : '');
    const isPublic = req.body.isPublic != null ? (String(req.body.isPublic).toLowerCase() === 'true') : (p.isPublic !== false);
    const tags = tagsStr ? tagsStr.split(',').map(s => s.trim()).filter(Boolean) : [];

    const images = (req.files && req.files.images) ? req.files.images : [];
    const audio = (req.files && req.files.audio && req.files.audio[0]) ? req.files.audio[0] : null;
    const cover = (req.files && req.files.cover && req.files.cover[0]) ? req.files.cover[0] : null;

    // 按类型处理更新
    if (type === 'article') {
      // 允许更新标题/正文、封面、标签、是否公开
      if (images.length > 0) {
        // 若上传了 images，则作为插图存储
        const imageUrls = images.map(f => `/storage/images/${f.filename}`);
        // 删除旧图（如果之前为 images 类型有图或文章插图）
        if (Array.isArray(p.images)) {
          p.images.forEach(rel => {
            const fileName = path.basename(rel || '');
            if (fileName) {
              const filePath = path.join(__dirname, 'storage', 'images', fileName);
              if (fs.existsSync(filePath)) { try { fs.unlinkSync(filePath); } catch (_) {} }
            }
          });
        }
        p.images = imageUrls;
      }
      p.title = title;
      p.content = content;
      p.tags = tags;
      p.isPublic = isPublic;
      if (cover) {
        if (p.coverUrl) {
          const old = path.basename(p.coverUrl);
          const oldPath = path.join(__dirname, 'storage', 'thumbnails', old);
          if (fs.existsSync(oldPath)) { try { fs.unlinkSync(oldPath); } catch (_) {} }
        }
        p.coverUrl = `/storage/thumbnails/${cover.filename}`;
      }
      p.type = 'article';
    } else if (type === 'images') {
      // 覆盖图片集、更新标题/描述、封面、标签、是否公开
      if (images.length > 0) {
        // 删除旧图
        if (Array.isArray(p.images)) {
          p.images.forEach(rel => {
            const fileName = path.basename(rel || '');
            if (fileName) {
              const filePath = path.join(__dirname, 'storage', 'images', fileName);
              if (fs.existsSync(filePath)) { try { fs.unlinkSync(filePath); } catch (_) {} }
            }
          });
        }
        p.images = images.map(f => `/storage/images/${f.filename}`);
      }
      p.title = title;
      p.description = description;
      p.tags = tags;
      p.isPublic = isPublic;
      if (cover) {
        if (p.coverUrl) {
          const old = path.basename(p.coverUrl);
          const oldPath = path.join(__dirname, 'storage', 'thumbnails', old);
          if (fs.existsSync(oldPath)) { try { fs.unlinkSync(oldPath); } catch (_) {} }
        }
        p.coverUrl = `/storage/thumbnails/${cover.filename}`;
      }
      p.type = 'images';
    } else if (type === 'music') {
      // 可替换音频与封面，并更新标题/描述、标签、是否公开
      if (audio) {
        if (p.audioUrl) {
          const old = path.basename(p.audioUrl);
          const oldPath = path.join(__dirname, 'storage', 'music', old);
          if (fs.existsSync(oldPath)) { try { fs.unlinkSync(oldPath); } catch (_) {} }
        }
        p.audioUrl = `/storage/music/${audio.filename}`;
        // 更新时长
        try { p.duration = await getDurationSec(audio.path); } catch (_) {}
      }
      p.title = title;
      p.description = description;
      p.tags = tags;
      p.isPublic = isPublic;
      if (cover) {
        if (p.coverUrl) {
          const old = path.basename(p.coverUrl);
          const oldPath = path.join(__dirname, 'storage', 'thumbnails', old);
          if (fs.existsSync(oldPath)) { try { fs.unlinkSync(oldPath); } catch (_) {} }
        }
        p.coverUrl = `/storage/thumbnails/${cover.filename}`;
      }
      p.type = 'music';
    }

    saveDb(db);
    return res.json({ success: true, message: '编辑成功' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '编辑失败' });
  }
});

// 获取帖子列表：文章/图片/音乐
// 支持查询参数：type=all|article|images|music，page，size
app.get('/api/posts', (req, res) => {
  try {
    const type = String(req.query.type || 'all').toLowerCase();
    const page = Math.max(1, parseInt(req.query.page || '1', 10) || 1);
    const size = Math.max(1, Math.min(50, parseInt(req.query.size || '10', 10) || 10));

    db.posts = Array.isArray(db.posts) ? db.posts : [];

    let rows = db.posts.filter(p => p.isPublic !== false);
    if (['article', 'images', 'music'].includes(type)) {
      rows = rows.filter(p => p.type === type);
    }

    rows.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

    const totalPages = Math.max(1, Math.ceil(rows.length / size));
    const currentPage = Math.min(page, totalPages);
    const start = (currentPage - 1) * size;
    const paged = rows.slice(start, start + size);

    const list = paged.map(p => {
      const author = db.users.find(u => u.id === p.authorId) || { id: p.authorId, username: 'unknown', nickname: null, avatar: null };
      const likeCount = db.likes.filter(l => l.postId === p.id).length;
      const commentCount = db.comments.filter(c => c.postId === p.id).length;
      const isLiked = req.user ? !!db.likes.find(l => l.userId === req.user.id && l.postId === p.id) : false;
      return {
        id: p.id,
        type: p.type,
        title: p.title || '',
        content: p.content || '',
        description: p.description || '',
        images: Array.isArray(p.images) ? p.images.map(u => absoluteUrl(req, u)) : [],
        audioUrl: p.audioUrl ? absoluteUrl(req, p.audioUrl) : null,
        coverUrl: p.coverUrl ? absoluteUrl(req, p.coverUrl) : null,
        duration: Number(p.duration) || 0,
        likeCount,
        commentCount,
        author: toUserBrief(author, req),
        createdAt: p.createdAt || new Date().toISOString(),
        isLiked,
      };
    });

    res.json({ success: true, message: 'OK', data: { posts: list, totalPages, currentPage } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '获取帖子失败' });
  }
});

// 获取帖子详情
app.get('/api/posts/:postId', async (req, res) => {
  try {
    const pid = req.params.postId;
    const p = db.posts.find(pp => pp.id === pid);
    if (!p) return res.status(404).json({ success: false, message: '帖子不存在' });

    // 对音乐类型补充时长
    if (p.type === 'music' && (!p.duration || Number(p.duration) <= 0)) {
      try {
        const fileName = path.basename(p.audioUrl || '');
        const filePath = path.join(__dirname, 'storage', 'music', fileName);
        const dur = await getDurationSec(filePath);
        if (dur > 0) { p.duration = dur; saveDb(db); }
      } catch (_) {}
    }

    const author = db.users.find(u => u.id === p.authorId) || { id: p.authorId, username: 'unknown', nickname: null, avatar: null };
    const isLiked = req.user ? !!db.likes.find(l => l.userId === req.user.id && l.postId === pid) : false;
    const detail = {
      id: p.id,
      type: p.type,
      title: p.title || '',
      content: p.content || '',
      description: p.description || '',
      images: Array.isArray(p.images) ? p.images.map(u => absoluteUrl(req, u)) : [],
      audioUrl: p.audioUrl ? absoluteUrl(req, p.audioUrl) : null,
      coverUrl: p.coverUrl ? absoluteUrl(req, p.coverUrl) : null,
      duration: Number(p.duration) || 0,
      likeCount: db.likes.filter(l => l.postId === p.id).length,
      commentCount: db.comments.filter(c => c.postId === p.id).length,
      author: toUserBrief(author, req),
      tags: Array.isArray(p.tags) ? p.tags : [],
      isLiked,
      createdAt: p.createdAt || new Date().toISOString(),
    };
    res.json({ success: true, message: 'OK', data: detail });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '获取详情失败' });
  }
});

// 点赞帖子
app.post('/api/posts/:postId/like', requireAuth, (req, res) => {
  const pid = req.params.postId;
  try {
    const exists = db.likes.find(l => l.userId === req.user.id && l.postId === pid);
    if (!exists) db.likes.push({ userId: req.user.id, postId: pid });
    saveDb(db);
    // 发送点赞通知给帖子作者
    try {
      const post = (Array.isArray(db.posts) ? db.posts : []).find(pp => pp.id === pid);
      if (post && post.authorId && post.authorId !== req.user.id) {
        const title = '你的帖子获赞';
        const content = `${(req.user && req.user.username) || '有人'}点赞了你的帖子：${post.title || ''}`;
        pushMessage(req, {
          toUserId: post.authorId,
          type: 'post_like',
          title,
          content,
          data: { postId: post.id, title: post.title || '' }
        });
      }
    } catch (_) {}
    res.json({ success: true, message: '已点赞' });
  } catch (e) {
    res.status(500).json({ success: false, message: '点赞失败' });
  }
});

// 取消点赞帖子
app.delete('/api/posts/:postId/like', requireAuth, (req, res) => {
  const pid = req.params.postId;
  try {
    db.likes = db.likes.filter(l => !(l.userId === req.user.id && l.postId === pid));
    saveDb(db);
    res.json({ success: true, message: '已取消点赞' });
  } catch (e) {
    res.status(500).json({ success: false, message: '取消点赞失败' });
  }
});

// 获取帖子评论列表
app.get('/api/posts/:postId/comments', (req, res) => {
  const pid = req.params.postId;
  const page = Math.max(1, Number(req.query.page) || 1);
  const size = Math.max(1, Number(req.query.size) || 10);
  const sorted = db.comments.filter(c => c.postId === pid).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  const start = (page - 1) * size;
  const rows = sorted.slice(start, start + size);
  const comments = rows.map(c => {
    const author = db.users.find(u => u.id === c.authorId) || { id: c.authorId, username: 'unknown', nickname: null, avatar: null };
    const likeCount = db.commentLikes.filter(l => l.commentId === c.id).length;
    const isLiked = req.user ? !!db.commentLikes.find(l => l.userId === req.user.id && l.commentId === c.id) : false;
    return { id: c.id, content: c.content, author: toUserBrief(author, req), createdAt: c.createdAt, likeCount, isLiked, parentId: c.parentId || null };
  });
  const totalPages = Math.max(1, Math.ceil(sorted.length / size));
  res.json({ success: true, message: 'OK', data: { comments, totalPages, currentPage: page } });
});

// 发表评论到帖子
app.post('/api/posts/:postId/comments', requireAuth, (req, res) => {
  const pid = req.params.postId;
  const content = (req.body && req.body.content) ? String(req.body.content) : '';
  const parentId = (req.body && req.body.parentId) ? String(req.body.parentId) : null;
  if (!content.trim()) return res.status(400).json({ success: false, message: '评论内容不能为空' });
  if (parentId) {
    const parent = db.comments.find(c => c.id === parentId && c.postId === pid);
    if (!parent) return res.status(400).json({ success: false, message: '父评论不存在或不属于该帖子' });
  }
  const id = 'c-' + uuidv4();
  const createdAt = new Date().toISOString();
  db.comments.push({ id, postId: pid, content, authorId: req.user.id, createdAt, likeCount: 0, parentId });
  saveDb(db);
  const author = db.users.find(u => u.id === req.user.id) || { id: req.user.id, username: 'unknown', nickname: null, avatar: null };
  const comment = { id, content, author: toUserBrief(author, req), createdAt, likeCount: 0, parentId };
  // 发送评论通知：给帖子作者和父评论作者（若存在）
  try {
    const post = (Array.isArray(db.posts) ? db.posts : []).find(pp => pp.id === pid);
    if (post && post.authorId && post.authorId !== req.user.id) {
      pushMessage(req, {
        toUserId: post.authorId,
        type: 'post_comment',
        title: '你的帖子收到评论',
        content: `${(req.user && req.user.username) || '有人'}评论了你的帖子：${content.slice(0, 80)}`,
        data: { postId: pid, commentId: id }
      });
    }
    if (parentId) {
      const parent = db.comments.find(c => c.id === parentId && c.postId === pid);
      if (parent && parent.authorId && parent.authorId !== req.user.id) {
        pushMessage(req, {
          toUserId: parent.authorId,
          type: 'comment_reply',
          title: '你的评论有了新回复',
          content: `${(req.user && req.user.username) || '有人'}回复了你的评论：${content.slice(0, 80)}`,
          data: { postId: pid, commentId: id, parentId }
        });
      }
    }
  } catch (_) {}
  res.json({ success: true, message: '评论成功', data: comment });
});

// 点赞帖子中的评论
app.post('/api/posts/:postId/comments/:commentId/like', requireAuth, (req, res) => {
  const cid = req.params.commentId;
  const pid = req.params.postId;
  try {
    const exists = db.commentLikes.find(l => l.userId === req.user.id && l.commentId === cid);
    if (!exists) db.commentLikes.push({ userId: req.user.id, commentId: cid, postId: pid });
    saveDb(db);
    // 发送评论获赞通知给评论作者（排除自己赞自己的情况）
    try {
      const comment = db.comments.find(c => c.id === cid && c.postId === pid);
      if (comment && comment.authorId && comment.authorId !== req.user.id) {
        const title = '你的评论获赞';
        const content = `${(req.user && req.user.username) || '有人'}点赞了你在帖子的评论：${(comment.content || '').slice(0, 80)}`;
        pushMessage(req, {
          toUserId: comment.authorId,
          type: 'comment_like',
          title,
          content,
          data: { postId: pid, commentId: cid }
        });
      }
    } catch (_) {}
    res.json({ success: true, message: '已点赞评论' });
  } catch (e) {
    res.status(500).json({ success: false, message: '点赞失败' });
  }
});

// 取消点赞帖子中的评论
app.delete('/api/posts/:postId/comments/:commentId/like', requireAuth, (req, res) => {
  const cid = req.params.commentId;
  const pid = req.params.postId;
  try {
    db.commentLikes = db.commentLikes.filter(l => !(l.userId === req.user.id && l.commentId === cid));
    saveDb(db);
    res.json({ success: true, message: '已取消点赞评论' });
  } catch (e) {
    res.status(500).json({ success: false, message: '取消点赞失败' });
  }
});

// 删除帖子（文章/图片/音乐）
app.delete('/api/posts/:postId', requireAuth, (req, res) => {
  try {
    const pid = req.params.postId;
    db.posts = Array.isArray(db.posts) ? db.posts : [];
    const p = db.posts.find(pp => pp.id === pid);
    if (!p) return res.status(404).json({ success: false, message: '帖子不存在' });
    if (p.authorId !== req.user.id) return res.status(403).json({ success: false, message: '无权限删除该帖子' });

    // 删除图片文件
    if (Array.isArray(p.images)) {
      p.images.forEach(rel => {
        const fileName = path.basename(rel || '');
        if (fileName) {
          const filePath = path.join(__dirname, 'storage', 'images', fileName);
          if (fs.existsSync(filePath)) {
            try { fs.unlinkSync(filePath); } catch (_) {}
          }
        }
      });
    }

    // 删除音乐文件
    if (p.audioUrl) {
      const audioName = path.basename(p.audioUrl);
      if (audioName) {
        const audioPath = path.join(__dirname, 'storage', 'music', audioName);
        if (fs.existsSync(audioPath)) {
          try { fs.unlinkSync(audioPath); } catch (_) {}
        }
      }
    }

    // 删除封面
    if (p.coverUrl) {
      const coverName = path.basename(p.coverUrl);
      if (coverName) {
        const coverPath = path.join(__dirname, 'storage', 'thumbnails', coverName);
        if (fs.existsSync(coverPath)) {
          try { fs.unlinkSync(coverPath); } catch (_) {}
        }
      }
    }

    // 清理关联的点赞与评论
    db.likes = db.likes.filter(l => l.postId !== pid);
    const removedCommentIds = db.comments.filter(c => c.postId === pid).map(c => c.id);
    db.comments = db.comments.filter(c => c.postId !== pid);
    db.commentLikes = db.commentLikes.filter(l => !removedCommentIds.includes(l.commentId));

    // 删除帖子记录
    db.posts = db.posts.filter(pp => pp.id !== pid);
    saveDb(db);
    res.json({ success: true, message: '帖子已删除' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '删除失败' });
  }
});

// --- Chat (private messages) APIs ---
// 联系人列表：显示我关注的人，并标注互关/回关状态
// 在线状态 TTL（最近心跳 60 秒内视为在线）
const PRESENCE_ONLINE_TTL_MS = 60 * 1000;
// 情侣关系存储（用 db.couples 替代硬编码 LOVER_IDS）
db.couples = Array.isArray(db.couples) ? db.couples : [];
function getCouplePartnerId(userId) {
  const item = db.couples.find(c => c.userId === userId);
  return item ? item.partnerId : null;
}
function setCouple(userId, partnerId, startedAtMs) {
  // 删除旧条目
  db.couples = db.couples.filter(c => c.userId !== userId && c.userId !== partnerId);
  const now = Number.isFinite(startedAtMs) ? startedAtMs : Date.now();
  // 对称写入，方便查询
  db.couples.push({ userId, partnerId, startedAtMs: now });
  db.couples.push({ userId: partnerId, partnerId: userId, startedAtMs: now });
  saveDb(db);
}
function clearCouple(userId) {
  const item = db.couples.find(c => c.userId === userId);
  if (!item) return false;
  const partnerId = item.partnerId;
  db.couples = db.couples.filter(c => !(c.userId === userId || c.userId === partnerId));
  saveDb(db);
  return true;
}

// --- Miss-You (想念) APIs ---
// 说明：支持情侣间“想念”传话。发送后在对方打开App时显示全屏动画与内容，
// 对方点击“收到想念”进行确认；发送方可查看“未收到/已收到”与时间记录。
app.post('/api/missyou', requireAuth, (req, res) => {
  try {
    const myId = req.user.id;
    const partnerId = getCouplePartnerId(myId);
    if (!partnerId) return res.status(400).json({ success: false, message: 'not-couple' });
    const { content, preset } = req.body || {};
    const text = String(content || '').trim();
    if (!text) return res.status(400).json({ success: false, message: 'content-required' });
    const allowedPresets = new Set(['heartbeat', 'aurora', 'fireworks', 'ribbon', 'plane']);
    const presetName = allowedPresets.has(String(preset || '').trim()) ? String(preset).trim() : 'heartbeat';
    db.missYou = Array.isArray(db.missYou) ? db.missYou : [];
    const now = new Date().toISOString();
    const item = {
      id: 'mu-' + uuidv4(),
      fromUserId: myId,
      toUserId: partnerId,
      content: text.slice(0, 2000),
      preset: presetName,
      sentAt: now,
      received: false,
      receivedAt: null,
    };
    db.missYou.push(item);
    saveDb(db);
    return res.json({ success: true, message: 'sent', data: item });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '发送想念失败' });
  }
});

// 获取我待接收的最近一条“想念”（未确认收到）
app.get('/api/missyou/pending', requireAuth, (req, res) => {
  try {
    db.missYou = Array.isArray(db.missYou) ? db.missYou : [];
    const myId = req.user.id;
    const pending = db.missYou
      .filter(m => m.toUserId === myId && !m.received)
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());
    const item = pending[0] || null;
    if (!item) return res.json({ success: true, message: 'none', data: null });
    const fromUser = db.users.find(u => u.id === item.fromUserId);
    const fromName = fromUser ? (fromUser.nickname || fromUser.username) : 'Ta';
    return res.json({ success: true, message: 'OK', data: {
      id: item.id,
      fromUserId: item.fromUserId,
      fromName,
      content: item.content,
      preset: item.preset || 'heartbeat',
      sentAt: item.sentAt,
    } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '加载待接收想念失败' });
  }
});

// 确认收到“想念”
app.post('/api/missyou/ack', requireAuth, (req, res) => {
  try {
    const { id } = req.body || {};
    if (!id) return res.status(400).json({ success: false, message: 'id-required' });
    db.missYou = Array.isArray(db.missYou) ? db.missYou : [];
    const idx = db.missYou.findIndex(m => m.id === id && m.toUserId === req.user.id);
    if (idx < 0) return res.status(404).json({ success: false, message: 'not-found' });
    if (!db.missYou[idx].received) {
      db.missYou[idx].received = true;
      db.missYou[idx].receivedAt = new Date().toISOString();
      saveDb(db);
    }
    return res.json({ success: true, message: 'acknowledged', data: db.missYou[idx] });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '确认收到失败' });
  }
});

// 我发出的“想念”记录列表（含已/未收到与时间）
app.get('/api/missyou/sent', requireAuth, (req, res) => {
  try {
    db.missYou = Array.isArray(db.missYou) ? db.missYou : [];
    const myId = req.user.id;
    // 全量按时间倒序（最新在前）
    let rows = db.missYou
      .filter(m => m.fromUserId === myId)
      .sort((a, b) => new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime());

    // 支持分页与增量刷新：limit/before/after（与私信接口风格一致）
    let limit = req.query.limit != null ? parseInt(req.query.limit, 10) : 50;
    if (!Number.isFinite(limit) || limit <= 0) limit = 50;
    if (limit > 200) limit = 200;
    const before = req.query.before != null ? Number(req.query.before) : null; // 取小于此时间的更早记录
    const after = req.query.after != null ? Number(req.query.after) : null;   // 取大于此时间的更新记录

    if (after != null && Number.isFinite(after)) {
      rows = rows.filter(m => new Date(m.sentAt).getTime() > after);
    }
    if (before != null && Number.isFinite(before)) {
      rows = rows.filter(m => new Date(m.sentAt).getTime() < before);
    }

    const hasMore = rows.length > limit;
    if (rows.length > limit) {
      // 倒序下取前 limit 条（最新的若不带 before/after），或在筛选后取前 limit 条
      rows = rows.slice(0, limit);
    }
    const nextBefore = rows.length > 0 ? new Date(rows[rows.length - 1].sentAt).getTime() : null;

    const items = rows.map(m => {
      const toUser = db.users.find(u => u.id === m.toUserId);
      return {
        id: m.id,
        toUserId: m.toUserId,
        toName: toUser ? (toUser.nickname || toUser.username) : 'Ta',
        content: m.content,
        preset: m.preset || 'heartbeat',
        sentAt: m.sentAt,
        received: !!m.received,
        receivedAt: m.receivedAt,
      };
    });
    return res.json({ success: true, message: 'OK', data: { items, hasMore, nextBefore } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '加载发送记录失败' });
  }
});

// 删除我发出的某条“想念”（避免发错）。仅发送者可删除；若对方未收到则不再展示。
app.delete('/api/missyou/:id', requireAuth, (req, res) => {
  try {
    const id = req.params.id;
    db.missYou = Array.isArray(db.missYou) ? db.missYou : [];
    const idx = db.missYou.findIndex(m => m.id === id && m.fromUserId === req.user.id);
    if (idx < 0) return res.status(404).json({ success: false, message: 'not-found' });
    // 删除记录（无论对方是否已收到，仅影响发送者的记录列表；接收端展示不受影响）
    db.missYou.splice(idx, 1);
    saveDb(db);
    return res.json({ success: true, message: 'deleted' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '删除失败' });
  }
});

// —— 情侣空间模式 API（旧称“贴贴”已移除） ——
// 发送情侣空间邀请

// 获取待接收的最近一条情侣空间邀请（未处理）

// 同意情侣空间邀请

// 拒绝情侣空间邀请

// 我发出的情侣空间邀请记录（含未收到/已同意/已拒绝与时间）

app.get('/api/chat/contacts', requireAuth, (req, res) => {
  try {
    db.follows = Array.isArray(db.follows) ? db.follows : [];
    db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
    db.presence = Array.isArray(db.presence) ? db.presence : [];
    // 我关注的人
    const followingSet = new Set(
      db.follows
        .filter(f => f.followerId === req.user.id)
        .map(f => f.followeeId)
    );
    // 有过私信往来的用户（即便未关注）
    const dmPeerSet = new Set(
      db.privateMessages
        .filter(m => m.fromUserId === req.user.id || m.toUserId === req.user.id)
        .map(m => (m.fromUserId === req.user.id ? m.toUserId : m.fromUserId))
    );
    // 合并联系人：关注的人 ∪ 私信往来的人，排除自己
    const contactIds = new Set([...followingSet, ...dmPeerSet]);
    contactIds.delete(req.user.id);
    const contacts = db.users
      .filter(u => contactIds.has(u.id))
      .map(u => {
        const isFollowing = followingSet.has(u.id);
        const isFollower = !!db.follows.find(f => f.followerId === u.id && f.followeeId === req.user.id);
        const isFriend = isFollowing && isFollower;
        const pres = db.presence.find(p => p.userId === u.id);
        const lastOnlineAt = pres ? Number(pres.lastOnlineAt || 0) : null;
        const online = lastOnlineAt ? ((Date.now() - lastOnlineAt) <= PRESENCE_ONLINE_TTL_MS) : false;
        // 计算与该联系人的未读消息数量
        const unreadCount = db.privateMessages.filter(m => m.toUserId === req.user.id && m.fromUserId === u.id && !m.read).length;
        return {
          id: u.id,
          username: u.username,
          nickname: u.nickname || null,
          avatar: u.avatar ? absoluteUrl(req, u.avatar) : null,
          isFollowing,
          isFollower,
          isFriend,
          online,
          lastOnlineAt,
          unreadCount,
        };
      });
    res.json({ success: true, message: 'OK', data: { contacts } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '获取联系人失败' });
  }
});

// 情侣空间：返回情侣对象信息与关系起始时间
app.get('/api/couple', requireAuth, (req, res) => {
  try {
    const myId = req.user.id;
    const partnerId = getCouplePartnerId(myId);
    if (!partnerId) {
      return res.json({ success: true, message: 'not-couple', data: null });
    }
    const partner = db.users.find((u) => u.id === partnerId);
    if (!partner) {
      return res.status(404).json({ success: false, message: 'partner-not-found', data: null });
    }

    db.follows = Array.isArray(db.follows) ? db.follows : [];
    db.presence = Array.isArray(db.presence) ? db.presence : [];

    const isFollowing = !!db.follows.find((f) => f.followerId === myId && f.followeeId === partnerId);
    const isFollower = !!db.follows.find((f) => f.followerId === partnerId && f.followeeId === myId);
    const isFriend = isFollowing && isFollower;

    const pres = db.presence.find((p) => p.userId === partnerId);
    const lastOnlineAt = pres ? Number(pres.lastOnlineAt || 0) : null;
    const online = lastOnlineAt ? ((Date.now() - lastOnlineAt) <= PRESENCE_ONLINE_TTL_MS) : false;

    // 关系开始时间：优先使用 db.couples 中的 startedAtMs
    const coupleItem = db.couples.find(c => c.userId === myId && c.partnerId === partnerId);
    let startAt = coupleItem ? Number(coupleItem.startedAtMs || 0) : null;
    if (!startAt || !Number.isFinite(startAt)) {
      // 回退：取互相关注中较早的时间（若存在）
      const followAB = db.follows.find((f) => f.followerId === myId && f.followeeId === partnerId);
      const followBA = db.follows.find((f) => f.followerId === partnerId && f.followeeId === myId);
      if (followAB && followBA) {
        const t1 = new Date(followAB.createdAt).getTime();
        const t2 = new Date(followBA.createdAt).getTime();
        startAt = Math.min(t1, t2);
      } else if (followAB || followBA) {
        const t = new Date((followAB || followBA).createdAt).getTime();
        startAt = Number.isFinite(t) ? t : null;
      }
    }

    const partnerBrief = {
      id: partner.id,
      username: partner.username,
      nickname: partner.nickname || null,
      avatar: partner.avatar ? (partner.avatar.startsWith('http') ? partner.avatar : absoluteUrl(req, partner.avatar)) : null,
      isFollowing,
      isFollower,
      isFriend,
      online,
      lastOnlineAt,
    };

    return res.json({ success: true, message: 'OK', data: { partner: partnerBrief, startAt } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '获取情侣信息失败' });
  }
});

// 设定/更新情侣关系
app.post('/api/couple', requireAuth, (req, res) => {
  try {
    const myId = req.user.id;
    const { partnerId, startedAtMs } = req.body || {};
    if (!partnerId || typeof partnerId !== 'string') {
      return res.status(400).json({ success: false, message: 'partnerId-required' });
    }
    if (partnerId === myId) {
      return res.status(400).json({ success: false, message: 'cannot-set-self-as-partner' });
    }
    const partner = db.users.find(u => u.id === partnerId);
    if (!partner) {
      return res.status(404).json({ success: false, message: 'partner-not-found' });
    }
    setCouple(myId, partnerId, Number(startedAtMs));
    return res.json({ success: true, message: 'couple-updated' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '更新情侣关系失败' });
  }
});

// 解除情侣关系
app.delete('/api/couple', requireAuth, (req, res) => {
  try {
    const myId = req.user.id;
    const ok = clearCouple(myId);
    if (!ok) return res.status(404).json({ success: false, message: 'not-couple' });
    return res.json({ success: true, message: 'couple-cleared' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '解除情侣关系失败' });
  }
});

// --- Post Read History APIs ---
// 获取我的帖子浏览历史
app.get('/api/post-history', requireAuth, (req, res) => {
  try {
    db.postHistory = Array.isArray(db.postHistory) ? db.postHistory : [];
    const rows = db.postHistory
      .filter(h => h.userId === req.user.id)
      .sort((a, b) => (b.readAt || '').localeCompare(a.readAt || ''));
    const items = rows.map(h => {
      const p = db.posts.find(pp => pp.id === h.postId) || {};
      const author = db.users.find(u => u.id === p.authorId);
      return {
        id: h.id,
        postId: h.postId,
        title: p.title || '未知帖子',
        coverUrl: p.coverUrl ? absoluteUrl(req, p.coverUrl) : (Array.isArray(p.images) && p.images[0] ? absoluteUrl(req, p.images[0]) : ''),
        authorName: (author && (author.nickname || author.username)) || '未知作者',
        readTime: new Date(h.readAt || Date.now()).toISOString(),
        type: p.type || 'article'
      };
    });
    res.json({ success: true, message: 'OK', data: { history: items } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '加载帖子历史失败' });
  }
});

// 添加或更新我的帖子浏览历史（同一帖子仅保留一条，按最近浏览覆盖）
app.post('/api/post-history', requireAuth, (req, res) => {
  try {
    const { postId } = req.body || {};
    if (!postId) return res.status(400).json({ success: false, message: '缺少postId' });
    const p = db.posts.find(pp => pp.id === postId);
    if (!p) return res.status(404).json({ success: false, message: '帖子不存在' });
    db.postHistory = Array.isArray(db.postHistory) ? db.postHistory : [];
    const now = new Date().toISOString();
    const idx = db.postHistory.findIndex(h => h.userId === req.user.id && h.postId === postId);
    if (idx >= 0) {
      db.postHistory[idx] = {
        ...db.postHistory[idx],
        readAt: now,
      };
    } else {
      db.postHistory.push({
        id: uuidv4(),
        userId: req.user.id,
        postId,
        readAt: now,
      });
    }
    saveDb(db);
    res.json({ success: true, message: '已记录帖子历史' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '记录帖子历史失败' });
  }
});

// 删除单条帖子浏览历史
app.delete('/api/post-history/:id', requireAuth, (req, res) => {
  try {
    const id = req.params.id;
    db.postHistory = Array.isArray(db.postHistory) ? db.postHistory : [];
    const before = db.postHistory.length;
    db.postHistory = db.postHistory.filter(h => !(h.id === id && h.userId === req.user.id));
    if (db.postHistory.length !== before) saveDb(db);
    res.json({ success: true, message: '已删除' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '删除失败' });
  }
});

// 清空我的所有帖子浏览历史
app.delete('/api/post-history', requireAuth, (req, res) => {
  try {
    db.postHistory = Array.isArray(db.postHistory) ? db.postHistory : [];
    const before = db.postHistory.length;
    db.postHistory = db.postHistory.filter(h => h.userId !== req.user.id);
    if (db.postHistory.length !== before) saveDb(db);
    res.json({ success: true, message: '已清空' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '清空失败' });
  }
});

// 心跳：标记我在线并更新最后在线时间
app.post('/api/presence/heartbeat', requireAuth, (req, res) => {
  try {
    db.presence = Array.isArray(db.presence) ? db.presence : [];
    const now = Date.now();
    const idx = db.presence.findIndex(p => p.userId === req.user.id);
    if (idx >= 0) {
      db.presence[idx].lastOnlineAt = now;
    } else {
      db.presence.push({ userId: req.user.id, lastOnlineAt: now });
    }
    saveDb(db);
    res.json({ success: true, message: 'OK' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '心跳失败' });
  }
});

// --- Watch Together authoritative presence ---
const WATCH_ONLINE_TTL_MS = 30 * 1000; // 30s 超时下线
db.watchSessions = db.watchSessions && typeof db.watchSessions === 'object' ? db.watchSessions : {};

function ensureWatchSession(contentKey) {
  if (!contentKey || typeof contentKey !== 'string') return null;
  if (!db.watchSessions[contentKey]) {
    db.watchSessions[contentKey] = { watchers: [] };
  }
  return db.watchSessions[contentKey];
}

function cleanupWatchers(session) {
  const now = Date.now();
  session.watchers = (session.watchers || []).filter(w => (now - (w.lastHeartbeatAt || 0)) <= WATCH_ONLINE_TTL_MS);
}

// 开始观看：加入指定 contentKey 的会话
app.post('/api/watch/start', requireAuth, (req, res) => {
  try {
    const { contentKey } = req.body || {};
    if (!contentKey || typeof contentKey !== 'string') return res.status(400).json({ success: false, message: 'contentKey 必填' });
    const session = ensureWatchSession(contentKey);
    const now = Date.now();
    const idx = session.watchers.findIndex(w => w.userId === req.user.id);
    if (idx >= 0) {
      session.watchers[idx].lastHeartbeatAt = now;
    } else {
      session.watchers.push({ userId: req.user.id, lastHeartbeatAt: now });
    }
    cleanupWatchers(session);
    saveDb(db);
    res.json({ success: true, message: 'OK', data: { onlineCount: session.watchers.length } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '加入观看失败' });
  }
});

// 心跳：维持观看在线
app.post('/api/watch/heartbeat', requireAuth, (req, res) => {
  try {
    const { contentKey } = req.body || {};
    if (!contentKey || typeof contentKey !== 'string') return res.status(400).json({ success: false, message: 'contentKey 必填' });
    const session = ensureWatchSession(contentKey);
    const now = Date.now();
    const idx = session.watchers.findIndex(w => w.userId === req.user.id);
    if (idx >= 0) {
      session.watchers[idx].lastHeartbeatAt = now;
    } else {
      session.watchers.push({ userId: req.user.id, lastHeartbeatAt: now });
    }
    cleanupWatchers(session);
    saveDb(db);
    res.json({ success: true, message: 'OK', data: { onlineCount: session.watchers.length } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '观看心跳失败' });
  }
});

// 停止观看：退出会话
app.post('/api/watch/stop', requireAuth, (req, res) => {
  try {
    const { contentKey } = req.body || {};
    if (!contentKey || typeof contentKey !== 'string') return res.status(400).json({ success: false, message: 'contentKey 必填' });
    const session = ensureWatchSession(contentKey);
    session.watchers = (session.watchers || []).filter(w => w.userId !== req.user.id);
    cleanupWatchers(session);
    saveDb(db);
    res.json({ success: true, message: 'OK', data: { onlineCount: session.watchers.length } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '退出观看失败' });
  }
});

// 查询当前观看在线人数（权威数据）
app.get('/api/watch/online', requireAuth, (req, res) => {
  try {
    const contentKey = req.query.contentKey;
    if (!contentKey || typeof contentKey !== 'string') return res.status(400).json({ success: false, message: 'contentKey 必填' });
    const session = ensureWatchSession(contentKey);
    cleanupWatchers(session);
    saveDb(db);
    const onlineIds = (session.watchers || []).map(w => w.userId);
    res.json({ success: true, message: 'OK', data: { onlineCount: onlineIds.length, userIds: onlineIds } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '获取观看在线失败' });
  }
});

// --- Couple Shared Album APIs ---
const COUPLE_ALBUMS_DIR = path.join(STORAGE_DIR, 'couple_albums');
if (!fs.existsSync(COUPLE_ALBUMS_DIR)) fs.mkdirSync(COUPLE_ALBUMS_DIR, { recursive: true });
function getPairKey(a, b) {
  return [a, b].sort().join('__');
}

// 列出情侣共同相册图片
app.get('/api/couple/album', requireAuth, async (req, res) => {
  try {
    const myId = req.user.id;
    const partnerId = getCouplePartnerId(myId);
    if (!partnerId) return res.json({ success: true, message: 'not-couple', data: [] });
    const pairKey = getPairKey(myId, partnerId);
    const dir = path.join(COUPLE_ALBUMS_DIR, pairKey);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const files = fs.readdirSync(dir).filter(n => !n.startsWith('.'));
  const items = await Promise.all(files.map(async (name) => {
    const fp = path.join(dir, name);
    const st = fs.statSync(fp);
    const ext = path.extname(name).toLowerCase();
    const videoExts = ['.mp4', '.mov', '.webm', '.mkv', '.m3u8'];
    const isVideo = videoExts.includes(ext) || name.toLowerCase().includes('.m3u8');
    let durationSec = null;
    if (isVideo && ext !== '.m3u8') {
      try { durationSec = await getDurationSec(fp); } catch (_) { durationSec = null; }
    }
    const relPath = path.join('/storage', 'couple_albums', pairKey, name).replace(/\\/g, '/');
    return {
      id: name,
      url: absoluteUrl(req, relPath),
      uploadedAtMs: Math.round(st.mtimeMs),
      isVideo,
      durationSec: (typeof durationSec === 'number' && durationSec > 0) ? durationSec : null,
      // 图片项直接以自身 URL 作为封面；视频项保持空字符串，交由前端回退处理
      coverUrl: isVideo ? '' : absoluteUrl(req, relPath),
    };
  }));
    items.sort((a, b) => (b.uploadedAtMs || 0) - (a.uploadedAtMs || 0));
    return res.json({ success: true, message: 'OK', data: items });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '获取相册失败' });
  }
});

// 上传情侣共同相册图片
const uploadCoupleAlbum = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      try {
        const myId = req.user.id;
        const partnerId = getCouplePartnerId(myId);
        if (!partnerId) return cb(new Error('not-couple'));
        const pairKey = getPairKey(myId, partnerId);
        const dir = path.join(COUPLE_ALBUMS_DIR, pairKey);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
      } catch (e) {
        cb(e);
      }
    },
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${Date.now()}_${uuidv4()}${ext}`);
    },
  }),
});

app.post('/api/couple/album/upload', requireAuth, uploadCoupleAlbum.array('images', 12), async (req, res) => {
  try {
    const files = req.files || [];
    const myId = req.user.id;
    const partnerId = getCouplePartnerId(myId);
    if (!partnerId) return res.status(400).json({ success: false, message: 'not-couple' });
    const pairKey = getPairKey(myId, partnerId);
  const items = await Promise.all(files.map(async (f) => {
    const ext = path.extname(f.filename).toLowerCase();
    const videoExts = ['.mp4', '.mov', '.webm', '.mkv', '.m3u8'];
    const isVideo = videoExts.includes(ext) || f.filename.toLowerCase().includes('.m3u8');
    let durationSec = null;
    if (isVideo && ext !== '.m3u8') {
      try { durationSec = await getDurationSec(f.path); } catch (_) { durationSec = null; }
    }
    const relPath = path.join('/storage', 'couple_albums', pairKey, f.filename).replace(/\\/g, '/');
    return {
      id: path.basename(f.filename),
      url: absoluteUrl(req, relPath),
      uploadedAtMs: Date.now(),
      isVideo,
      durationSec: (typeof durationSec === 'number' && durationSec > 0) ? durationSec : null,
      // 图片项直接以自身 URL 作为封面；视频项保持空字符串，交由前端回退处理
      coverUrl: isVideo ? '' : absoluteUrl(req, relPath),
    };
  }));
    return res.json({ success: true, message: 'uploaded', data: items });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '上传相册失败' });
  }
});

// 删除情侣共同相册图片
app.delete('/api/couple/album/:filename', requireAuth, (req, res) => {
  try {
    const myId = req.user.id;
    const partnerId = getCouplePartnerId(myId);
    if (!partnerId) return res.status(400).json({ success: false, message: 'not-couple' });
    const pairKey = getPairKey(myId, partnerId);
    const dir = path.join(COUPLE_ALBUMS_DIR, pairKey);
    const fp = path.join(dir, req.params.filename);
    if (!fs.existsSync(fp)) return res.status(404).json({ success: false, message: 'file-not-found' });
    fs.unlinkSync(fp);
    return res.json({ success: true, message: 'deleted' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '删除相册失败' });
  }
});
// 会话消息列表（与指定用户的双向聊天记录）
app.get('/api/chat/:peerId/messages', requireAuth, (req, res) => {
  try {
    const peerId = req.params.peerId;
    db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
    let rows = db.privateMessages
      .filter(m => (m.fromUserId === req.user.id && m.toUserId === peerId) || (m.fromUserId === peerId && m.toUserId === req.user.id))
      .sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
    // 支持分页与增量刷新：limit/before/after
    let limit = req.query.limit != null ? parseInt(req.query.limit, 10) : 50;
    if (!Number.isFinite(limit) || limit <= 0) limit = 50;
    if (limit > 200) limit = 200;
    const before = req.query.before != null ? Number(req.query.before) : null;
    const after = req.query.after != null ? Number(req.query.after) : null;
    if (after != null && Number.isFinite(after)) {
      rows = rows.filter(m => (m.timestamp || 0) > after);
    }
    if (before != null && Number.isFinite(before)) {
      rows = rows.filter(m => (m.timestamp || 0) < before);
    }
    if (rows.length > limit) {
      rows = rows.slice(rows.length - limit);
    }
    const messages = rows.map(m => ({
      id: m.id,
      fromUserId: m.fromUserId,
      toUserId: m.toUserId,
      content: m.content,
      timestamp: m.timestamp,
      isMine: m.fromUserId === req.user.id,
      read: !!m.read,
      recalled: !!m.recalled,
    }));
    res.json({ success: true, message: 'OK', data: { messages } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '获取会话失败' });
  }
});

// 发送私信
app.post('/api/chat/:peerId/messages', requireAuth, (req, res) => {
  try {
    const peerId = req.params.peerId;
    const peer = db.users.find(u => u.id === peerId);
    if (!peer) return res.status(404).json({ success: false, message: '目标用户不存在' });
    const content = (req.body && req.body.content) ? String(req.body.content).trim() : '';
    if (!content) return res.status(400).json({ success: false, message: '消息内容不能为空' });
    const id = 'pm-' + uuidv4();
    const timestamp = Date.now();
    db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
    db.privateMessages.push({ id, fromUserId: req.user.id, toUserId: peerId, content, timestamp, read: false, recalled: false });
    saveDb(db);
    res.json({ success: true, message: '消息已发送', data: { id, fromUserId: req.user.id, toUserId: peerId, content, timestamp, isMine: true, read: false, recalled: false } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '发送失败' });
  }
});

// 撤回消息（仅允许发送者在2分钟内撤回）
app.post('/api/chat/:peerId/messages/:messageId/recall', requireAuth, (req, res) => {
  try {
    const peerId = req.params.peerId;
    const messageId = req.params.messageId;
    db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
    const msg = db.privateMessages.find(m => m.id === messageId);
    if (!msg) return res.status(404).json({ success: false, message: '消息不存在' });
    if (msg.fromUserId !== req.user.id || msg.toUserId !== peerId) {
      return res.status(403).json({ success: false, message: '无权撤回该消息' });
    }
    const now = Date.now();
    const withinWindow = (now - (msg.timestamp || 0)) <= 2 * 60 * 1000; // 2分钟
    if (!withinWindow) {
      return res.status(400).json({ success: false, message: '超过2分钟无法撤回' });
    }
    if (msg.recalled) {
      return res.json({ success: true, message: '消息已撤回', data: {
        id: msg.id,
        fromUserId: msg.fromUserId,
        toUserId: msg.toUserId,
        content: msg.content || '',
        timestamp: msg.timestamp,
        isMine: true,
        read: !!msg.read,
        recalled: true
      } });
    }
    msg.recalled = true;
    // 可选择清空内容或保留，这里清空以表现撤回
    msg.content = '';
    saveDb(db);
    return res.json({ success: true, message: '撤回成功', data: {
      id: msg.id,
      fromUserId: msg.fromUserId,
      toUserId: msg.toUserId,
      content: msg.content || '',
      timestamp: msg.timestamp,
      isMine: true,
      read: !!msg.read,
      recalled: true
    } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '撤回失败' });
  }
});

// 将与某人的未读消息标记为已读（我为接收方）
app.post('/api/chat/:peerId/read', requireAuth, (req, res) => {
  try {
    const peerId = req.params.peerId;
    db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
    let changed = 0;
    db.privateMessages.forEach(m => {
      if (m.toUserId === req.user.id && m.fromUserId === peerId && !m.read) { m.read = true; changed++; }
    });
    if (changed > 0) saveDb(db);
    res.json({ success: true, message: '已标记为已读', data: { changed } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '操作失败' });
  }
});

// 未读私信总数
app.get('/api/chat/unreadCount', requireAuth, (req, res) => {
  try {
    db.privateMessages = Array.isArray(db.privateMessages) ? db.privateMessages : [];
    const count = db.privateMessages.filter(m => m.toUserId === req.user.id && !m.read).length;
    res.json({ success: true, message: 'OK', data: { count } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '获取未读数失败' });
  }
});

// --- Search APIs ---
app.get('/api/search/videos', (req, res) => {
  const query = (req.query.query || '').toString();
  const rows = db.videos.filter(v => (v.title || '').includes(query)).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  const list = rows.map(v => {
    const author = db.users.find(u => u.id === v.authorId) || { id: v.authorId, username: 'unknown', nickname: null, avatar: null };
    const viewCount = db.views.filter(vw => vw.videoId === v.id).length;
    return { id: v.id, title: v.title, videoUrl: absoluteUrl(req, v.videoUrl), coverUrl: v.coverUrl ? absoluteUrl(req, v.coverUrl) : '', duration: Number(v.duration) || 0, viewCount, likeCount: db.likes.filter(l => l.videoId === v.id).length, author: toUserBrief(author, req) };
  });
  res.json({ success: true, message: 'OK', data: { videos: list, totalPages: 1, currentPage: 1 } });
});

app.get('/api/search/users', (req, res) => {
  const query = (req.query.query || '').toString();
  db.follows = Array.isArray(db.follows) ? db.follows : [];
  const rows = db.users
    .filter(u => (u.username || '').includes(query))
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  const users = rows.map(u => {
    const isFollowing = req.user ? !!db.follows.find(f => f.followerId === req.user.id && f.followeeId === u.id) : false;
    const isFollower = req.user ? !!db.follows.find(f => f.followerId === u.id && f.followeeId === req.user.id) : false;
    const isFriend = isFollowing && isFollower;
    return {
      id: u.id,
      username: u.username,
      avatar: u.avatar ? absoluteUrl(req, u.avatar) : null,
      followersCount: Number(u.followersCount) || 0,
      videosCount: Number(u.videosCount) || 0,
      isFollowing,
      isFollower,
      isFriend,
    };
  });
  res.json({ success: true, message: 'OK', data: { users, totalPages: 1, currentPage: 1 } });
});

// User avatar upload
app.post('/api/user/avatar', requireAuth, upload.single('avatar'), (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ success: false, message: '缺少头像文件' });
  const relative = `/storage/avatars/${file.filename}`;
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ success: false, message: '用户不存在' });
  user.avatar = relative;
  saveDb(db);
  const responseUser = { ...user };
  delete responseUser.passwordHash;
  responseUser.avatar = absoluteUrl(req, responseUser.avatar);
  res.json({ success: true, message: '头像已更新', data: { avatarUrl: responseUser.avatar, user: responseUser } });
});

// 用户资料更新（昵称/签名）
app.post('/api/user/profile', requireAuth, (req, res) => {
  try {
    const { nickname, signature } = req.body || {};
    const user = db.users.find(u => u.id === req.user.id);
    if (!user) return res.status(404).json({ success: false, message: '用户不存在' });

    if (typeof nickname === 'string') {
      const trimmed = nickname.trim();
      user.nickname = trimmed;
    }
    if (typeof signature === 'string') {
      const trimmed = signature.trim();
      user.signature = trimmed;
    }

    saveDb(db);
    const responseUser = { ...user };
    delete responseUser.passwordHash;
    responseUser.avatar = responseUser.avatar ? absoluteUrl(req, responseUser.avatar) : '';
    return res.json({ success: true, message: '资料已更新', data: { user: responseUser } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ success: false, message: '更新资料失败' });
  }
});

// 用户统计：总获赞（不含评论赞）与作品数量
app.get('/api/users/:userId/stats', (req, res) => {
  const userId = req.params.userId;
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ success: false, message: '用户不存在' });
  const userVideos = db.videos.filter(v => v.authorId === userId);
  const videosCount = userVideos.length;
  const videoIds = new Set(userVideos.map(v => v.id));
  // 统计帖子（文章/图片/音乐）点赞
  db.posts = Array.isArray(db.posts) ? db.posts : [];
  const userPosts = db.posts.filter(p => p.authorId === userId);
  const postIds = new Set(userPosts.map(p => p.id));
  // 总获赞 = 我的视频被点赞数 + 我的帖子被点赞数（不含评论赞）
  const likesCount = db.likes.filter(l => (l.videoId && videoIds.has(l.videoId)) || (l.postId && postIds.has(l.postId))).length;
  // 关注/粉丝统计（基于动态关系）
  db.follows = Array.isArray(db.follows) ? db.follows : [];
  const followersCount = db.follows.filter(f => f.followeeId === userId).length;
  const followingCount = db.follows.filter(f => f.followerId === userId).length;
  const isFollowing = req.user ? !!db.follows.find(f => f.followerId === req.user.id && f.followeeId === userId) : false;
  const isFollower = req.user ? !!db.follows.find(f => f.followerId === userId && f.followeeId === req.user.id) : false;
  const isFriend = isFollowing && isFollower;
  res.json({ success: true, message: 'OK', data: { likesCount, videosCount, followersCount, followingCount, isFollowing, isFollower, isFriend } });
});

// 关注用户
app.post('/api/users/:userId/follow', requireAuth, (req, res) => {
  const targetId = req.params.userId;
  if (targetId === req.user.id) {
    return res.status(400).json({ success: false, message: '不能关注自己' });
  }
  const target = db.users.find(u => u.id === targetId);
  if (!target) return res.status(404).json({ success: false, message: '用户不存在' });
  db.follows = Array.isArray(db.follows) ? db.follows : [];
  const exists = db.follows.find(f => f.followerId === req.user.id && f.followeeId === targetId);
  if (!exists) {
    db.follows.push({ followerId: req.user.id, followeeId: targetId, createdAt: new Date().toISOString() });
    saveDb(db);
    // 发送关注通知
    try {
      pushMessage(req, {
        toUserId: targetId,
        type: 'follow',
        title: '你有了新的关注者',
        content: `${(req.user && req.user.username) || '有人'}关注了你`,
        data: { followerId: req.user.id }
      });
    } catch (_) {}
  }
  res.json({ success: true, message: '已关注' });
});

// 取消关注
app.delete('/api/users/:userId/follow', requireAuth, (req, res) => {
  const targetId = req.params.userId;
  db.follows = Array.isArray(db.follows) ? db.follows : [];
  const before = db.follows.length;
  db.follows = db.follows.filter(f => !(f.followerId === req.user.id && f.followeeId === targetId));
  if (db.follows.length !== before) saveDb(db);
  res.json({ success: true, message: '已取消关注' });
});

// 粉丝列表
app.get('/api/users/:userId/followers', (req, res) => {
  const userId = req.params.userId;
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ success: false, message: '用户不存在' });
  db.follows = Array.isArray(db.follows) ? db.follows : [];
  const followerIds = db.follows.filter(f => f.followeeId === userId).map(f => f.followerId);
  const users = db.users.filter(u => followerIds.includes(u.id)).map(u => {
    const brief = toUserBrief(u, req);
    const isFollowing = req.user ? !!db.follows.find(f => f.followerId === req.user.id && f.followeeId === u.id) : false;
    const isFollower = req.user ? !!db.follows.find(f => f.followerId === u.id && f.followeeId === req.user.id) : false;
    return { ...brief, isFollowing, isFollower, isFriend: isFollowing && isFollower };
  });
  res.json({ success: true, message: 'OK', data: { users } });
});

// 关注列表
app.get('/api/users/:userId/following', (req, res) => {
  const userId = req.params.userId;
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ success: false, message: '用户不存在' });
  db.follows = Array.isArray(db.follows) ? db.follows : [];
  const followeeIds = db.follows.filter(f => f.followerId === userId).map(f => f.followeeId);
  const users = db.users.filter(u => followeeIds.includes(u.id)).map(u => {
    const brief = toUserBrief(u, req);
    const isFollowing = req.user ? !!db.follows.find(f => f.followerId === req.user.id && f.followeeId === u.id) : false;
    const isFollower = req.user ? !!db.follows.find(f => f.followerId === u.id && f.followeeId === req.user.id) : false;
    return { ...brief, isFollowing, isFollower, isFriend: isFollowing && isFollower };
  });
  res.json({ success: true, message: 'OK', data: { users } });
});

app.get('/', (req, res) => {
  const hasPreview = fs.existsSync(PREVIEW_DIR);
  res.send(
    'Real backend running (JSON persistent storage). ' +
    'Try GET /api/videos' +
    (hasPreview ? ' or open /preview/' : '')
  );
});
// 删除帖子中的评论（仅作者可删；删除该评论及其直接回复与相关点赞）
app.delete('/api/posts/:postId/comments/:commentId', requireAuth, (req, res) => {
  try {
    const pid = req.params.postId;
    const cid = req.params.commentId;
    const target = db.comments.find(c => c.id === cid && c.postId === pid);
    if (!target) return res.status(404).json({ success: false, message: '评论不存在' });
    if (target.authorId !== req.user.id) return res.status(403).json({ success: false, message: '无权限删除该评论' });

    const toDeleteIds = new Set([cid]);
    db.comments.forEach(c => { if (c.postId === pid && c.parentId === cid) toDeleteIds.add(c.id); });
    db.comments = db.comments.filter(c => !(c.postId === pid && toDeleteIds.has(c.id)));
    db.commentLikes = Array.isArray(db.commentLikes) ? db.commentLikes.filter(l => !toDeleteIds.has(l.commentId)) : [];
    saveDb(db);
    res.json({ success: true, message: '评论已删除' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '删除失败' });
  }
});

// 删除视频中的评论（仅作者可删；删除该评论及其直接回复与相关点赞）
app.delete('/api/videos/:videoId/comments/:commentId', requireAuth, (req, res) => {
  try {
    const vid = req.params.videoId;
    const cid = req.params.commentId;
    const target = db.comments.find(c => c.id === cid && c.videoId === vid);
    if (!target) return res.status(404).json({ success: false, message: '评论不存在' });
    if (target.authorId !== req.user.id) return res.status(403).json({ success: false, message: '无权限删除该评论' });

    const toDeleteIds = new Set([cid]);
    db.comments.forEach(c => { if (c.videoId === vid && c.parentId === cid) toDeleteIds.add(c.id); });
    db.comments = db.comments.filter(c => !(c.videoId === vid && toDeleteIds.has(c.id)));
    db.commentLikes = Array.isArray(db.commentLikes) ? db.commentLikes.filter(l => !toDeleteIds.has(l.commentId)) : [];
    saveDb(db);
    res.json({ success: true, message: '评论已删除' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ success: false, message: '删除失败' });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Backend listening on http://localhost:${PORT}/`);
});

// 记录唯一播放（每用户每视频仅一次）
app.post('/api/videos/:videoId/view', requireAuth, (req, res) => {
  const videoId = req.params.videoId;
  const userId = req.user.id;
  const v = db.videos.find(vv => vv.id === videoId);
  if (!v) return res.status(404).json({ success: false, message: '视频不存在' });
  db.views = Array.isArray(db.views) ? db.views : [];
  const exists = db.views.find(vw => vw.videoId === videoId && vw.userId === userId);
  if (!exists) {
    db.views.push({ id: uuidv4(), videoId, userId, createdAt: new Date().toISOString() });
    saveDb(db);
  }
  const viewCount = db.views.filter(vw => vw.videoId === videoId).length;
  res.json({ success: true, message: 'OK', data: { viewCount, isNewView: !exists } });
});
